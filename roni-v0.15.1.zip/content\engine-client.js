// content/engine-client.js — thin proxy.
// Receives chrome.tabs messages from popup/background, forwards them to the
// background service worker (which actually fetches the local Engine).
// We can't fetch http://localhost from a content script on https://web.whatsapp.com
// due to mixed-content blocking — background runs in chrome-extension:// origin
// and is allowed to.

(function () {
  'use strict';

  const TAG = '[GetJob/engine-client]';

  function proxyToBackground(action, opts = {}, sendResponse) {
    chrome.runtime.sendMessage({ type: 'ENGINE_PROXY_' + action, opts }, (resp) => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse(resp);
    });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return false;

    if (msg.type === 'SEND_MESSAGE') {
      const clientAckId = msg.clientAckId || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
      proxyToBackground('SEND', { body: { phone: msg.phone, text: msg.text, clientAckId } }, (resp) => {
        if (resp?.success) {
          sendResponse({
            success: true,
            result: {
              method: 'engine',
              ack: resp.result.ack,
              msgId: resp.result.messageId,
              clientAckId: resp.result.clientAckId
            }
          });
        } else {
          sendResponse({ success: false, error: resp?.error || 'PROXY_FAILED', detail: resp?.detail });
        }
      });
      return true;
    }

    if (msg.type === 'GET_STATUS') {
      proxyToBackground('STATUS', {}, (resp) => {
        if (resp?.success) {
          sendResponse({
            success: true,
            result: {
              ready: resp.result.state === 'READY',
              state: resp.result.state,
              phone: resp.result.phone,
              since: resp.result.since
            }
          });
        } else {
          sendResponse({
            success: true,
            result: { ready: false, state: 'ENGINE_DOWN', error: resp?.error }
          });
        }
      });
      return true;
    }

    if (msg.type === 'EXTRACT_CHATS') {
      proxyToBackground('EXTRACT_CHATS', { body: msg.options || { limit: 200, includeGroups: true } }, (resp) => {
        if (resp?.success) sendResponse({ success: true, result: { chats: resp.result.chats } });
        else sendResponse({ success: false, error: resp?.error });
      });
      return true;
    }

    if (msg.type === 'GET_GROUP_MEMBERS') {
      proxyToBackground('GET_GROUP_MEMBERS', { groupId: msg.groupId }, (resp) => {
        if (resp?.success) sendResponse({ success: true, result: { members: resp.result.members } });
        else sendResponse({ success: false, error: resp?.error });
      });
      return true;
    }

    if (msg.type === 'SEND_GROUP') {
      proxyToBackground('SEND_GROUP', { body: { groupId: msg.groupId, text: msg.text } }, (resp) => {
        sendResponse(resp);
      });
      return true;
    }

    if (msg.type === 'ENGINE_HEALTH') {
      proxyToBackground('HEALTH', {}, (resp) => {
        sendResponse(resp);
      });
      return true;
    }

    // Legacy no-ops for backward compatibility
    if (msg.type === 'REBUILD_STORE') {
      sendResponse({ success: true, result: { hasStore: false, mode: 'engine', note: 'Engine handles WA — no Store rebuild needed' } });
      return false;
    }
    if (msg.type === 'RUN_DIAGNOSTIC') {
      Promise.all([
        new Promise(r => proxyToBackground('HEALTH', {}, r)),
        new Promise(r => proxyToBackground('STATUS', {}, r))
      ]).then(([healthResp, statusResp]) => {
        const health = healthResp?.success ? healthResp.result : { error: healthResp?.error };
        const status = statusResp?.success ? statusResp.result : { error: statusResp?.error };
        sendResponse({
          success: true,
          result: {
            capturedAt: new Date().toISOString(),
            version: '0.15.0',
            strategy: 'Engine HTTP via background proxy (whatsapp-web.js)',
            engine: { health, status },
            recommendations: [
              health.error
                ? `🔴 Engine לא מגיב: ${health.error}. וודא שה-Engine רץ + ש-token נכון בהגדרות.`
                : `✅ Engine פועל v${health.version}, uptime ${health.engineUptimeSec}s`,
              status.error
                ? `🔴 לא הצלחתי לקרוא status מ-Engine`
                : status.state === 'READY'
                  ? `✅ WhatsApp מחובר (${status.phone || ''})`
                  : `⚠️ WhatsApp במצב ${status.state}`
            ]
          }
        });
      });
      return true;
    }

    return false;
  });

  console.log(TAG, 'engine-client v0.15.1 loaded — proxies via background to local Engine');
})();
