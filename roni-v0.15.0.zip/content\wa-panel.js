// content/wa-panel.js — injects floating Roni button + slide-out panel into WhatsApp Web.
// v0.10.1: verbose diagnostics + MutationObserver to survive WA's React re-renders.

(function () {
  'use strict';

  const TAG = '[GetJob/wa-panel]';
  const STORAGE_OPEN_KEY = 'roni:waPanelOpen';
  const STORAGE_WIDTH_KEY = 'roni:waPanelWidth';

  console.log(TAG, 'script loaded, readyState=', document.readyState);

  function init() {
    try {
      console.log(TAG, 'init() starting');
      if (document.getElementById('roni-fab')) {
        console.log(TAG, 'fab already exists, skipping');
        return;
      }
      if (!document.body) {
        console.warn(TAG, 'document.body not ready, retrying in 500ms');
        setTimeout(init, 500);
        return;
      }
      injectFab();
      console.log(TAG, 'fab injected');
      injectPanel();
      console.log(TAG, 'panel injected');
      restoreState();
      installResurrector();
      console.log(TAG, '✅ all done');
    } catch (e) {
      console.error(TAG, '❌ init failed:', e);
      console.error(TAG, 'stack:', e.stack);
    }
  }

  function injectFab() {
    const btn = document.createElement('button');
    btn.id = 'roni-fab';
    btn.title = 'רוני · שליחת WhatsApp חכמה';
    // Roni logo: white R + spark dot, no background (FAB itself provides the peach circle)
    btn.innerHTML = `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <circle cx="48" cy="18" r="3.2" fill="#FFFFFF" opacity="0.95">
          <animate attributeName="opacity" values="0.6;1;0.6" dur="2.4s" repeatCount="indefinite"/>
        </circle>
        <g fill="#FFFFFF">
          <rect x="20" y="18" width="6.5" height="28" rx="2.5"/>
          <path d="M 26.5 18 L 35 18 C 42 18 45 22 45 27 C 45 32 42 35 35 35 L 26.5 35 L 26.5 29.5 L 34 29.5 C 37 29.5 38.5 28.5 38.5 26.5 C 38.5 24.5 37 23.5 34 23.5 L 26.5 23.5 Z"/>
          <path d="M 33 33 L 40.5 33 C 42 33 43 33.6 43.6 35 L 47 45 C 47.5 46.5 46.5 47.6 45 47.6 L 41.4 47.6 C 40.4 47.6 39.7 47 39.4 46 L 36 36.5 C 35.6 35.4 34.7 34.5 33.6 34.2 Z"/>
        </g>
      </svg>`;
    btn.addEventListener('click', togglePanel);
    document.body.appendChild(btn);
  }

  function injectPanel() {
    const container = document.createElement('div');
    container.id = 'roni-panel-container';

    const bar = document.createElement('div');
    bar.id = 'roni-panel-bar';
    bar.innerHTML = `
      <span class="title">רוני · כאן בשבילך</span>
      <button id="roni-panel-popout" title="פתח כחלון נפרד">↗</button>
      <button id="roni-panel-close" title="סגור">✕</button>
    `;

    const iframe = document.createElement('iframe');
    iframe.id = 'roni-panel-iframe';
    iframe.src = chrome.runtime.getURL('popup/popup.html?embed=wapanel');
    iframe.allow = 'clipboard-write';

    const resize = document.createElement('div');
    resize.id = 'roni-panel-resize';

    container.append(resize, bar, iframe);
    document.body.appendChild(container);

    bar.querySelector('#roni-panel-close').addEventListener('click', () => setOpen(false));
    bar.querySelector('#roni-panel-popout').addEventListener('click', () => {
      window.open(chrome.runtime.getURL('popup/popup.html'), '_blank',
        'width=520,height=720,toolbar=no,menubar=no');
    });

    initResize(resize, container);
  }

  function setOpen(open) {
    const c = document.getElementById('roni-panel-container');
    if (!c) return;
    c.classList.toggle('open', open);
    document.body.classList.toggle('roni-panel-open', open);
    try {
      chrome.storage.local.set({ [STORAGE_OPEN_KEY]: open });
    } catch (_) {}
  }

  function togglePanel() {
    const c = document.getElementById('roni-panel-container');
    if (!c) return;
    setOpen(!c.classList.contains('open'));
  }

  function initResize(handle, panel) {
    let dragging = false;
    let startX = 0;
    let startWidth = 0;
    handle.addEventListener('mousedown', (e) => {
      dragging = true;
      startX = e.clientX;
      startWidth = panel.getBoundingClientRect().width;
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dir = document.documentElement.dir === 'rtl' ? 1 : -1;
      const newWidth = Math.max(360, Math.min(720, startWidth + dir * (e.clientX - startX)));
      panel.style.width = newWidth + 'px';
    });
    window.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      document.body.style.userSelect = '';
      try {
        const w = panel.getBoundingClientRect().width;
        chrome.storage.local.set({ [STORAGE_WIDTH_KEY]: w });
      } catch (_) {}
    });
  }

  function restoreState() {
    try {
      chrome.storage.local.get([STORAGE_OPEN_KEY, STORAGE_WIDTH_KEY], (data) => {
        const c = document.getElementById('roni-panel-container');
        if (!c) return;
        if (data[STORAGE_WIDTH_KEY]) c.style.width = data[STORAGE_WIDTH_KEY] + 'px';
        if (data[STORAGE_OPEN_KEY]) setOpen(true);
      });
    } catch (_) {}
  }

  // Resurrect the FAB if WA Web's React removes it
  function installResurrector() {
    const obs = new MutationObserver(() => {
      if (!document.getElementById('roni-fab') || !document.getElementById('roni-panel-container')) {
        console.log(TAG, '🔄 resurrecting after DOM mutation');
        init();
      }
    });
    obs.observe(document.body, { childList: true, subtree: false });
  }

  // Keyboard shortcut Ctrl+Shift+R
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && (e.key === 'R' || e.key === 'r' || e.key === 'ר')) {
      e.preventDefault();
      togglePanel();
    }
  });

  // Multiple init attempts: WA's React may not have rendered yet.
  function scheduleInits() {
    [300, 1000, 2500, 5000].forEach(delay => setTimeout(init, delay));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleInits);
  } else {
    scheduleInits();
  }
})();
