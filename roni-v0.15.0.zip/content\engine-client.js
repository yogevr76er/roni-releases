// content/engine-client.js — replaces the old content-isolated.js + content-main.js.
// Thin client: receives chrome.runtime messages from popup/background,
// forwards them to local Roni Engine over HTTP. NO injection into WhatsApp Web.

(function () {
  'use strict';

  const TAG = '[GetJob/engine-client]';

  // Config keys read from chrome.storage.sync (set in popup Settings tab)
  const STORAGE_KEYS = {
    engineToken: 'roni:engineToken',
    enginePort: 'roni:enginePort'  // default 7341
  };

  async function getEngineConfig() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(
        [STORAGE_KEYS.engineToken, STORAGE_KEYS.enginePort],
        (data) => resolve({
          token: data[STORAGE_KEYS.engineToken] || '',
          port: data[STORAGE_KEYS.enginePort] || 7341
        })
      );
    });
  }

  async function engineFetch(path, { method = 'GET', body, timeout = 30000 } = {}) {
    const cfg = await getEngineConfig();
    const url = `http://127.0.0.1:${cfg.port}${path}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (cfg.token) headers['Authorization'] = `Bearer ${cfg.token}`;
      const res = await fetch(url, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined,
        signal: controller.signal
      });
      clearTimeout(timer);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw Object.assign(new Error(data.error || `HTTP_${res.status}`), {
          status: res.status,
          detail: data.detail || data.error
        });
      }
      return data;
    } catch (e) {
      clearTimeout(timer);
      if (e.name === 'AbortError') throw new Error('ENGINE_TIMEOUT');
      if (e.message?.includes('Failed to fetch') || e.message?.includes('NetworkError')) {
        throw new Error('ENGINE_UNREACHABLE');
      }
      throw e;
    }
  }

  // ---------- chrome.runtime message handlers ----------

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return false;

    if (msg.type === 'SEND_MESSAGE') {
      const clientAckId = msg.clientAckId || crypto.randomUUID();
      engineFetch('/send', {
        method: 'POST',
        body: { phone: msg.phone, text: msg.text, clientAckId },
        timeout: 60000
      })
        .then(result => sendResponse({
          success: true,
          result: {
            method: 'engine',
            ack: result.ack,
            msgId: result.messageId,
            clientAckId: result.clientAckId
          }
        }))
        .catch(err => sendResponse({
          success: false,
          error: err.message,
          detail: err.detail
        }));
      return true;
    }

    if (msg.type === 'GET_STATUS') {
      // Status is the Engine's WA state, not WA Web tab state
      engineFetch('/status', { timeout: 5000 })
        .then(status => sendResponse({
          success: true,
          result: {
            ready: status.state === 'READY',
            state: status.state,
            phone: status.phone,
            since: status.since
          }
        }))
        .catch(err => {
          // Engine unreachable → tell popup
          if (err.message === 'ENGINE_UNREACHABLE') {
            sendResponse({
              success: true,
              result: { ready: false, state: 'ENGINE_DOWN', error: err.message }
            });
          } else {
            sendResponse({ success: false, error: err.message });
          }
        });
      return true;
    }

    if (msg.type === 'EXTRACT_CHATS') {
      engineFetch('/extract-chats', {
        method: 'POST',
        body: msg.options || { limit: 200, includeGroups: true },
        timeout: 30000
      })
        .then(result => sendResponse({
          success: true,
          result: { chats: result.chats }
        }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (msg.type === 'GET_GROUP_MEMBERS') {
      engineFetch(`/group/${encodeURIComponent(msg.groupId)}/members`, { timeout: 15000 })
        .then(result => sendResponse({ success: true, result: { members: result.members } }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (msg.type === 'SEND_GROUP') {
      engineFetch('/send-group', {
        method: 'POST',
        body: { groupId: msg.groupId, text: msg.text },
        timeout: 60000
      })
        .then(result => sendResponse({ success: true, result }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (msg.type === 'ENGINE_HEALTH') {
      engineFetch('/health', { timeout: 3000 })
        .then(result => sendResponse({ success: true, result }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    // Legacy actions that no longer apply (REBUILD_STORE, RUN_DIAGNOSTIC) — return graceful no-op
    if (msg.type === 'REBUILD_STORE') {
      sendResponse({ success: true, result: { hasStore: false, mode: 'engine', note: 'Engine handles WA — no Store rebuild needed' } });
      return false;
    }
    if (msg.type === 'RUN_DIAGNOSTIC') {
      // Run engine health + status as a basic diagnostic
      Promise.all([
        engineFetch('/health', { timeout: 3000 }).catch(e => ({ error: e.message })),
        engineFetch('/status', { timeout: 5000 }).catch(e => ({ error: e.message }))
      ]).then(([health, status]) => {
        sendResponse({
          success: true,
          result: {
            capturedAt: new Date().toISOString(),
            version: '0.15.0',
            strategy: 'Engine HTTP (whatsapp-web.js)',
            engine: { health, status },
            recommendations: [
              health.error
                ? `🔴 Engine לא מגיב: ${health.error}. ודאי שה-Engine רץ בtray.`
                : `✅ Engine פועל v${health.version}, uptime ${health.engineUptimeSec}s`,
              status.error
                ? `🔴 לא הצלחתי לקרוא status מ-Engine`
                : status.state === 'READY'
                  ? `✅ WhatsApp מחובר (${status.phone || ''})`
                  : `⚠️ WhatsApp במצב ${status.state}`
            ]
          }
        });
      });
      return true;
    }

    return false;
  });

  console.log(TAG, 'engine-client loaded — sends will go to local Roni Engine');
})();
