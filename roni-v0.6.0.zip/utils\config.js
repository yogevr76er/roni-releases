// utils/config.js — Roni configuration. Edit this file when you set up GitHub hosting.
//
// Update flow:
// 1. Create a public GitHub repo (e.g., yogev/roni-releases).
// 2. Push two files to that repo's main branch:
//    - version.json   (metadata: latest version + download URL + release notes)
//    - roni-vX.Y.Z.zip (the actual extension ZIP from build.ps1)
// 3. Set RONI_CONFIG.updateCheckUrl below to:
//      https://raw.githubusercontent.com/<USER>/<REPO>/main/version.json
// 4. Set RONI_CONFIG.releasesBaseUrl to where ZIPs live (defaults to same repo /raw/main/).
//
// On every popup open, Roni fetches the JSON, compares to the manifest version,
// and shows a banner if a newer release is available.
// To DISABLE the updater entirely, set updateCheckUrl to null.

const RONI_CONFIG = {
  // GitHub repo identifiers — used to build raw URLs.
  // EDIT THESE TWO LINES with your GitHub username and repo name:
  githubUser: 'yogevr76er',
  githubRepo: 'roni-releases',

  // Derived URLs (you usually don't need to touch these).
  get updateCheckUrl() {
    return `https://raw.githubusercontent.com/${this.githubUser}/${this.githubRepo}/main/version.json`;
  },
  get releasesBaseUrl() {
    return `https://github.com/${this.githubUser}/${this.githubRepo}/raw/main/`;
  },

  // Don't pester the user more than once per N hours.
  updateCheckIntervalHours: 6,

  // ===== Central telemetry (Supabase) =====
  // Set both fields to enable shipping anonymized events to your Supabase.
  // Until set (or contains "CHANGE-ME"), the extension only logs locally.
  // The anon key is safe in client code as long as Row Level Security restricts
  // the roni_events table to INSERT-only for anon role.
  supabaseUrl: 'https://ysuxvvmgpcqnerlrdjpb.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlzdXh2dm1ncGNxbmVybHJkanBiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyNzUzODIsImV4cCI6MjA5MTg1MTM4Mn0.l2ECVYgq9Nzj8KGG2APWDGL97iqwz6eaV26agDCm-Rc'
};

if (typeof window !== 'undefined') window.RONI_CONFIG = RONI_CONFIG;
