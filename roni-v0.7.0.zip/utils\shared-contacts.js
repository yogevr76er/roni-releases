// utils/shared-contacts.js — central shared contact pool via Supabase.
// All coordinators read from + write to the same table. Phone is the key.

const SharedContacts = (() => {
  function isConfigured() {
    return RONI_CONFIG.supabaseUrl &&
           RONI_CONFIG.supabaseAnonKey &&
           !RONI_CONFIG.supabaseUrl.includes('CHANGE-ME');
  }

  function api(path, opts = {}) {
    const url = `${RONI_CONFIG.supabaseUrl.replace(/\/+$/, '')}/rest/v1/roni_shared_contacts${path}`;
    return fetch(url, {
      ...opts,
      headers: {
        'apikey': RONI_CONFIG.supabaseAnonKey,
        'Authorization': `Bearer ${RONI_CONFIG.supabaseAnonKey}`,
        'Content-Type': 'application/json',
        ...(opts.headers || {})
      }
    });
  }

  async function listAll({ search = '', limit = 1000 } = {}) {
    if (!isConfigured()) return [];
    let qs = `?select=*&order=updated_at.desc&limit=${limit}`;
    if (search) {
      const safe = encodeURIComponent(`%${search}%`);
      qs += `&or=(name.ilike.${safe},phone.ilike.${safe})`;
    }
    const res = await api(qs);
    if (!res.ok) throw new Error(`SHARED_LIST_${res.status}`);
    return res.json();
  }

  // Bulk upsert (insert or update on conflict).
  // contacts: [{ phone, name, source, source_id?, tags?, metadata?, added_by, added_by_name }]
  async function upsertMany(contacts) {
    if (!isConfigured()) throw new Error('NOT_CONFIGURED');
    if (!contacts || !contacts.length) return { count: 0 };

    // Chunk to avoid payload limits (~1000 rows per request)
    const CHUNK = 500;
    let totalUpserted = 0;
    for (let i = 0; i < contacts.length; i += CHUNK) {
      const chunk = contacts.slice(i, i + CHUNK);
      const res = await api('?on_conflict=phone', {
        method: 'POST',
        headers: {
          'Prefer': 'resolution=merge-duplicates,return=representation'
        },
        body: JSON.stringify(chunk)
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`SHARED_UPSERT_${res.status}: ${text.slice(0, 200)}`);
      }
      const rows = await res.json();
      totalUpserted += rows.length;
    }
    return { count: totalUpserted };
  }

  // Update last_messaged_* fields (called by background after a successful send)
  async function recordSend({ phone, coordinatorId, coordinatorName }) {
    if (!isConfigured()) return;
    const body = {
      last_messaged_at: new Date().toISOString(),
      last_messaged_by: coordinatorId
    };
    try {
      await api(`?phone=eq.${encodeURIComponent(phone)}`, {
        method: 'PATCH',
        body: JSON.stringify(body)
      });
    } catch (_) { /* non-fatal */ }
  }

  async function recordReply({ phone }) {
    if (!isConfigured()) return;
    try {
      await api(`?phone=eq.${encodeURIComponent(phone)}`, {
        method: 'PATCH',
        headers: { 'Prefer': 'return=minimal' },
        body: JSON.stringify({ updated_at: new Date().toISOString() })
      });
      // Increment via RPC would be cleaner; for now just touch updated_at.
    } catch (_) { /* non-fatal */ }
  }

  async function deleteByPhone(phone) {
    if (!isConfigured()) throw new Error('NOT_CONFIGURED');
    const res = await api(`?phone=eq.${encodeURIComponent(phone)}`, { method: 'DELETE' });
    if (!res.ok) throw new Error(`SHARED_DELETE_${res.status}`);
    return true;
  }

  // Convert shared row → Roni contact shape (for sending)
  function toContact(row, idx) {
    return {
      id: idx + 1,
      name: row.name || '',
      phone: row.phone,
      extra: { ...(row.metadata || {}), tags: (row.tags || []).join(', ') },
      status: 'pending',
      shared: true,
      sharedSource: row.source
    };
  }

  return { isConfigured, listAll, upsertMany, recordSend, recordReply, deleteByPhone, toContact };
})();

if (typeof window !== 'undefined') window.SharedContacts = SharedContacts;
