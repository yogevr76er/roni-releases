// utils/telemetry.js — ships event log entries to a central Supabase table.
// Privacy: NO message bodies, NO contact names, NO full phone numbers.
// Only metadata: event type, timestamps, counts, durations, masked phones (last 4 digits).
//
// Configure in utils/config.js: supabaseUrl + supabaseAnonKey.
// Coordinator identity: random UUID generated on first run, stored in chrome.storage.sync.

const Telemetry = (() => {
  const STORAGE_COORD_ID = 'roni:coordId';
  const STORAGE_COORD_NAME = 'roni:coordName';
  const STORAGE_LAST_SHIP = 'roni:telemetryLastShipAt';
  const STORAGE_FAILED_BUFFER = 'roni:telemetryRetryBuffer';
  const SHIP_INTERVAL_MS = 5 * 60 * 1000;  // ship every 5 min
  const MAX_BATCH = 200;

  // ---- coordinator identity ----
  function getCoordinatorId() {
    return new Promise((resolve) => {
      chrome.storage.sync.get([STORAGE_COORD_ID, STORAGE_COORD_NAME], (data) => {
        let id = data[STORAGE_COORD_ID];
        if (!id) {
          id = 'coord_' + (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));
          chrome.storage.sync.set({ [STORAGE_COORD_ID]: id });
        }
        resolve({ id, name: data[STORAGE_COORD_NAME] || '' });
      });
    });
  }

  function setCoordinatorName(name) {
    return new Promise((r) => chrome.storage.sync.set({ [STORAGE_COORD_NAME]: (name || '').trim() }, r));
  }

  // ---- enabled? ----
  function isEnabled() {
    return new Promise((r) => chrome.storage.sync.get(['roni:telemetryEnabled'], d => r(d['roni:telemetryEnabled'] !== false)));
  }
  function setEnabled(v) {
    return new Promise((r) => chrome.storage.sync.set({ 'roni:telemetryEnabled': !!v }, r));
  }

  function isConfigured() {
    return RONI_CONFIG.supabaseUrl &&
           RONI_CONFIG.supabaseAnonKey &&
           !RONI_CONFIG.supabaseUrl.includes('CHANGE-ME');
  }

  // ---- shipping ----
  // Convert a local event to a telemetry row. Strip anything risky.
  function toRow(coord, evt) {
    const { t, type, v, ...rest } = evt;
    // Whitelist of payload fields we ship — never ship anything outside this list
    const ALLOWED = [
      'method', 'ack', 'durationMs', 'error', 'phone', 'msgLen', 'source',
      'reason', 'risk', 'setting', 'value', 'enabled', 'start', 'end', 'days',
      'numVariants', 'success', 'intentLen', 'model', 'setId', 'name',
      'total', 'accepted', 'duplicates', 'invalid', 'cap'
    ];
    const payload = {};
    for (const k of ALLOWED) if (rest[k] !== undefined) payload[k] = rest[k];

    return {
      coordinator_id: coord.id,
      coordinator_name: coord.name || null,
      event_at: new Date(t).toISOString(),
      type,
      version: v || null,
      payload
    };
  }

  async function ship(events, opts = {}) {
    if (!isConfigured()) return { skipped: true, reason: 'NOT_CONFIGURED' };
    if (!await isEnabled() && !opts.force) return { skipped: true, reason: 'DISABLED' };
    if (!events || !events.length) return { skipped: true, reason: 'EMPTY' };

    const coord = await getCoordinatorId();
    const rows = events.map(e => toRow(coord, e));

    // Supabase REST endpoint — POST to /rest/v1/<table>
    const url = `${RONI_CONFIG.supabaseUrl.replace(/\/+$/, '')}/rest/v1/roni_events`;
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': RONI_CONFIG.supabaseAnonKey,
        'Authorization': `Bearer ${RONI_CONFIG.supabaseAnonKey}`,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify(rows)
    });

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`SUPABASE_${res.status}: ${text.slice(0, 200)}`);
    }
    return { shipped: rows.length };
  }

  // Ship events newer than `lastShipAt`, batched.
  async function shipPending() {
    if (!isConfigured()) return null;
    if (!(await isEnabled())) return null;

    const lastShipAt = await new Promise(r =>
      chrome.storage.local.get([STORAGE_LAST_SHIP], d => r(d[STORAGE_LAST_SHIP] || 0))
    );
    const allEvents = await EventLog.load();
    const pending = allEvents.filter(e => e.t > lastShipAt).slice(0, MAX_BATCH);
    if (!pending.length) return { shipped: 0 };

    try {
      const res = await ship(pending);
      const newestT = pending[pending.length - 1].t;
      await new Promise(r => chrome.storage.local.set({ [STORAGE_LAST_SHIP]: newestT }, r));
      return res;
    } catch (err) {
      // Don't advance lastShipAt — will retry next cycle
      return { error: err.message };
    }
  }

  // Schedule periodic shipping (call from popup init or service worker)
  let timer = null;
  function startAutoShipping() {
    if (timer) return;
    // Initial shot, then interval
    setTimeout(() => shipPending().catch(() => {}), 5000);
    timer = setInterval(() => shipPending().catch(() => {}), SHIP_INTERVAL_MS);
  }
  function stopAutoShipping() {
    if (timer) { clearInterval(timer); timer = null; }
  }

  return {
    getCoordinatorId, setCoordinatorName,
    isEnabled, setEnabled, isConfigured,
    ship, shipPending, startAutoShipping, stopAutoShipping
  };
})();

if (typeof window !== 'undefined') window.Telemetry = Telemetry;
