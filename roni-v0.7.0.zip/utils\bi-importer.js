// utils/bi-importer.js — fetches workers from getjob BI Apps Script API.
// Provides filtering and conversion to Roni's contact shape.

const BIImporter = (() => {
  const CACHE_KEY = 'roni:biCache';
  const CACHE_TTL_MS = 30 * 60 * 1000; // 30 min

  // Convert raw BI worker → Roni contact shape
  function toContact(w, idx) {
    const phone = String(w.w || '').replace(/\D/g, '');
    return {
      id: idx + 1,
      name: w.n || w.fn || '',
      phone,
      extra: {
        תפקידים: w.r || '',
        עיר: w.c || '',
        אזור: w.rg || '',
        סטטוס: w.s || '',
        מין: w.g === 'female' ? 'נקבה' : (w.g === 'male' ? 'זכר' : (w.g || '')),
        biId: w.id || '',
        biCreated: w.cr || '',
        biSrc: w.src || ''
      },
      status: 'pending',
      bi: true
    };
  }

  async function fetchAll({ force = false } = {}) {
    if (!force) {
      const cached = await new Promise(r =>
        chrome.storage.local.get([CACHE_KEY], d => r(d[CACHE_KEY]))
      );
      if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
        return { ...cached, fromCache: true };
      }
    }

    const url = RONI_CONFIG.biApiUrl;
    if (!url) throw new Error('BI_URL_NOT_CONFIGURED');

    const res = await fetch(url, { method: 'GET' });
    if (!res.ok) throw new Error(`BI_HTTP_${res.status}`);
    const json = await res.json();
    if (!json || !Array.isArray(json.data)) throw new Error('BI_BAD_FORMAT');

    const payload = {
      count: json.count || json.data.length,
      updated: json.updated || null,
      workers: json.data,
      fetchedAt: Date.now()
    };
    await chrome.storage.local.set({ [CACHE_KEY]: payload });
    return payload;
  }

  // Build filter facets (unique values per field with counts)
  function facets(workers) {
    const out = {
      status: new Map(),
      city: new Map(),
      region: new Map(),
      gender: new Map(),
      role: new Map()
    };
    for (const w of workers) {
      if (w.s) out.status.set(w.s, (out.status.get(w.s) || 0) + 1);
      if (w.c) out.city.set(w.c, (out.city.get(w.c) || 0) + 1);
      if (w.rg) out.region.set(w.rg, (out.region.get(w.rg) || 0) + 1);
      if (w.g) out.gender.set(w.g, (out.gender.get(w.g) || 0) + 1);
      if (w.r) {
        for (const role of String(w.r).split(',').map(s => s.trim()).filter(Boolean)) {
          out.role.set(role, (out.role.get(role) || 0) + 1);
        }
      }
    }
    const sortedEntries = (m) => [...m.entries()].sort((a, b) => b[1] - a[1]);
    return {
      status:  sortedEntries(out.status),
      city:    sortedEntries(out.city),
      region:  sortedEntries(out.region),
      gender:  sortedEntries(out.gender),
      role:    sortedEntries(out.role)
    };
  }

  // Apply filter object: {status:[], city:[], region:[], gender:[], role:[], textQuery:''}
  function applyFilter(workers, filter = {}) {
    const inSet = (val, arr) => !arr || !arr.length || arr.includes(val);
    const q = (filter.textQuery || '').trim().toLowerCase();
    return workers.filter(w => {
      if (!inSet(w.s, filter.status)) return false;
      if (!inSet(w.c, filter.city)) return false;
      if (!inSet(w.rg, filter.region)) return false;
      if (!inSet(w.g, filter.gender)) return false;
      if (filter.role && filter.role.length) {
        const hasAny = filter.role.some(r => String(w.r || '').includes(r));
        if (!hasAny) return false;
      }
      if (q) {
        const hay = `${w.n || ''} ${w.p || ''} ${w.c || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      // Must have valid Israeli mobile
      if (!/^9725\d{8}$/.test(String(w.w || ''))) return false;
      return true;
    });
  }

  return { fetchAll, facets, applyFilter, toContact };
})();

if (typeof window !== 'undefined') window.BIImporter = BIImporter;
