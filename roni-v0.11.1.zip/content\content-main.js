// content-main.js — runs in MAIN world of web.whatsapp.com.
// Responsible for: Store API injection (primary send path) and DOM fallback.
// Talks to content-isolated.js via window.postMessage.
//
// Inspired by whatsapp-web.js (MIT) — github.com/pedroslopez/whatsapp-web.js

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  // ---------- moduleRaid: capture every webpack module ----------
  // WA Web is a webpack bundle. We push a fake chunk that requires every module
  // and captures the module exports map. From there we search by signature.
  let modulesCache = null;

  function captureModules() {
    if (modulesCache) return modulesCache;

    // WA Web has used several webpack chunk names over time
    const candidates = Object.keys(window).filter(k =>
      k.startsWith('webpackChunk') || k.startsWith('webpackJsonp')
    );
    if (!candidates.length) return null;

    const modules = {};
    let success = false;

    for (const chunkName of candidates) {
      const chunk = window[chunkName];
      if (!chunk || typeof chunk.push !== 'function') continue;
      try {
        const chunkId = 'getjob_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
        chunk.push([
          [chunkId],
          {},
          (req) => {
            const ids = Object.keys(req.m || req.cache || {});
            for (const id of ids) {
              try {
                const mod = req(id);
                if (mod) modules[id] = mod;
              } catch (_) { /* skip individual broken modules */ }
            }
          }
        ]);
        if (Object.keys(modules).length > 0) { success = true; break; }
      } catch (e) {
        console.warn(TAG, `moduleRaid via ${chunkName} threw:`, e.message);
      }
    }

    if (!success || !Object.keys(modules).length) return null;
    modulesCache = modules;
    console.log(TAG, `moduleRaid captured ${Object.keys(modules).length} modules`);
    return modules;
  }

  // Wait for WA Web to finish loading webpack + bootstrapping
  async function waitForReady(timeoutMs = 30000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const has = Object.keys(window).some(k =>
        k.startsWith('webpackChunk') || k.startsWith('webpackJsonp')
      );
      if (has) {
        // Give it another beat to register all modules
        await sleep(500);
        return true;
      }
      await sleep(200);
    }
    return false;
  }

  // ---------- find specific Store pieces by signature ----------
  function findModule(modules, predicate) {
    for (const id of Object.keys(modules)) {
      const m = modules[id];
      if (!m) continue;
      try {
        if (predicate(m)) return m;
        if (m.default && predicate(m.default)) return m.default;
      } catch (_) { /* skip */ }
    }
    return null;
  }

  let Store = null;

  function buildStore() {
    if (Store) return Store;
    const modules = captureModules();
    if (!modules) return null;

    Store = {};

    // Chat collection — has .find / .get / ._models
    Store.Chat = findModule(modules, m =>
      m && m.Chat && typeof m.Chat.find === 'function'
    );
    if (Store.Chat) Store.Chat = Store.Chat.Chat;
    if (!Store.Chat) {
      Store.Chat = findModule(modules, m =>
        m && typeof m.find === 'function' && m._models &&
        m._models[0] && m._models[0].constructor && m._models[0].constructor.name === 'Chat'
      );
    }

    // Wid factory — modern path: WidFactory.createWid('123@c.us')
    Store.WidFactory = findModule(modules, m =>
      m && typeof m.createWid === 'function' && typeof m.createWidFromWidLike === 'function'
    );

    // SendMessage — the chat-instance .sendMessage method handles this for us,
    // but we also keep a reference to a direct sender for diagnostics.
    Store.SendTextMsgToChat = findModule(modules, m =>
      m && typeof m === 'function' && /SendTextMsgToChat|sendTextMsgToChat/.test(m.toString())
    );

    // Connection state — Stream.displayInfo === 'CONNECTED'
    Store.Stream = findModule(modules, m =>
      m && typeof m.displayInfo === 'string' && typeof m.mode === 'string'
    );

    // Number existence check (WapQuery in older builds, Wap2 in newer)
    Store.WapQuery = findModule(modules, m =>
      m && (typeof m.queryWidExists === 'function' || typeof m.queryExist === 'function')
    );

    // Msg collection — for reply detection. Backbone-ish: has .add event, .models
    Store.Msg = findModule(modules, m =>
      m && typeof m.on === 'function' && Array.isArray(m.models) &&
      m.models[0] && m.models[0].constructor && /Msg/.test(m.models[0].constructor.name)
    );

    return Store;
  }

  // ---------- Reply tracking ----------
  // We track sent messages by their msgId. When an inbound message comes from the
  // same chat (recipient), we record it as a reply with response_time.
  const sentRegistry = new Map(); // msgId -> { phone, sentAt, contactJid }
  let msgListenerAttached = false;

  function registerSent(msgId, phone, contactJid) {
    if (!msgId) return;
    sentRegistry.set(msgId, { phone, sentAt: Date.now(), contactJid });
    // GC: clean entries older than 7 days (don't leak memory)
    const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
    for (const [k, v] of sentRegistry.entries()) {
      if (v.sentAt < cutoff) sentRegistry.delete(k);
    }
  }

  function attachMsgListener() {
    if (msgListenerAttached) return;
    const S = buildStore();
    if (!S || !S.Msg || typeof S.Msg.on !== 'function') return;

    S.Msg.on('add', (msg) => {
      try {
        if (!msg || msg.id?.fromMe) return; // only inbound
        const fromJid = msg.from?._serialized || msg.from;
        if (!fromJid) return;
        // find latest sent to this contact within last 7 days
        const matches = [...sentRegistry.entries()]
          .filter(([_, v]) => v.contactJid === fromJid)
          .sort((a, b) => b[1].sentAt - a[1].sentAt);
        if (!matches.length) return;
        const [matchedMsgId, info] = matches[0];
        const responseTimeSec = Math.round((Date.now() - info.sentAt) / 1000);
        if (responseTimeSec > 7 * 24 * 3600) return; // too old, probably random

        // Notify isolated world
        window.postMessage({
          type: 'GETJOB_REPLY_DETECTED',
          payload: {
            phone: info.phone,
            originalMsgId: matchedMsgId,
            replyAt: Date.now(),
            responseTimeSec,
            replyLen: (msg.body || '').length
          }
        }, '*');
        sentRegistry.delete(matchedMsgId); // one-shot per send
      } catch (_) { /* ignore individual errors */ }
    });

    msgListenerAttached = true;
    console.log(TAG, 'Msg listener attached for reply tracking');
  }

  // ---------- send via Store (primary) ----------
  async function sendViaStore(phone, text) {
    // Wait for webpack to be ready (up to 15s) then retry build a few times
    let S = buildStore();
    if (!S || !S.Chat || !S.WidFactory) {
      const ready = await waitForReady(15000);
      if (!ready) throw new Error('STORE_UNAVAILABLE_NO_WEBPACK — WhatsApp Web עוד לא נטען. חכי 10 שניות ונסי שוב.');

      // Retry up to 5 times with delay
      for (let i = 0; i < 5; i++) {
        modulesCache = null; Store = null;
        S = buildStore();
        if (S && S.Chat && S.WidFactory) break;
        await sleep(1500);
      }

      if (!S || !S.Chat || !S.WidFactory) {
        throw new Error(`STORE_UNAVAILABLE — Store נבנה אבל חסרים מודולים: hasChat=${!!(S&&S.Chat)} hasWidFactory=${!!(S&&S.WidFactory)}. ייתכן שWhatsApp שינה את הbundle. נסי "הער את רוני".`);
      }
    }

    const jid = `${phone}@c.us`;
    const wid = S.WidFactory.createWid(jid);

    // verify number exists on WhatsApp before opening a chat
    if (S.WapQuery) {
      try {
        const q = S.WapQuery.queryWidExists || S.WapQuery.queryExist;
        const res = await q(wid);
        const exists = res && (res.wid || res.jid || res === true);
        if (!exists) throw new Error('NUMBER_NOT_ON_WHATSAPP');
      } catch (e) {
        if (e.message === 'NUMBER_NOT_ON_WHATSAPP') throw e;
        // queryExists itself failed — proceed anyway, Chat.find may still work
      }
    }

    let chat = S.Chat.get && S.Chat.get(wid);
    if (!chat) {
      chat = await S.Chat.find(wid);
    }
    if (!chat) throw new Error('CHAT_NOT_FOUND');

    // sendMessage on the chat model — returns an ack-bearing object
    const result = await chat.sendMessage(text);
    const msgId = (result && result.id && result.id._serialized) || null;

    // Register for reply tracking
    if (msgId) registerSent(msgId, phone, jid);

    return {
      method: 'store',
      ack: (result && result.ack) ?? null,
      msgId
    };
  }

  // ---------- DOM fallback (no wa.me/send) ----------
  // Find chat via the in-app search box, then type into compose box and Enter.
  async function sendViaDom(phone, text) {
    // Try multiple selector patterns — WA Web shifts these by version
    function findSearchBox() {
      const selectors = [
        // Modern textbox patterns
        'div[role="textbox"][contenteditable="true"][data-tab="3"]',
        'div[role="textbox"][contenteditable="true"][data-tab="4"]',
        // By aria-label (Hebrew)
        'div[contenteditable="true"][aria-label*="חיפוש"]',
        'div[contenteditable="true"][aria-label*="צ\'אט"]',
        // By aria-label (English)
        'div[contenteditable="true"][aria-label*="Search"]',
        // Generic — first contenteditable in side panel
        'div[role="textbox"][contenteditable="true"]'
      ];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) return el;
      }
      return null;
    }

    function findSearchButton() {
      const selectors = [
        '[aria-label="חיפוש או צ\'אט חדש"]',
        '[aria-label="Search or start new chat"]',
        '[aria-label*="חיפוש"][role="button"]',
        '[aria-label*="Search"][role="button"]',
        'button[title*="חיפוש"]',
        'button[title*="Search"]'
      ];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) return el;
      }
      return null;
    }

    let searchBox = findSearchBox();
    if (!searchBox) {
      const searchBtn = findSearchButton();
      if (searchBtn) {
        searchBtn.click();
        await sleep(500);
        searchBox = findSearchBox();
      }
    }
    if (!searchBox) {
      throw new Error('SEARCH_BOX_NOT_FOUND — לא מצאתי את תיבת החיפוש של WhatsApp. ייתכן ש-WhatsApp עוד לא נטען מלא או ששינו את ה-DOM.');
    }

    searchBox.focus();
    document.execCommand('insertText', false, phone);
    await sleep(800);

    // Press Enter on the first matching contact (WA opens it)
    const firstResult = document.querySelector('[role="listitem"][tabindex="-1"]') ||
                        document.querySelector('div[role="grid"] [role="row"]');
    if (!firstResult) throw new Error('NO_CONTACT_MATCH');
    firstResult.click();
    await sleep(700);

    // Compose box
    const compose = document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="10"]') ||
                    document.querySelector('footer div[contenteditable="true"]');
    if (!compose) throw new Error('COMPOSE_NOT_FOUND');
    compose.focus();

    // Type one char at a time with jitter (slightly more human than paste)
    for (const ch of text) {
      document.execCommand('insertText', false, ch);
      await sleep(40 + Math.random() * 80);
    }
    await sleep(300);

    // Enter to send
    compose.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(800);
    return { method: 'dom', ack: null, msgId: null };
  }

  // ---------- top-level send: hybrid ----------
  async function send(phone, text) {
    try {
      return await sendViaStore(phone, text);
    } catch (storeErr) {
      console.warn(TAG, 'Store failed, falling back to DOM:', storeErr.message);
      try {
        const r = await sendViaDom(phone, text);
        r.storeError = storeErr.message;
        return r;
      } catch (domErr) {
        throw new Error(`STORE_AND_DOM_FAILED: store=${storeErr.message} dom=${domErr.message}`);
      }
    }
  }

  // ---------- Chat extraction (for WA contact import) ----------
  function extractChats(opts = {}) {
    const S = buildStore();
    if (!S) throw new Error('STORE_NOT_BUILT — webpack modules not captured. Try refreshing WA Web.');
    if (!S.Chat) throw new Error('STORE.CHAT_NOT_FOUND — WhatsApp module signatures may have changed.');
    if (!Array.isArray(S.Chat.models)) {
      throw new Error('STORE.CHAT.MODELS_NOT_ARRAY — chat list not loaded yet. Wait a few seconds.');
    }
    if (S.Chat.models.length === 0) {
      throw new Error('NO_CHATS_LOADED — chat list is empty. Open a chat in WhatsApp first to trigger loading.');
    }

    const limit = opts.limit || 500;
    const includeGroups = !!opts.includeGroups;
    const out = [];

    for (const chat of S.Chat.models) {
      if (out.length >= limit) break;
      try {
        const id = chat.id;
        const isGroup = id?._serialized?.endsWith('@g.us') || chat.isGroup;
        if (isGroup && !includeGroups) continue;
        const jid = id?._serialized || '';
        const phoneMatch = jid.match(/^(\d+)@c\.us$/);
        if (!phoneMatch) continue;
        const phone = phoneMatch[1];
        const name = chat.name || chat.formattedTitle || chat.contact?.name || chat.contact?.pushname || '';
        if (!name) continue;
        out.push({
          name,
          phone,
          isGroup: false,
          unread: chat.unreadCount || 0,
          lastMessageAt: chat.t ? chat.t * 1000 : null
        });
      } catch (_) { /* skip */ }
    }
    return out.sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
  }

  function getConnectionState() {
    const S = buildStore();
    if (!S || !S.Stream) return 'unknown';
    return S.Stream.displayInfo || 'unknown';
  }

  function isReady() {
    return getConnectionState() === 'CONNECTED';
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- bridge: window.postMessage <-> isolated world ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;

    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        respond({ ok: true, result: { ready: isReady(), state: getConnectionState() } });
      } else if (action === 'rebuildStore') {
        modulesCache = null;
        Store = null;
        const S = buildStore();
        respond({ ok: true, result: { hasStore: !!S, hasChat: !!(S && S.Chat) } });
      } else if (action === 'extractChats') {
        try {
          const chats = extractChats(payload);
          respond({ ok: true, result: { chats } });
        } catch (e) {
          respond({ ok: false, error: e.message });
        }
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  // attempt eager Store build once page is interactive, then attach msg listener
  const tryInit = () => {
    try {
      buildStore();
      attachMsgListener();
      // retry attach for a minute (Store.Msg sometimes appears later)
      let tries = 0;
      const iv = setInterval(() => {
        if (msgListenerAttached || ++tries > 12) { clearInterval(iv); return; }
        try { attachMsgListener(); } catch (_) {}
      }, 5000);
    } catch (_) {}
  };
  if (document.readyState === 'complete') {
    setTimeout(tryInit, 2000);
  } else {
    window.addEventListener('load', () => setTimeout(tryInit, 2000));
  }

  console.log(TAG, 'injected (MAIN world)');
})();
