// popup.js — v0.3.0: contacts + template library + AI generation + settings.

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const STORAGE_KEYS = {
  contacts: 'roni:contacts',
  contactsStats: 'roni:contactsStats'
};

let state = {
  contacts: [],
  stats: null,
  sets: [],         // template library
  activeId: null,   // active set id
  aiResult: null    // last AI generation result, awaiting save
};

// ---------- storage ----------
function loadContactsState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEYS.contacts, STORAGE_KEYS.contactsStats], (data) => {
      state.contacts = data[STORAGE_KEYS.contacts] || [];
      state.stats = data[STORAGE_KEYS.contactsStats] || null;
      resolve();
    });
  });
}

function saveContacts() {
  chrome.storage.local.set({
    [STORAGE_KEYS.contacts]: state.contacts,
    [STORAGE_KEYS.contactsStats]: state.stats
  });
}

async function loadLibrary() {
  const { sets, activeId } = await TemplateLibrary.load();
  state.sets = sets;
  state.activeId = activeId;
}

async function saveLibrary() {
  await TemplateLibrary.save(state.sets, state.activeId);
}

function activeSet() {
  return state.sets.find(s => s.id === state.activeId);
}

// ---------- WA Web tab + status ----------
async function getWaTab() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  return tabs[0] || null;
}

async function refreshStatus() {
  const badge = $('#wa-status');
  badge.textContent = 'בודק...';
  badge.className = 'badge';
  const tab = await getWaTab();
  if (!tab) {
    badge.textContent = 'WA Web לא פתוח';
    badge.classList.add('err');
    return;
  }
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' });
    if (resp && resp.success && resp.result.ready) {
      badge.textContent = 'מחובר';
      badge.classList.add('ok');
    } else {
      badge.textContent = resp?.result?.state || 'לא מוכן';
      badge.classList.add('warn');
    }
  } catch {
    badge.textContent = 'שגיאה';
    badge.classList.add('err');
  }
}

// ---------- tabs ----------
function activateTab(name) {
  $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  $$('.tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${name}`));
  if (name === 'preview') renderPreview();
  if (name === 'settings') renderSettings();
}

// ---------- contacts ----------
async function handleFile(evt) {
  const file = evt.target.files && evt.target.files[0];
  if (!file) return;
  try {
    const { contacts, stats } = await ContactParser.parseFile(file);
    state.contacts = contacts;
    state.stats = stats;
    saveContacts();
    renderContacts();
    updateTabCounts();
  } catch (err) {
    const msg = errMessage(err.message);
    $('#contacts-summary').className = 'summary visible';
    $('#contacts-summary').innerHTML = `<span class="stat err">רוני: ${msg}</span>`;
  }
}

function errMessage(code) {
  const map = {
    NO_SHEET: 'לא נמצאה טבלה בקובץ',
    MISSING_NAME_COLUMN: 'חסרה עמודת "שם" / "name"',
    MISSING_PHONE_COLUMN: 'חסרה עמודת "טלפון" / "phone"',
    FILE_READ_ERROR: 'לא הצלחתי לקרוא את הקובץ'
  };
  return map[code] || code;
}

function renderContacts() {
  const list = $('#contacts-list');
  const summary = $('#contacts-summary');
  if (!state.contacts.length) {
    list.innerHTML = '';
    summary.className = 'summary';
    summary.innerHTML = '';
    return;
  }
  const s = state.stats || {};
  const parts = [`<span class="stat ok">✔ נטענו: ${s.accepted ?? state.contacts.length}</span>`];
  if (s.duplicate)    parts.push(`<span class="stat warn">כפולים: ${s.duplicate}</span>`);
  if (s.invalidPhone) parts.push(`<span class="stat warn">טלפון לא תקין: ${s.invalidPhone}</span>`);
  if (s.missingName)  parts.push(`<span class="stat warn">חסר שם: ${s.missingName}</span>`);
  if (s.missingPhone) parts.push(`<span class="stat warn">חסר טלפון: ${s.missingPhone}</span>`);
  summary.className = 'summary visible';
  summary.innerHTML = parts.join('');

  list.innerHTML = state.contacts.map(c => `
    <div class="contact-row">
      <span class="status status-${c.status}">${statusText(c.status)}</span>
      <span class="name">${escapeHtml(c.name)}</span>
      <span class="phone">${c.phone}</span>
    </div>
  `).join('');
}

function statusText(s) {
  return ({ pending: 'ממתין', sent: 'נשלח', failed: 'נכשל', skipped: 'דולג' })[s] || s;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function clearContacts() {
  if (!state.contacts.length) return;
  if (!confirm(`רוני ימחק את ${state.contacts.length} אנשי הקשר. להמשיך?`)) return;
  state.contacts = [];
  state.stats = null;
  saveContacts();
  renderContacts();
  updateTabCounts();
}

// ---------- template library ----------
function renderSetsList() {
  const list = $('#sets-list');
  list.innerHTML = state.sets.map(s => `
    <div class="set-chip ${s.id === state.activeId ? 'active' : ''}" data-id="${s.id}">
      <span class="icon">${s.icon || '💬'}</span>
      <span class="name">${escapeHtml(s.name)}</span>
      <span class="count">${s.templates.length}</span>
    </div>
  `).join('');
  list.querySelectorAll('.set-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      state.activeId = chip.dataset.id;
      await saveLibrary();
      renderSetsList();
      renderSetEditor();
      updateTabCounts();
    });
  });
}

function renderSetEditor() {
  const card = $('#set-editor-card');
  const set = activeSet();
  if (!set) { card.style.display = 'none'; return; }
  card.style.display = 'block';

  $('#active-set-title').textContent = `${set.icon || '💬'} ${set.name}`;
  $('#set-name').value = set.name;
  $('#set-icon').value = set.icon || '';
  $('#btn-delete-set').style.display = set.builtin ? 'none' : 'block';

  const editor = $('#templates-editor');
  editor.innerHTML = set.templates.map((t, i) => `
    <div class="template-editor" data-idx="${i}">
      <div class="row">
        <span>וריאציה ${i + 1}</span>
        <button class="btn-danger" data-action="del" data-idx="${i}">מחק</button>
      </div>
      <textarea data-idx="${i}" rows="3">${escapeHtml(t)}</textarea>
      <div class="meta">
        <span data-meta-count="${i}">${(t || '').length} תווים</span>
        <span data-meta-vars="${i}">משתנים: ${TemplateEngine.extractVars(t).join(', ') || '—'}</span>
      </div>
    </div>
  `).join('');

  editor.querySelectorAll('textarea').forEach(ta => {
    ta.addEventListener('input', e => {
      const idx = +e.target.dataset.idx;
      set.templates[idx] = e.target.value;
      const t = e.target.value;
      $(`[data-meta-count="${idx}"]`).textContent = `${t.length} תווים`;
      $(`[data-meta-vars="${idx}"]`).textContent = `משתנים: ${TemplateEngine.extractVars(t).join(', ') || '—'}`;
      validateActiveSetUI();
    });
  });
  editor.querySelectorAll('[data-action="del"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = +e.target.dataset.idx;
      if (set.templates.length <= 1) { alert('סט חייב לפחות וריאציה אחת'); return; }
      set.templates.splice(idx, 1);
      renderSetEditor();
      validateActiveSetUI();
    });
  });

  validateActiveSetUI();
}

function validateActiveSetUI() {
  const set = activeSet();
  if (!set) return;
  const v = TemplateEngine.validateTemplates(set.templates);
  const box = $('#templates-validation');
  const msgs = [];
  if (v.errors.length) {
    box.className = 'validation-box has-errors';
    msgs.push('<strong>רוני מצא בעיות:</strong>');
    msgs.push('<ul>' + v.errors.map(e => `<li>${escapeHtml(e)}</li>`).join('') + '</ul>');
  } else if (v.warnings.length) {
    box.className = 'validation-box has-warnings';
    msgs.push('<strong>רוני מציע לבדוק:</strong>');
    msgs.push('<ul>' + v.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('') + '</ul>');
  } else {
    box.className = 'validation-box ok';
    msgs.push(`<strong>✔ ${v.count} וריאציות תקינות</strong>`);
  }
  box.innerHTML = msgs.join('');
}

async function saveActiveSet() {
  const set = activeSet();
  if (!set) return;
  set.name = $('#set-name').value.trim() || set.name;
  set.icon = $('#set-icon').value.trim() || set.icon;
  set.templates = set.templates.map(t => (t || '').trim()).filter(Boolean);
  if (!set.templates.length) set.templates = ['שלום {{שם}}'];
  set.updatedAt = Date.now();
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
  flash('הסט נשמר', 'ok');
}

function addVariantToActive() {
  const set = activeSet();
  if (!set) return;
  set.templates.push("שלום {{שם}}, רוני מגטג'וב 🙋");
  renderSetEditor();
}

async function deleteActiveSet() {
  const set = activeSet();
  if (!set || set.builtin) return;
  if (!confirm(`רוני ימחק את הסט "${set.name}". להמשיך?`)) return;
  state.sets = state.sets.filter(s => s.id !== state.activeId);
  state.activeId = state.sets[0].id;
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
}

async function newEmptySet() {
  const newSet = TemplateLibrary.createSet({
    name: 'סט חדש',
    icon: '💬',
    templates: [`שלום {{שם}}, רוני מגטג'וב 🙋`]
  });
  state.sets.push(newSet);
  state.activeId = newSet.id;
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
}

function flash(msg, kind) {
  const box = $('#templates-validation');
  box.className = `validation-box ${kind === 'ok' ? 'ok' : 'has-errors'}`;
  box.innerHTML = `<strong>${escapeHtml(msg)}</strong>`;
  setTimeout(validateActiveSetUI, 1500);
}

// ---------- preview ----------
function renderPreview() {
  const list = $('#preview-list');
  const meta = $('#preview-meta');
  const set = activeSet();

  if (!set) { list.innerHTML = ''; meta.textContent = 'אין סט פעיל.'; return; }

  meta.innerHTML = `סט פעיל: <strong>${set.icon} ${escapeHtml(set.name)}</strong> (${set.templates.length} וריאציות)`;

  if (!state.contacts.length) {
    list.innerHTML = '<div class="hint" style="padding:8px;">טען קודם אנשי קשר בטאב "אנשי קשר".</div>';
    return;
  }

  const valid = set.templates.filter(t => t && t.trim());
  if (!valid.length) {
    list.innerHTML = '<div class="hint" style="padding:8px;">אין וריאציות פעילות בסט.</div>';
    return;
  }

  const rotator = new TemplateEngine.Rotator(valid);
  const sample = state.contacts.slice(0, 5);
  list.innerHTML = sample.map(c => {
    const { index, text } = rotator.renderForContact(c);
    return `
      <div class="preview-item">
        <div class="head">
          <span>📱 ${escapeHtml(c.name)} · ${c.phone}</span>
          <span>וריאציה #${index + 1}</span>
        </div>${escapeHtml(text)}
      </div>`;
  }).join('');
}

// ---------- AI modal ----------
function openAiModal() {
  $('#ai-modal').style.display = 'flex';
  $('#ai-status').style.display = 'none';
  $('#ai-results').style.display = 'none';
  $('#ai-intent').focus();
}

function closeAiModal() {
  $('#ai-modal').style.display = 'none';
  state.aiResult = null;
}

function showAiStatus(msg, ok) {
  const box = $('#ai-status');
  box.style.display = 'block';
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

async function aiGenerate(numVariants) {
  const intent = $('#ai-intent').value.trim();
  if (!intent) { showAiStatus('תאר תחילה מה אתה רוצה לשלוח', false); return; }

  const settings = await AIGenerator.getSettings();
  if (!settings.apiKey) {
    showAiStatus('לא הוגדר מפתח API. עבור להגדרות והוסף.', false);
    return;
  }

  showAiStatus('רוני חושב... ⏳', true);
  $('#ai-generate').disabled = true;
  $('#ai-generate-3').disabled = true;

  try {
    const result = await AIGenerator.generateVariants(intent, { numVariants });
    state.aiResult = result;
    showAiStatus(`✔ רוני יצר ${result.templates.length} וריאציות (מודל: ${result.model})`, true);
    renderAiResult(result);
  } catch (err) {
    showAiStatus('רוני נכשל: ' + AIGenerator.errMessage(err.message), false);
  } finally {
    $('#ai-generate').disabled = false;
    $('#ai-generate-3').disabled = false;
  }
}

function renderAiResult(result) {
  $('#ai-results').style.display = 'block';
  $('#ai-set-name').value = result.name;
  $('#ai-set-icon').value = result.icon;

  const list = $('#ai-variants');
  list.innerHTML = result.templates.map((t, i) => `
    <div class="variant" data-idx="${i}">
      <div class="head">
        <span>וריאציה ${i + 1}</span>
        <span>${(t || '').length} תווים</span>
      </div>
      <textarea data-idx="${i}" rows="3">${escapeHtml(t)}</textarea>
    </div>
  `).join('');

  list.querySelectorAll('textarea').forEach(ta => {
    ta.addEventListener('input', e => {
      const idx = +e.target.dataset.idx;
      state.aiResult.templates[idx] = e.target.value;
      e.target.parentElement.querySelector('.head span:last-child').textContent =
        `${e.target.value.length} תווים`;
    });
  });
}

async function aiSaveAsSet() {
  if (!state.aiResult) return;
  const name = $('#ai-set-name').value.trim() || state.aiResult.name;
  const icon = $('#ai-set-icon').value.trim() || state.aiResult.icon;
  const templates = state.aiResult.templates.map(t => (t || '').trim()).filter(Boolean);

  // Validate every template has {{שם}}
  const v = TemplateEngine.validateTemplates(templates);
  if (v.errors.length) {
    if (!confirm('יש בעיות בתבניות:\n\n' + v.errors.join('\n') + '\n\nלשמור בכל זאת?')) return;
  }

  const newSet = TemplateLibrary.createSet({
    name, icon, templates,
    intent: state.aiResult.intent,
    model: state.aiResult.model
  });
  state.sets.push(newSet);
  state.activeId = newSet.id;
  await saveLibrary();
  closeAiModal();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
}

// ---------- settings ----------
async function renderSettings() {
  const s = await AIGenerator.getSettings();
  $('#api-key').value = s.apiKey || '';
  $('#ai-model').value = s.model || AIGenerator.DEFAULT_MODEL;
}

async function saveSettings() {
  const apiKey = $('#api-key').value.trim();
  const model = $('#ai-model').value;
  await AIGenerator.saveSettings({ apiKey, model });
  showSettingsResult('הגדרות נשמרו ✔', true);
}

async function testApi() {
  const box = $('#settings-result');
  box.textContent = 'בודק חיבור ל-Claude...';
  box.className = 'result-box';
  try {
    const result = await AIGenerator.generateVariants(
      'הודעת בדיקה קצרה לעובד שביקש פרטים על משמרת',
      { numVariants: 1 }
    );
    showSettingsResult(`✔ חיבור תקין!\nמודל: ${result.model}\nדוגמת וריאציה:\n${result.templates[0]}`, true);
  } catch (err) {
    showSettingsResult('רוני נכשל: ' + AIGenerator.errMessage(err.message), false);
  }
}

function showSettingsResult(msg, ok) {
  const box = $('#settings-result');
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

// ---------- test tab ----------
function showResult(msg, ok) {
  const box = $('#result');
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

async function sendOne() {
  const phone = $('#test-phone').value.replace(/\D/g, '');
  const text = $('#test-text').value.trim();
  const btn = $('#btn-send-one');
  if (!phone || phone.length < 9) { showResult('רוני אומר: טלפון לא תקין', false); return; }
  if (!text) { showResult('רוני אומר: ההודעה ריקה', false); return; }
  const tab = await getWaTab();
  if (!tab) { showResult('רוני צריך שתפתח קודם את web.whatsapp.com', false); return; }
  btn.disabled = true;
  showResult('רוני שולח...', true);
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'SEND_MESSAGE', phone, text });
    if (resp && resp.success) {
      showResult(`רוני: נשלח ✔\nשיטה: ${resp.result.method}\nack: ${resp.result.ack ?? '—'}\nmsgId: ${resp.result.msgId ?? '—'}`, true);
    } else {
      showResult(`רוני נתקל בבעיה: ${resp?.error || 'לא ידוע'}`, false);
    }
  } catch (err) {
    showResult(`רוני לא הצליח לתקשר: ${err.message}`, false);
  } finally {
    btn.disabled = false;
  }
}

async function rebuildStore() {
  const tab = await getWaTab();
  if (!tab) { showResult('רוני צריך שתפתח קודם את web.whatsapp.com', false); return; }
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'REBUILD_STORE' });
    if (resp && resp.success) {
      showResult(`רוני התעורר: hasStore=${resp.result.hasStore} hasChat=${resp.result.hasChat}`, resp.result.hasChat);
    } else {
      showResult(`רוני לא הצליח להתעורר: ${resp?.error || 'לא ידוע'}`, false);
    }
  } catch (err) {
    showResult(`רוני נתקל בשגיאה: ${err.message}`, false);
  }
}

// ---------- tab counts ----------
function updateTabCounts() {
  $('#tab-count-contacts').textContent = state.contacts.length || '';
  const set = activeSet();
  $('#tab-count-templates').textContent = set ? set.templates.length : '';
}

// ---------- init ----------
document.addEventListener('DOMContentLoaded', async () => {
  await loadContactsState();
  await loadLibrary();

  $$('.tab').forEach(t => t.addEventListener('click', () => activateTab(t.dataset.tab)));

  // contacts
  $('#file-upload').addEventListener('change', handleFile);
  $('#btn-clear-contacts').addEventListener('click', clearContacts);

  // templates / library
  $('#btn-new-set').addEventListener('click', newEmptySet);
  $('#btn-add-template').addEventListener('click', addVariantToActive);
  $('#btn-save-set').addEventListener('click', saveActiveSet);
  $('#btn-delete-set').addEventListener('click', deleteActiveSet);

  // AI modal
  $('#btn-ai-create').addEventListener('click', openAiModal);
  $('#ai-modal-close').addEventListener('click', closeAiModal);
  $('#ai-generate').addEventListener('click', () => aiGenerate(5));
  $('#ai-generate-3').addEventListener('click', () => aiGenerate(3));
  $('#ai-regenerate').addEventListener('click', () => aiGenerate(state.aiResult?.templates?.length || 5));
  $('#ai-save').addEventListener('click', aiSaveAsSet);
  $('#ai-modal').addEventListener('click', (e) => {
    if (e.target.id === 'ai-modal') closeAiModal();
  });

  // settings
  $('#btn-save-settings').addEventListener('click', saveSettings);
  $('#btn-test-api').addEventListener('click', testApi);

  // preview
  $('#btn-refresh-preview').addEventListener('click', renderPreview);

  // test
  $('#btn-send-one').addEventListener('click', sendOne);
  $('#btn-rebuild-store').addEventListener('click', rebuildStore);
  $('#btn-refresh-status').addEventListener('click', refreshStatus);

  renderContacts();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
  refreshStatus();
  initUpdater();
});

// ---------- updater ----------
async function initUpdater() {
  // Show actual manifest version in header
  const v = chrome.runtime.getManifest().version;
  $('#version').textContent = `v${v}`;

  let result;
  try { result = await Updater.check(); } catch { return; }
  if (!result || !result.hasUpdate) return;

  const dismissedKey = 'roni:updateDismissed:' + result.latest;
  const dismissed = await new Promise(r => chrome.storage.local.get([dismissedKey], d => r(d[dismissedKey])));
  if (dismissed && !result.mandatory) return;

  const banner = $('#update-banner');
  const msg = banner.querySelector('.update-msg');
  const link = $('#update-link');

  msg.innerHTML = `<strong>🆕 גרסה ${escapeHtml(result.latest)} זמינה</strong>
    <small>אחרי הורדה: חלץ ל-<code>C:\\Roni\\</code> ולחץ Ctrl+R</small>`;

  if (result.downloadUrl) {
    link.href = result.downloadUrl;
    link.style.display = '';
  } else {
    link.style.display = 'none';
  }
  banner.style.display = 'flex';

  $('#update-dismiss').addEventListener('click', () => {
    chrome.storage.local.set({ [dismissedKey]: true });
    banner.style.display = 'none';
  });
}
