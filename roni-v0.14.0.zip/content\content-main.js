// content-main.js — runs in MAIN world of web.whatsapp.com.
// v0.14.0: Store-based sender with PROPER TIMING (learned from Joni source code).
//
// Key insight (lesson_no_parasitic_push.md, corrected):
// Parasitic chunk push is FINE — but ONLY after WA Web is fully ready.
// Doing it at document_start corrupts WA's webpack init. Doing it after
// WA renders its UI is what every working extension does (Joni, whatsapp-web.js).

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- DOM signals: when is WA ready? ----------
  function waIsReady() {
    // WA is "ready" when the chat list is rendered (means webpack finished init)
    return !!(
      document.querySelector('div[role="grid"][aria-label]') ||
      document.querySelector('[data-list-scroll-container]') ||
      document.querySelector('header input[type="text"]')
    );
  }

  async function waitForWaReady(timeoutMs = 60000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (waIsReady()) {
        console.log(TAG, `WA ready after ${Date.now()-start}ms`);
        // Extra grace for any late-loading modules
        await sleep(800);
        return true;
      }
      await sleep(300);
    }
    return false;
  }

  // ---------- moduleRaid (Joni-style, on-demand only) ----------
  let modules = null;

  async function captureModules() {
    if (modules) return modules;
    if (!waIsReady()) {
      const ok = await waitForWaReady(30000);
      if (!ok) throw new Error('WA_NOT_READY_30S');
    }
    // Joni's exact pattern — 2 chunk name candidates
    const chunk =
      window.webpackChunkbuild ||
      window.webpackChunkwhatsapp_web_client;
    if (!chunk) throw new Error('NO_WEBPACK_CHUNK');

    const captured = [];
    chunk.push([
      [Date.now()],
      {},
      (req) => {
        const ids = Object.keys(req.m || {});
        for (const id of ids) {
          try { const mod = req(id); if (mod) captured.push(mod); }
          catch (_) { /* skip */ }
        }
      }
    ]);
    if (!captured.length) throw new Error('NO_MODULES_CAPTURED');
    modules = captured;
    console.log(TAG, `Captured ${captured.length} modules`);
    return modules;
  }

  function findModule(predicate) {
    if (!modules) return null;
    for (const m of modules) {
      try {
        if (predicate(m)) return m;
        if (m?.default && predicate(m.default)) return m.default;
      } catch (_) {}
    }
    return null;
  }

  // ---------- Store: lazy-resolve via signatures (Joni-tested) ----------
  let Store = null;
  async function getStore() {
    if (Store && Store.WidFactory && Store.Chat && Store.SendMessage) return Store;
    await captureModules();

    Store = Store || {};

    // WidFactory — modern: createWid('phone@c.us')
    Store.WidFactory = Store.WidFactory || findModule(m =>
      typeof m?.createWid === 'function' && typeof m?.createWidFromWidLike === 'function'
    );

    // Chat collection
    Store.Chat = Store.Chat || (() => {
      // Try .Chat.find pattern
      const m1 = findModule(m => m?.Chat && typeof m.Chat.find === 'function');
      if (m1?.Chat) return m1.Chat;
      // Try direct find with _models array of Chat instances
      return findModule(m =>
        typeof m?.find === 'function' && Array.isArray(m?.models) &&
        m.models[0]?.constructor?.name === 'Chat'
      );
    })();

    // formatPhone — normalizes a phone string for WA
    Store.formatPhone = Store.formatPhone || findModule(m =>
      typeof m?.formatPhone === 'function'
    )?.formatPhone;

    // SendMessage — try several patterns
    Store.SendMessage = Store.SendMessage || findModule(m =>
      typeof m === 'function' && /(SendTextMsgToChat|sendTextMsgToChat)/.test(m.toString())
    );

    // Stream — for connection state
    Store.Stream = Store.Stream || findModule(m =>
      typeof m?.displayInfo === 'string' && typeof m?.mode === 'string'
    );

    // WapQuery — verify number exists on WhatsApp
    Store.WapQuery = Store.WapQuery || findModule(m =>
      typeof m?.queryWidExists === 'function' || typeof m?.queryExist === 'function'
    );

    return Store;
  }

  // ---------- Send via Store ----------
  async function sendViaStore(phone, text) {
    const t0 = Date.now();
    const log = (s) => console.log(TAG, `[send] ${s} (+${Date.now()-t0}ms)`);

    const S = await getStore();
    if (!S.Chat || !S.WidFactory) {
      throw new Error('STORE_INCOMPLETE — Chat or WidFactory missing. Try again in a few seconds.');
    }

    // Build the WA contact JID
    const jid = `${phone}@c.us`;
    const wid = S.WidFactory.createWid(jid);
    log(`wid created: ${jid}`);

    // Verify number exists
    if (S.WapQuery) {
      try {
        const q = S.WapQuery.queryWidExists || S.WapQuery.queryExist;
        const res = await q(wid);
        const exists = res && (res.wid || res.jid || res === true);
        if (!exists) throw new Error(`NUMBER_NOT_ON_WHATSAPP: ${phone} לא רשום בוואטסאפ`);
      } catch (e) {
        if (String(e.message).includes('NUMBER_NOT_ON_WHATSAPP')) throw e;
        log(`number check failed (will try anyway): ${e.message}`);
      }
    }

    // Get or create chat
    let chat = S.Chat.get && S.Chat.get(wid);
    if (!chat) {
      chat = await S.Chat.find(wid);
    }
    if (!chat) throw new Error('CHAT_NOT_FOUND');
    log(`chat resolved`);

    // Send the message via chat instance
    let result;
    if (typeof chat.sendMessage === 'function') {
      result = await chat.sendMessage(text);
    } else if (typeof chat.sendToChat === 'function') {
      // Joni's preferred path
      result = await chat.sendToChat({ chat, options: { type: 'text', body: text } });
    } else {
      throw new Error('NO_SEND_METHOD_ON_CHAT');
    }

    log(`message sent`);
    return {
      method: 'store',
      ack: result?.ack ?? 0,
      msgId: result?.id?._serialized || null,
      durationMs: Date.now() - t0
    };
  }

  // ---------- Top-level send ----------
  async function send(phone, text) {
    return await sendViaStore(phone, text);
  }

  function getConnectionState() {
    if (Store?.Stream?.displayInfo) return Store.Stream.displayInfo;
    return waIsReady() ? 'CONNECTED' : 'BUILDING';
  }
  function isReady() {
    return getConnectionState() === 'CONNECTED' || waIsReady();
  }

  // ---------- Chat extraction (uses Store.Chat.models) ----------
  async function extractChats(opts = {}) {
    const S = await getStore();
    if (!S.Chat?.models) throw new Error('NO_CHAT_LIST');
    const limit = opts.limit || 500;
    const includeGroups = !!opts.includeGroups;
    const out = [];
    for (const chat of S.Chat.models) {
      if (out.length >= limit) break;
      try {
        const id = chat.id;
        const isGroup = id?._serialized?.endsWith('@g.us') || chat.isGroup;
        if (isGroup && !includeGroups) continue;
        const jid = id?._serialized || '';
        const phoneMatch = jid.match(/^(\d+)@c\.us$/);
        if (!phoneMatch && !isGroup) continue;
        const name = chat.name || chat.formattedTitle || chat.contact?.name || chat.contact?.pushname || '';
        if (!name) continue;
        out.push({
          name,
          phone: phoneMatch ? phoneMatch[1] : '',
          isGroup,
          unread: chat.unreadCount || 0,
          lastMessageAt: chat.t ? chat.t * 1000 : null
        });
      } catch (_) {}
    }
    return out.sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
  }

  // ---------- Diagnostic ----------
  async function runDiagnostic() {
    const t0 = Date.now();
    const report = {
      capturedAt: new Date().toISOString(),
      version: '0.14.0',
      strategy: 'Store API via Joni-style on-demand moduleRaid',
      wa: {
        ready: waIsReady(),
        readyState: document.readyState,
        url: location.href
      },
      webpack: {
        chunkBuild: !!window.webpackChunkbuild,
        chunkWA: !!window.webpackChunkwhatsapp_web_client,
        modulesCaptured: modules ? modules.length : 0
      },
      store: {
        hasChat: false, hasWidFactory: false, hasStream: false, hasWapQuery: false,
        hasFormatPhone: false, streamState: null
      },
      recommendations: []
    };

    if (waIsReady()) {
      try {
        const S = await getStore();
        report.store.hasChat = !!S.Chat;
        report.store.hasWidFactory = !!S.WidFactory;
        report.store.hasStream = !!S.Stream;
        report.store.hasWapQuery = !!S.WapQuery;
        report.store.hasFormatPhone = !!S.formatPhone;
        report.store.streamState = S.Stream?.displayInfo || null;
        report.webpack.modulesCaptured = modules ? modules.length : 0;
      } catch (e) {
        report.store.error = e.message;
      }
    } else {
      report.recommendations.push('🔴 WA Web עוד לא נטען מלא — חכה עוד 5-10 שניות.');
    }

    if (waIsReady() && !report.store.hasChat) {
      report.recommendations.push('🟡 Chat module לא נמצא. ייתכן שWA שינו את ה-bundle. דווח ליוגב.');
    }
    if (report.recommendations.length === 0) {
      report.recommendations.push('✅ הכל תקין. רוני אמור לשלוח.');
    }
    report.diagnosticLatencyMs = Date.now() - t0;
    return report;
  }

  // ---------- Bridge ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;
    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        respond({ ok: true, result: {
          ready: isReady(),
          state: getConnectionState(),
          hasStore: !!Store,
          hasChat: !!Store?.Chat,
          mode: 'store-on-demand'
        }});
      } else if (action === 'rebuildStore') {
        modules = null; Store = null;
        try {
          const S = await getStore();
          respond({ ok: true, result: { hasStore: !!S, hasChat: !!S?.Chat } });
        } catch (e) {
          respond({ ok: true, result: { hasStore: false, error: e.message } });
        }
      } else if (action === 'extractChats') {
        try {
          const chats = await extractChats(payload);
          respond({ ok: true, result: { chats } });
        } catch (e) {
          respond({ ok: false, error: e.message });
        }
      } else if (action === 'diagnose') {
        const report = await runDiagnostic();
        respond({ ok: true, result: report });
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  // CRITICAL: do NOTHING webpack-related at load time. Wait for explicit
  // user action (status check, send, diagnose) which will trigger getStore()
  // only when WA is ready.
  console.log(TAG, 'injected (MAIN world) — store-on-demand, will wait for WA ready');
})();
