// content-main.js — runs in MAIN world of web.whatsapp.com.
// Responsible for: Store API injection (primary send path) and DOM fallback.
// Talks to content-isolated.js via window.postMessage.
//
// Inspired by whatsapp-web.js (MIT) — github.com/pedroslopez/whatsapp-web.js

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  // ---------- moduleRaid: capture every webpack module ----------
  // WA Web is a webpack bundle. We push a fake chunk that requires every module
  // and captures the module exports map. From there we search by signature.
  let modulesCache = null;
  let captureMeta = { chunksFound: [], chunkCount: 0, latencyMs: 0, error: null, completedAt: 0 };

  function findWebpackChunks() {
    return Object.keys(window).filter(k =>
      k.startsWith('webpackChunk') || k.startsWith('webpackJsonp')
    );
  }

  function tryCaptureFrom(chunkName) {
    const chunk = window[chunkName];
    if (!chunk || typeof chunk.push !== 'function') return null;
    const modules = {};
    try {
      const chunkId = 'getjob_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      chunk.push([
        [chunkId],
        {},
        (req) => {
          const ids = Object.keys(req.m || req.cache || {});
          for (const id of ids) {
            try {
              const mod = req(id);
              if (mod) modules[id] = mod;
            } catch (_) { /* skip individual broken modules */ }
          }
        }
      ]);
    } catch (e) {
      console.warn(TAG, `moduleRaid via ${chunkName} threw:`, e.message);
      captureMeta.error = `${chunkName}: ${e.message}`;
      return null;
    }
    return Object.keys(modules).length ? modules : null;
  }

  /**
   * Async-first module capture. Polls for webpack until it appears, then captures.
   * Returns the modules map. Throws on timeout.
   * Replaces the old sync captureModules() — see lesson_firefighting.md for why.
   */
  async function captureModulesAsync(timeoutMs = 30000) {
    if (modulesCache) return modulesCache;
    const start = Date.now();
    let attempts = 0;
    while (Date.now() - start < timeoutMs) {
      attempts++;
      const chunks = findWebpackChunks();
      captureMeta.chunksFound = chunks;
      captureMeta.chunkCount = chunks.length;
      if (chunks.length) {
        // Webpack present — give it a tiny grace period for late-registered modules
        // on the FIRST detection only
        if (attempts === 1 && (Date.now() - start < 200)) await sleep(300);
        for (const chunkName of chunks) {
          const captured = tryCaptureFrom(chunkName);
          if (captured) {
            modulesCache = captured;
            captureMeta.latencyMs = Date.now() - start;
            captureMeta.completedAt = Date.now();
            console.log(TAG, `Captured ${Object.keys(captured).length} modules from ${chunkName} in ${captureMeta.latencyMs}ms`);
            return captured;
          }
        }
      }
      await sleep(250);
    }
    captureMeta.latencyMs = Date.now() - start;
    captureMeta.error = `WEBPACK_NOT_FOUND_AFTER_${Math.round(captureMeta.latencyMs / 1000)}S`;
    throw new Error(captureMeta.error);
  }

  // ---------- find specific Store pieces by signature ----------
  function findModule(modules, predicate) {
    for (const id of Object.keys(modules)) {
      const m = modules[id];
      if (!m) continue;
      try {
        if (predicate(m)) return m;
        if (m.default && predicate(m.default)) return m.default;
      } catch (_) { /* skip */ }
    }
    return null;
  }

  let Store = null;

  /**
   * Async-first Store builder. Awaits webpack readiness then resolves all sub-modules.
   * Cached after first successful build. Throws if webpack never appears.
   */
  async function buildStoreAsync(timeoutMs = 30000) {
    if (Store && Store.Chat && Store.WidFactory) return Store;
    const modules = await captureModulesAsync(timeoutMs);
    return populateStore(modules);
  }

  /** Sync best-effort: returns built Store or null. No work performed. */
  function getStoreSync() {
    return Store && Store.Chat ? Store : null;
  }

  function populateStore(modules) {
    Store = {};

    // Chat collection — has .find / .get / ._models
    Store.Chat = findModule(modules, m =>
      m && m.Chat && typeof m.Chat.find === 'function'
    );
    if (Store.Chat) Store.Chat = Store.Chat.Chat;
    if (!Store.Chat) {
      Store.Chat = findModule(modules, m =>
        m && typeof m.find === 'function' && m._models &&
        m._models[0] && m._models[0].constructor && m._models[0].constructor.name === 'Chat'
      );
    }

    // Wid factory — modern path: WidFactory.createWid('123@c.us')
    Store.WidFactory = findModule(modules, m =>
      m && typeof m.createWid === 'function' && typeof m.createWidFromWidLike === 'function'
    );

    // SendMessage — the chat-instance .sendMessage method handles this for us,
    // but we also keep a reference to a direct sender for diagnostics.
    Store.SendTextMsgToChat = findModule(modules, m =>
      m && typeof m === 'function' && /SendTextMsgToChat|sendTextMsgToChat/.test(m.toString())
    );

    // Connection state — Stream.displayInfo === 'CONNECTED'
    Store.Stream = findModule(modules, m =>
      m && typeof m.displayInfo === 'string' && typeof m.mode === 'string'
    );

    // Number existence check (WapQuery in older builds, Wap2 in newer)
    Store.WapQuery = findModule(modules, m =>
      m && (typeof m.queryWidExists === 'function' || typeof m.queryExist === 'function')
    );

    // Msg collection — for reply detection. Backbone-ish: has .add event, .models
    Store.Msg = findModule(modules, m =>
      m && typeof m.on === 'function' && Array.isArray(m.models) &&
      m.models[0] && m.models[0].constructor && /Msg/.test(m.models[0].constructor.name)
    );

    return Store;
  }

  // ---------- Reply tracking ----------
  // We track sent messages by their msgId. When an inbound message comes from the
  // same chat (recipient), we record it as a reply with response_time.
  const sentRegistry = new Map(); // msgId -> { phone, sentAt, contactJid }
  let msgListenerAttached = false;

  function registerSent(msgId, phone, contactJid) {
    if (!msgId) return;
    sentRegistry.set(msgId, { phone, sentAt: Date.now(), contactJid });
    // GC: clean entries older than 7 days (don't leak memory)
    const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
    for (const [k, v] of sentRegistry.entries()) {
      if (v.sentAt < cutoff) sentRegistry.delete(k);
    }
  }

  function attachMsgListener() {
    if (msgListenerAttached) return;
    const S = getStoreSync();
    if (!S || !S.Msg || typeof S.Msg.on !== 'function') return;

    S.Msg.on('add', (msg) => {
      try {
        if (!msg || msg.id?.fromMe) return; // only inbound
        const fromJid = msg.from?._serialized || msg.from;
        if (!fromJid) return;
        // find latest sent to this contact within last 7 days
        const matches = [...sentRegistry.entries()]
          .filter(([_, v]) => v.contactJid === fromJid)
          .sort((a, b) => b[1].sentAt - a[1].sentAt);
        if (!matches.length) return;
        const [matchedMsgId, info] = matches[0];
        const responseTimeSec = Math.round((Date.now() - info.sentAt) / 1000);
        if (responseTimeSec > 7 * 24 * 3600) return; // too old, probably random

        // Notify isolated world
        window.postMessage({
          type: 'GETJOB_REPLY_DETECTED',
          payload: {
            phone: info.phone,
            originalMsgId: matchedMsgId,
            replyAt: Date.now(),
            responseTimeSec,
            replyLen: (msg.body || '').length
          }
        }, '*');
        sentRegistry.delete(matchedMsgId); // one-shot per send
      } catch (_) { /* ignore individual errors */ }
    });

    msgListenerAttached = true;
    console.log(TAG, 'Msg listener attached for reply tracking');
  }

  // ---------- send via Store (primary) ----------
  async function sendViaStore(phone, text) {
    // buildStoreAsync awaits webpack readiness internally — no manual retry needed
    let S;
    try {
      S = await buildStoreAsync(30000);
    } catch (e) {
      throw new Error(`STORE_UNAVAILABLE — ${e.message}. חכי שWhatsApp Web ייטען מלא ונסי שוב.`);
    }
    if (!S || !S.Chat || !S.WidFactory) {
      throw new Error(`STORE_INCOMPLETE — webpack נטען אבל חסרים מודולים: hasChat=${!!(S&&S.Chat)} hasWidFactory=${!!(S&&S.WidFactory)}. ייתכן שWhatsApp שינה את הbundle.`);
    }

    const jid = `${phone}@c.us`;
    const wid = S.WidFactory.createWid(jid);

    // verify number exists on WhatsApp before opening a chat
    if (S.WapQuery) {
      try {
        const q = S.WapQuery.queryWidExists || S.WapQuery.queryExist;
        const res = await q(wid);
        const exists = res && (res.wid || res.jid || res === true);
        if (!exists) throw new Error('NUMBER_NOT_ON_WHATSAPP');
      } catch (e) {
        if (e.message === 'NUMBER_NOT_ON_WHATSAPP') throw e;
        // queryExists itself failed — proceed anyway, Chat.find may still work
      }
    }

    let chat = S.Chat.get && S.Chat.get(wid);
    if (!chat) {
      chat = await S.Chat.find(wid);
    }
    if (!chat) throw new Error('CHAT_NOT_FOUND');

    // sendMessage on the chat model — returns an ack-bearing object
    const result = await chat.sendMessage(text);
    const msgId = (result && result.id && result.id._serialized) || null;

    // Register for reply tracking
    if (msgId) registerSent(msgId, phone, jid);

    return {
      method: 'store',
      ack: (result && result.ack) ?? null,
      msgId
    };
  }

  // ---------- DOM fallback (no wa.me/send) ----------
  // Find chat via the in-app search box, then type into compose box and Enter.
  async function sendViaDom(phone, text) {
    // Try multiple selector patterns — WA Web shifts these by version
    function findSearchBox() {
      const selectors = [
        // Modern textbox patterns
        'div[role="textbox"][contenteditable="true"][data-tab="3"]',
        'div[role="textbox"][contenteditable="true"][data-tab="4"]',
        // By aria-label (Hebrew)
        'div[contenteditable="true"][aria-label*="חיפוש"]',
        'div[contenteditable="true"][aria-label*="צ\'אט"]',
        // By aria-label (English)
        'div[contenteditable="true"][aria-label*="Search"]',
        // Generic — first contenteditable in side panel
        'div[role="textbox"][contenteditable="true"]'
      ];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) return el;
      }
      return null;
    }

    function findSearchButton() {
      const selectors = [
        '[aria-label="חיפוש או צ\'אט חדש"]',
        '[aria-label="Search or start new chat"]',
        '[aria-label*="חיפוש"][role="button"]',
        '[aria-label*="Search"][role="button"]',
        'button[title*="חיפוש"]',
        'button[title*="Search"]'
      ];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) return el;
      }
      return null;
    }

    let searchBox = findSearchBox();
    if (!searchBox) {
      const searchBtn = findSearchButton();
      if (searchBtn) {
        searchBtn.click();
        await sleep(500);
        searchBox = findSearchBox();
      }
    }
    if (!searchBox) {
      throw new Error('SEARCH_BOX_NOT_FOUND — לא מצאתי את תיבת החיפוש של WhatsApp. ייתכן ש-WhatsApp עוד לא נטען מלא או ששינו את ה-DOM.');
    }

    searchBox.focus();
    document.execCommand('insertText', false, phone);
    await sleep(800);

    // Press Enter on the first matching contact (WA opens it)
    const firstResult = document.querySelector('[role="listitem"][tabindex="-1"]') ||
                        document.querySelector('div[role="grid"] [role="row"]');
    if (!firstResult) throw new Error('NO_CONTACT_MATCH');
    firstResult.click();
    await sleep(700);

    // Compose box
    const compose = document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="10"]') ||
                    document.querySelector('footer div[contenteditable="true"]');
    if (!compose) throw new Error('COMPOSE_NOT_FOUND');
    compose.focus();

    // Type one char at a time with jitter (slightly more human than paste)
    for (const ch of text) {
      document.execCommand('insertText', false, ch);
      await sleep(40 + Math.random() * 80);
    }
    await sleep(300);

    // Enter to send
    compose.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(800);
    return { method: 'dom', ack: null, msgId: null };
  }

  // ---------- top-level send: hybrid ----------
  async function send(phone, text) {
    try {
      return await sendViaStore(phone, text);
    } catch (storeErr) {
      console.warn(TAG, 'Store failed, falling back to DOM:', storeErr.message);
      try {
        const r = await sendViaDom(phone, text);
        r.storeError = storeErr.message;
        return r;
      } catch (domErr) {
        throw new Error(`STORE_AND_DOM_FAILED: store=${storeErr.message} dom=${domErr.message}`);
      }
    }
  }

  // ---------- Chat extraction (for WA contact import) ----------
  async function extractChats(opts = {}) {
    const S = await buildStoreAsync(20000);
    if (!S) throw new Error('STORE_NOT_BUILT — webpack modules not captured. Try refreshing WA Web.');
    if (!S.Chat) throw new Error('STORE.CHAT_NOT_FOUND — WhatsApp module signatures may have changed.');
    if (!Array.isArray(S.Chat.models)) {
      throw new Error('STORE.CHAT.MODELS_NOT_ARRAY — chat list not loaded yet. Wait a few seconds.');
    }
    if (S.Chat.models.length === 0) {
      throw new Error('NO_CHATS_LOADED — chat list is empty. Open a chat in WhatsApp first to trigger loading.');
    }

    const limit = opts.limit || 500;
    const includeGroups = !!opts.includeGroups;
    const out = [];

    for (const chat of S.Chat.models) {
      if (out.length >= limit) break;
      try {
        const id = chat.id;
        const isGroup = id?._serialized?.endsWith('@g.us') || chat.isGroup;
        if (isGroup && !includeGroups) continue;
        const jid = id?._serialized || '';
        const phoneMatch = jid.match(/^(\d+)@c\.us$/);
        if (!phoneMatch) continue;
        const phone = phoneMatch[1];
        const name = chat.name || chat.formattedTitle || chat.contact?.name || chat.contact?.pushname || '';
        if (!name) continue;
        out.push({
          name,
          phone,
          isGroup: false,
          unread: chat.unreadCount || 0,
          lastMessageAt: chat.t ? chat.t * 1000 : null
        });
      } catch (_) { /* skip */ }
    }
    return out.sort((a, b) => (b.lastMessageAt || 0) - (a.lastMessageAt || 0));
  }

  function getConnectionState() {
    const S = getStoreSync();
    if (!S || !S.Stream) return 'unknown';
    return S.Stream.displayInfo || 'unknown';
  }

  function isReady() {
    return getConnectionState() === 'CONNECTED';
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- Diagnostic ----------
  // Returns a structured snapshot of the runtime state — webpack, Store, DOM, bridge.
  // Surfaced via the 'diagnose' action below; rendered in Settings tab → "אבחון מערכת".
  async function runDiagnostic() {
    const t0 = Date.now();
    const report = {
      capturedAt: new Date().toISOString(),
      whatsapp: {
        pageReady: document.readyState,
        url: location.href,
        appUid: (() => {
          try { return document.querySelector('[data-app-uid]')?.getAttribute('data-app-uid') || null; }
          catch { return null; }
        })(),
        userAgent: navigator.userAgent.split(') ').pop()
      },
      webpack: { ...captureMeta },
      store: { hasChat: false, hasWidFactory: false, hasStream: false, hasMsg: false, hasWapQuery: false, streamState: null },
      dom: { searchBoxFound: false, searchBoxSelector: null, composeBoxFound: false, composeBoxSelector: null,
             contenteditables: 0, sidePanelMounted: false, chatListMounted: false },
      recommendations: []
    };

    // Try to build Store (with short timeout — diagnostic shouldn't block long)
    try {
      const S = await buildStoreAsync(5000);
      report.store.hasChat = !!S?.Chat;
      report.store.hasWidFactory = !!S?.WidFactory;
      report.store.hasStream = !!S?.Stream;
      report.store.hasMsg = !!S?.Msg;
      report.store.hasWapQuery = !!S?.WapQuery;
      report.store.streamState = S?.Stream?.displayInfo || null;
    } catch (e) {
      report.store.error = e.message;
    }

    // DOM probes — try every selector we know of
    const searchSelectors = [
      'div[role="textbox"][contenteditable="true"][data-tab="3"]',
      'div[role="textbox"][contenteditable="true"][data-tab="4"]',
      'div[contenteditable="true"][aria-label*="חיפוש"]',
      'div[contenteditable="true"][aria-label*="צ\'אט"]',
      'div[contenteditable="true"][aria-label*="Search"]',
      'div[role="textbox"][contenteditable="true"]'
    ];
    for (const sel of searchSelectors) {
      if (document.querySelector(sel)) {
        report.dom.searchBoxFound = true;
        report.dom.searchBoxSelector = sel;
        break;
      }
    }
    const composeSelectors = [
      'div[role="textbox"][contenteditable="true"][data-tab="10"]',
      'footer div[contenteditable="true"]',
      'footer [role="textbox"]'
    ];
    for (const sel of composeSelectors) {
      if (document.querySelector(sel)) {
        report.dom.composeBoxFound = true;
        report.dom.composeBoxSelector = sel;
        break;
      }
    }
    report.dom.contenteditables = document.querySelectorAll('[contenteditable="true"]').length;
    report.dom.sidePanelMounted = !!document.querySelector('[data-list-scroll-container], [aria-label*="רשימת"]');
    report.dom.chatListMounted = !!document.querySelector('div[role="grid"][aria-label*="רשימ"]') ||
                                 !!document.querySelector('div[role="listitem"]');

    // Build Hebrew recommendations
    if (report.webpack.chunkCount === 0) {
      report.recommendations.push('🔴 לא נמצא webpack — וואטסאפ עוד לא נטען. חכי עוד 10 שניות ונסי שוב.');
    } else if (!report.store.hasChat) {
      report.recommendations.push('🟡 Webpack נטען אבל לא מצאנו את מודול ה-Chat. ייתכן ש-WhatsApp שינו את ה-bundle. דווחי ליוגב את התוצאה הזו.');
    } else if (report.store.streamState !== 'CONNECTED') {
      report.recommendations.push(`🟡 WhatsApp במצב ${report.store.streamState || 'לא ידוע'} — לא מחובר. בדקי שאת מחוברת עם QR.`);
    }
    if (!report.dom.searchBoxFound) {
      report.recommendations.push('🟡 לא מצאנו את תיבת החיפוש של WhatsApp. ה-DOM fallback עלול להיכשל. אם Store עובד, אין בעיה.');
    }
    if (report.recommendations.length === 0) {
      report.recommendations.push('✅ הכל נראה תקין. אם השליחה עדיין נכשלת — דווחי ליוגב.');
    }

    report.diagnosticLatencyMs = Date.now() - t0;
    return report;
  }

  // ---------- bridge: window.postMessage <-> isolated world ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;

    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        // Async: wait briefly for Store, but never longer than the bridge timeout.
        try {
          const S = await buildStoreAsync(15000);
          respond({ ok: true, result: {
            ready: !!(S && S.Chat && S.Stream?.displayInfo === 'CONNECTED'),
            state: S?.Stream?.displayInfo || 'BUILDING',
            hasStore: !!S,
            hasChat: !!(S?.Chat),
            hasWidFactory: !!(S?.WidFactory)
          }});
        } catch (e) {
          respond({ ok: true, result: {
            ready: false,
            state: 'WAITING_FOR_WEBPACK',
            error: e.message
          }});
        }
      } else if (action === 'rebuildStore') {
        modulesCache = null;
        Store = null;
        captureMeta = { chunksFound: [], chunkCount: 0, latencyMs: 0, error: null, completedAt: 0 };
        try {
          const S = await buildStoreAsync(20000);
          respond({ ok: true, result: { hasStore: !!S, hasChat: !!(S && S.Chat) } });
        } catch (e) {
          respond({ ok: true, result: { hasStore: false, hasChat: false, error: e.message } });
        }
      } else if (action === 'extractChats') {
        try {
          const chats = await extractChats(payload);
          respond({ ok: true, result: { chats } });
        } catch (e) {
          respond({ ok: false, error: e.message });
        }
      } else if (action === 'diagnose') {
        const report = await runDiagnostic();
        respond({ ok: true, result: report });
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  // attempt eager Store build once page is interactive, then attach msg listener.
  // Now async: we build Store ASAP rather than waiting for the first user request.
  const tryInit = async () => {
    try {
      await buildStoreAsync(60000); // long timeout for slow boots
      attachMsgListener();
      // retry attach for a minute (Store.Msg sometimes appears later)
      let tries = 0;
      const iv = setInterval(() => {
        if (msgListenerAttached || ++tries > 12) { clearInterval(iv); return; }
        try { attachMsgListener(); } catch (_) {}
      }, 5000);
    } catch (e) {
      console.warn(TAG, 'tryInit could not build Store:', e.message);
    }
  };
  // Start Store building immediately — captureModulesAsync will poll until webpack
  // appears, so there's no benefit to waiting.
  tryInit();

  console.log(TAG, 'injected (MAIN world) — Store build started');
})();
