// popup.js — v0.3.0: contacts + template library + AI generation + settings.

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const STORAGE_KEYS = {
  contacts: 'roni:contacts',
  contactsStats: 'roni:contactsStats'
};

let state = {
  contacts: [],
  stats: null,
  sets: [],         // template library
  activeId: null,   // active set id
  aiResult: null    // last AI generation result, awaiting save
};

// ---------- storage ----------
function loadContactsState() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEYS.contacts, STORAGE_KEYS.contactsStats], (data) => {
      state.contacts = data[STORAGE_KEYS.contacts] || [];
      state.stats = data[STORAGE_KEYS.contactsStats] || null;
      resolve();
    });
  });
}

function saveContacts() {
  chrome.storage.local.set({
    [STORAGE_KEYS.contacts]: state.contacts,
    [STORAGE_KEYS.contactsStats]: state.stats
  });
}

async function loadLibrary() {
  const { sets, activeId } = await TemplateLibrary.load();
  state.sets = sets;
  state.activeId = activeId;
}

async function saveLibrary() {
  await TemplateLibrary.save(state.sets, state.activeId);
}

function activeSet() {
  return state.sets.find(s => s.id === state.activeId);
}

// ---------- WA Web tab + status ----------
async function getWaTab() {
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  return tabs[0] || null;
}

async function refreshStatus() {
  const badge = $('#wa-status');
  badge.textContent = 'בודק...';
  badge.className = 'badge';
  const tab = await getWaTab();
  if (!tab) {
    badge.textContent = 'WA Web לא פתוח';
    badge.classList.add('err');
    return;
  }
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' });
    if (resp && resp.success && resp.result.ready) {
      badge.textContent = 'מחובר';
      badge.classList.add('ok');
    } else {
      badge.textContent = resp?.result?.state || 'לא מוכן';
      badge.classList.add('warn');
    }
  } catch {
    badge.textContent = 'שגיאה';
    badge.classList.add('err');
  }
}

// ---------- tabs ----------
function activateTab(name) {
  $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  $$('.tab-content').forEach(c => c.classList.toggle('active', c.id === `tab-${name}`));
  if (name === 'preview') renderPreview();
  if (name === 'settings') renderSettings();
  if (name === 'insights') renderInsights();
  if (name === 'send') renderSendTab();
}

// ---------- contacts ----------
async function handleFile(evt) {
  const file = evt.target.files && evt.target.files[0];
  if (!file) return;
  try {
    const { contacts, stats } = await ContactParser.parseFile(file);
    setActiveBatch(contacts, stats, `📂 ${file.name}`);
    EventLog.log(EventLog.TYPE.CONTACTS_LOADED, {
      filename: file.name, total: stats.total, accepted: stats.accepted,
      duplicates: stats.duplicate, invalid: stats.invalidPhone, source: 'file'
    });
  } catch (err) {
    const msg = errMessage(err.message);
    $('#contacts-summary').className = 'summary visible';
    $('#contacts-summary').innerHTML = `<span class="stat err">רוני: ${msg}</span>`;
  }
}

function setActiveBatch(contacts, stats, title) {
  state.contacts = contacts;
  state.stats = stats;
  if (title) state.activeBatchTitle = title;
  saveContacts();
  renderContacts();
  updateTabCounts();
  refreshSourceCards();
}

function errMessage(code) {
  const map = {
    NO_SHEET: 'לא נמצאה טבלה בקובץ',
    MISSING_NAME_COLUMN: 'חסרה עמודת "שם" / "name"',
    MISSING_PHONE_COLUMN: 'חסרה עמודת "טלפון" / "phone"',
    FILE_READ_ERROR: 'לא הצלחתי לקרוא את הקובץ'
  };
  return map[code] || code;
}

function renderContacts() {
  const list = $('#contacts-list');
  const summary = $('#contacts-summary');
  const batchCard = $('#active-batch');
  const empty = $('#contacts-empty');

  if (!state.contacts.length) {
    if (batchCard) batchCard.style.display = 'none';
    if (empty) empty.style.display = 'block';
    list.innerHTML = '';
    summary.className = 'summary';
    summary.innerHTML = '';
    return;
  }
  if (batchCard) batchCard.style.display = 'block';
  if (empty) empty.style.display = 'none';
  if ($('#active-batch-title') && state.activeBatchTitle) {
    $('#active-batch-title').textContent = state.activeBatchTitle;
  }
  const s = state.stats || {};
  const parts = [`<span class="stat ok">✔ נטענו: ${s.accepted ?? state.contacts.length}</span>`];
  if (s.duplicate)    parts.push(`<span class="stat warn">כפולים: ${s.duplicate}</span>`);
  if (s.invalidPhone) parts.push(`<span class="stat warn">טלפון לא תקין: ${s.invalidPhone}</span>`);
  if (s.missingName)  parts.push(`<span class="stat warn">חסר שם: ${s.missingName}</span>`);
  if (s.missingPhone) parts.push(`<span class="stat warn">חסר טלפון: ${s.missingPhone}</span>`);
  summary.className = 'summary visible';
  summary.innerHTML = parts.join('');

  list.innerHTML = state.contacts.map(c => `
    <div class="contact-row">
      <span class="status status-${c.status}">${statusText(c.status)}</span>
      <span class="name">${escapeHtml(c.name)}</span>
      <span class="phone">${c.phone}</span>
    </div>
  `).join('');
}

function statusText(s) {
  return ({ pending: 'ממתין', sent: 'נשלח', failed: 'נכשל', skipped: 'דולג' })[s] || s;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function clearContacts() {
  if (!state.contacts.length) return;
  if (!confirm(`רוני ימחק את ${state.contacts.length} אנשי הקשר מהרשימה הפעילה. להמשיך?`)) return;
  state.contacts = [];
  state.stats = null;
  state.activeBatchTitle = '';
  saveContacts();
  renderContacts();
  updateTabCounts();
  refreshSourceCards();
}

// ---------- Source cards ----------
let biCache = null;     // { workers, count, updated }
let biFilter = { status: [], region: [], gender: [], role: [], textQuery: '' };

async function refreshSourceCards() {
  // BI count
  try {
    const cached = await new Promise(r =>
      chrome.storage.local.get(['roni:biCache'], d => r(d['roni:biCache']))
    );
    if (cached) {
      $('#src-bi-count').textContent = `${cached.count} עובדים`;
    } else {
      $('#src-bi-count').textContent = 'לחץ לטעון';
    }
  } catch { $('#src-bi-count').textContent = '—'; }

  // Shared count
  try {
    if (SharedContacts.isConfigured()) {
      const list = await SharedContacts.listAll({ limit: 1 });
      // PostgREST doesn't return count without HEAD; fetch full list count separately
      const all = await SharedContacts.listAll({ limit: 5000 });
      $('#src-shared-count').textContent = `${all.length} משותפים`;
    } else {
      $('#src-shared-count').textContent = 'לא מוגדר';
    }
  } catch { $('#src-shared-count').textContent = '—'; }
}

// ---------- BI Modal ----------
async function openBiModal() {
  $('#bi-modal').style.display = 'flex';
  $('#bi-loading').style.display = 'block';
  $('#bi-controls').style.display = 'none';

  try {
    const data = await BIImporter.fetchAll();
    biCache = data;
    $('#bi-loading').style.display = 'none';
    $('#bi-controls').style.display = 'block';
    renderBiFilters();
    updateBiSummary();
  } catch (err) {
    $('#bi-loading').textContent = `שגיאה בטעינה: ${err.message}`;
  }
}

function closeBiModal() { $('#bi-modal').style.display = 'none'; }

function renderBiFilters() {
  if (!biCache) return;
  const f = BIImporter.facets(biCache.workers);

  function chips(containerSel, entries, key, max = 12) {
    const c = $(containerSel);
    c.innerHTML = entries.slice(0, max).map(([val, count]) => `
      <span class="chip" data-key="${key}" data-val="${escapeHtml(val)}">
        ${escapeHtml(val)}<span class="count">${count}</span>
      </span>
    `).join('');
    c.querySelectorAll('.chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const v = chip.dataset.val;
        const arr = biFilter[key];
        const i = arr.indexOf(v);
        if (i >= 0) arr.splice(i, 1); else arr.push(v);
        chip.classList.toggle('active');
        updateBiSummary();
      });
    });
  }

  chips('#bi-filter-status', f.status, 'status', 8);
  chips('#bi-filter-region', f.region, 'region', 12);
  chips('#bi-filter-role',   f.role,   'role',   16);
  chips('#bi-filter-gender', f.gender, 'gender', 4);
}

function updateBiSummary() {
  if (!biCache) return;
  biFilter.textQuery = $('#bi-search').value || '';
  const filtered = BIImporter.applyFilter(biCache.workers, biFilter);
  $('#bi-summary').innerHTML = `<strong>${filtered.length}</strong> מתוך ${biCache.count} עובדים תואמים את הסינון`;
  return filtered;
}

async function biLoadActive() {
  const filtered = updateBiSummary();
  if (!filtered || !filtered.length) { alert('אין תוצאות'); return; }
  if (filtered.length > 100) {
    if (!confirm(`רוני אומר: ${filtered.length} זה הרבה. שלח batch של עד 100-150 בכל פעם — בטוח יותר. להמשיך בכל זאת?`)) {
      return;
    }
  }
  const contacts = filtered.map((w, i) => BIImporter.toContact(w, i));
  setActiveBatch(contacts, {
    total: filtered.length, accepted: contacts.length,
    duplicate: 0, invalidPhone: 0, missingName: 0, missingPhone: 0
  }, `🎯 BI · ${contacts.length} עובדים`);
  EventLog.log(EventLog.TYPE.CONTACTS_LOADED, {
    source: 'bi', total: filtered.length, accepted: contacts.length,
    filter: { ...biFilter, textQuery: biFilter.textQuery || '' }
  });
  closeBiModal();
}

async function biLoadShared() {
  const filtered = updateBiSummary();
  if (!filtered || !filtered.length) { alert('אין תוצאות'); return; }
  if (!SharedContacts.isConfigured()) { alert('Supabase לא מוגדר'); return; }

  const coord = await Telemetry.getCoordinatorId();
  const rows = filtered.map(w => ({
    phone: w.w,
    name: w.n,
    source: 'bi',
    source_id: w.id || null,
    tags: [w.s, w.rg].filter(Boolean),
    metadata: { city: w.c, region: w.rg, roles: w.r, gender: w.g, status: w.s },
    added_by: coord.id,
    added_by_name: coord.name || null
  }));

  try {
    const r = await SharedContacts.upsertMany(rows);
    EventLog.log(EventLog.TYPE.CONTACTS_LOADED, { source: 'bi_to_shared', accepted: r.count });
    alert(`✔ נוספו ${r.count} עובדים לפול המשותף. כל הרכזות יראו אותם.`);
    closeBiModal();
    refreshSourceCards();
  } catch (err) {
    alert('שגיאה בשמירה: ' + err.message);
  }
}

// ---------- Shared contacts: load to active ----------
async function loadShared() {
  if (!SharedContacts.isConfigured()) {
    alert('Supabase לא מוגדר. עברו להגדרות.');
    return;
  }
  try {
    const rows = await SharedContacts.listAll({ limit: 5000 });
    if (!rows.length) {
      alert('אין אנשי קשר משותפים עדיין. ייבא מ-BI כדי לאכלס.');
      return;
    }
    const contacts = rows.map((r, i) => SharedContacts.toContact(r, i));
    setActiveBatch(contacts, {
      total: rows.length, accepted: rows.length,
      duplicate: 0, invalidPhone: 0, missingName: 0, missingPhone: 0
    }, `👥 משותפים · ${rows.length}`);
    EventLog.log(EventLog.TYPE.CONTACTS_LOADED, { source: 'shared', accepted: rows.length });
  } catch (err) {
    alert('שגיאה: ' + err.message);
  }
}

// ---------- WA chat extraction ----------
async function importFromWA() {
  const tab = await getWaTab();
  if (!tab) { alert('פתח/י קודם web.whatsapp.com'); return; }

  // Diagnostic step 1: ensure WA Web is connected
  let status;
  try {
    status = await chrome.tabs.sendMessage(tab.id, { type: 'GET_STATUS' });
  } catch (e) {
    alert('רוני לא מצליח לתקשר עם WhatsApp Web.\n\nכנראה צריך לרענן את הטאב של web.whatsapp.com (Ctrl+R) — content script לא מתחבר אוטומטית לטאב שכבר היה פתוח לפני התקנה.');
    return;
  }
  if (!status?.success) {
    alert('שגיאת תקשורת: ' + (status?.error || 'לא ידוע') + '\n\nנסה לרענן את WA Web.');
    return;
  }
  if (!status.result?.ready) {
    alert(`WhatsApp Web לא מוכן (סטטוס: ${status.result?.state || 'לא ידוע'}).\n\nחכה עד שהאפליקציה נטענת מלא ונסה שוב.`);
    return;
  }

  // Step 2: extract
  let resp;
  try {
    resp = await chrome.tabs.sendMessage(tab.id, { type: 'EXTRACT_CHATS', options: { limit: 500 } });
  } catch (e) {
    alert('שגיאה בקריאה ל-content script: ' + e.message);
    return;
  }
  if (!resp?.success) {
    alert('רוני לא הצליח לשלוף שיחות:\n' + (resp?.error || 'תגובה ריקה') +
          '\n\nאפשר שה-Store API של WhatsApp השתנה. נסה ב-📤 → "הער את רוני".');
    return;
  }
  const chats = resp.result?.chats || [];
  if (!chats.length) {
    alert('לא נמצאו שיחות. ייתכן ש-WhatsApp Web עוד לא טען את רשימת הצ\'אטים — חכה 5-10 שניות ונסה שוב.');
    return;
  }
  const contacts = chats.map((c, i) => ({
    id: i + 1,
    name: c.name,
    phone: c.phone,
    extra: { unread: c.unread, lastMessageAt: c.lastMessageAt },
    status: 'pending',
    fromWA: true
  }));
  setActiveBatch(contacts, {
    total: chats.length, accepted: contacts.length,
    duplicate: 0, invalidPhone: 0, missingName: 0, missingPhone: 0
  }, `💬 WhatsApp · ${contacts.length} שיחות`);
  EventLog.log(EventLog.TYPE.CONTACTS_LOADED, { source: 'whatsapp', accepted: contacts.length });
}

// ---------- template library ----------
function renderSetsList() {
  const list = $('#sets-list');
  list.innerHTML = state.sets.map(s => `
    <div class="set-chip ${s.id === state.activeId ? 'active' : ''}" data-id="${s.id}">
      <span class="icon">${s.icon || '💬'}</span>
      <span class="name">${escapeHtml(s.name)}</span>
      <span class="count">${s.templates.length}</span>
    </div>
  `).join('');
  list.querySelectorAll('.set-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      state.activeId = chip.dataset.id;
      await saveLibrary();
      renderSetsList();
      renderSetEditor();
      updateTabCounts();
    });
  });
}

function renderSetEditor() {
  const card = $('#set-editor-card');
  const set = activeSet();
  if (!set) { card.style.display = 'none'; return; }
  card.style.display = 'block';

  $('#active-set-title').textContent = `${set.icon || '💬'} ${set.name}`;
  $('#set-name').value = set.name;
  $('#set-icon').value = set.icon || '';
  $('#btn-delete-set').style.display = set.builtin ? 'none' : 'block';

  const editor = $('#templates-editor');
  editor.innerHTML = set.templates.map((t, i) => `
    <div class="template-editor" data-idx="${i}">
      <div class="row">
        <span>וריאציה ${i + 1}</span>
        <button class="btn-danger" data-action="del" data-idx="${i}">מחק</button>
      </div>
      <textarea data-idx="${i}" rows="3">${escapeHtml(t)}</textarea>
      <div class="meta">
        <span data-meta-count="${i}">${(t || '').length} תווים</span>
        <span data-meta-vars="${i}">משתנים: ${TemplateEngine.extractVars(t).join(', ') || '—'}</span>
      </div>
    </div>
  `).join('');

  editor.querySelectorAll('textarea').forEach(ta => {
    ta.addEventListener('input', e => {
      const idx = +e.target.dataset.idx;
      set.templates[idx] = e.target.value;
      const t = e.target.value;
      $(`[data-meta-count="${idx}"]`).textContent = `${t.length} תווים`;
      $(`[data-meta-vars="${idx}"]`).textContent = `משתנים: ${TemplateEngine.extractVars(t).join(', ') || '—'}`;
      validateActiveSetUI();
    });
  });
  editor.querySelectorAll('[data-action="del"]').forEach(btn => {
    btn.addEventListener('click', e => {
      const idx = +e.target.dataset.idx;
      if (set.templates.length <= 1) { alert('סט חייב לפחות וריאציה אחת'); return; }
      set.templates.splice(idx, 1);
      renderSetEditor();
      validateActiveSetUI();
    });
  });

  validateActiveSetUI();
}

function validateActiveSetUI() {
  const set = activeSet();
  if (!set) return;
  const v = TemplateEngine.validateTemplates(set.templates);
  const box = $('#templates-validation');
  const msgs = [];
  if (v.errors.length) {
    box.className = 'validation-box has-errors';
    msgs.push('<strong>רוני מצא בעיות:</strong>');
    msgs.push('<ul>' + v.errors.map(e => `<li>${escapeHtml(e)}</li>`).join('') + '</ul>');
  } else if (v.warnings.length) {
    box.className = 'validation-box has-warnings';
    msgs.push('<strong>רוני מציע לבדוק:</strong>');
    msgs.push('<ul>' + v.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('') + '</ul>');
  } else {
    box.className = 'validation-box ok';
    msgs.push(`<strong>✔ ${v.count} וריאציות תקינות</strong>`);
  }
  box.innerHTML = msgs.join('');
}

async function saveActiveSet() {
  const set = activeSet();
  if (!set) return;
  set.name = $('#set-name').value.trim() || set.name;
  set.icon = $('#set-icon').value.trim() || set.icon;
  set.templates = set.templates.map(t => (t || '').trim()).filter(Boolean);
  if (!set.templates.length) set.templates = ['שלום {{שם}}'];
  set.updatedAt = Date.now();
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
  flash('הסט נשמר', 'ok');
}

function addVariantToActive() {
  const set = activeSet();
  if (!set) return;
  set.templates.push("שלום {{שם}}, רוני מגטג'וב 🙋");
  renderSetEditor();
}

async function deleteActiveSet() {
  const set = activeSet();
  if (!set || set.builtin) return;
  if (!confirm(`רוני ימחק את הסט "${set.name}". להמשיך?`)) return;
  state.sets = state.sets.filter(s => s.id !== state.activeId);
  state.activeId = state.sets[0].id;
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
}

async function newEmptySet() {
  const newSet = TemplateLibrary.createSet({
    name: 'סט חדש',
    icon: '💬',
    templates: [`שלום {{שם}}, רוני מגטג'וב 🙋`]
  });
  state.sets.push(newSet);
  state.activeId = newSet.id;
  await saveLibrary();
  renderSetsList();
  renderSetEditor();
}

function flash(msg, kind) {
  const box = $('#templates-validation');
  box.className = `validation-box ${kind === 'ok' ? 'ok' : 'has-errors'}`;
  box.innerHTML = `<strong>${escapeHtml(msg)}</strong>`;
  setTimeout(validateActiveSetUI, 1500);
}

// ---------- preview ----------
function renderPreview() {
  const list = $('#preview-list');
  const meta = $('#preview-meta');
  const set = activeSet();

  if (!set) { list.innerHTML = ''; meta.textContent = 'אין סט פעיל.'; return; }

  meta.innerHTML = `סט פעיל: <strong>${set.icon} ${escapeHtml(set.name)}</strong> (${set.templates.length} וריאציות)`;

  if (!state.contacts.length) {
    list.innerHTML = '<div class="hint" style="padding:8px;">טען קודם אנשי קשר בטאב "אנשי קשר".</div>';
    return;
  }

  const valid = set.templates.filter(t => t && t.trim());
  if (!valid.length) {
    list.innerHTML = '<div class="hint" style="padding:8px;">אין וריאציות פעילות בסט.</div>';
    return;
  }

  const rotator = new TemplateEngine.Rotator(valid);
  const sample = state.contacts.slice(0, 5);
  list.innerHTML = sample.map(c => {
    const { index, text } = rotator.renderForContact(c);
    return `
      <div class="preview-item">
        <div class="head">
          <span>📱 ${escapeHtml(c.name)} · ${c.phone}</span>
          <span>וריאציה #${index + 1}</span>
        </div>${escapeHtml(text)}
      </div>`;
  }).join('');
}

// ---------- AI modal ----------
function openAiModal() {
  $('#ai-modal').style.display = 'flex';
  $('#ai-status').style.display = 'none';
  $('#ai-results').style.display = 'none';
  $('#ai-intent').focus();
}

function closeAiModal() {
  $('#ai-modal').style.display = 'none';
  state.aiResult = null;
}

function showAiStatus(msg, ok) {
  const box = $('#ai-status');
  box.style.display = 'block';
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

async function aiGenerate(numVariants) {
  const intent = $('#ai-intent').value.trim();
  if (!intent) { showAiStatus('תאר תחילה מה אתה רוצה לשלוח', false); return; }

  const settings = await AIGenerator.getSettings();
  if (!settings.apiKey) {
    showAiStatus('לא הוגדר מפתח API. עבור להגדרות והוסף.', false);
    return;
  }

  showAiStatus('רוני חושב... ⏳', true);
  $('#ai-generate').disabled = true;
  $('#ai-generate-3').disabled = true;

  try {
    const result = await AIGenerator.generateVariants(intent, { numVariants });
    state.aiResult = result;
    EventLog.log(EventLog.TYPE.AI_GENERATION, {
      intentLen: intent.length,
      numVariants: result.templates.length,
      model: result.model,
      success: true
    });
    showAiStatus(`✔ רוני יצר ${result.templates.length} וריאציות (מודל: ${result.model})`, true);
    renderAiResult(result);
  } catch (err) {
    EventLog.log(EventLog.TYPE.AI_GENERATION, { intentLen: intent.length, success: false, error: err.message });
    showAiStatus('רוני נכשל: ' + AIGenerator.errMessage(err.message), false);
  } finally {
    $('#ai-generate').disabled = false;
    $('#ai-generate-3').disabled = false;
  }
}

function renderAiResult(result) {
  $('#ai-results').style.display = 'block';
  $('#ai-set-name').value = result.name;
  $('#ai-set-icon').value = result.icon;

  const list = $('#ai-variants');
  list.innerHTML = result.templates.map((t, i) => `
    <div class="variant" data-idx="${i}">
      <div class="head">
        <span>וריאציה ${i + 1}</span>
        <span>${(t || '').length} תווים</span>
      </div>
      <textarea data-idx="${i}" rows="3">${escapeHtml(t)}</textarea>
    </div>
  `).join('');

  list.querySelectorAll('textarea').forEach(ta => {
    ta.addEventListener('input', e => {
      const idx = +e.target.dataset.idx;
      state.aiResult.templates[idx] = e.target.value;
      e.target.parentElement.querySelector('.head span:last-child').textContent =
        `${e.target.value.length} תווים`;
    });
  });
}

async function aiSaveAsSet() {
  if (!state.aiResult) return;
  const name = $('#ai-set-name').value.trim() || state.aiResult.name;
  const icon = $('#ai-set-icon').value.trim() || state.aiResult.icon;
  const templates = state.aiResult.templates.map(t => (t || '').trim()).filter(Boolean);

  // Validate every template has {{שם}}
  const v = TemplateEngine.validateTemplates(templates);
  if (v.errors.length) {
    if (!confirm('יש בעיות בתבניות:\n\n' + v.errors.join('\n') + '\n\nלשמור בכל זאת?')) return;
  }

  const newSet = TemplateLibrary.createSet({
    name, icon, templates,
    intent: state.aiResult.intent,
    model: state.aiResult.model
  });
  state.sets.push(newSet);
  state.activeId = newSet.id;
  await saveLibrary();
  EventLog.log(EventLog.TYPE.TEMPLATE_SET_CREATED, {
    setId: newSet.id, name: newSet.name, source: 'ai',
    numVariants: newSet.templates.length, model: newSet.model
  });
  closeAiModal();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
}

// ---------- settings ----------
async function renderSettings() {
  const s = await AIGenerator.getSettings();
  $('#api-key').value = s.apiKey || '';
  $('#ai-model').value = s.model || AIGenerator.DEFAULT_MODEL;
  await renderWarmupControls();
  await renderGoogleContactsControls();
  await renderSafetyControls();
  await renderTelemetryControls();
}

async function renderWarmupControls() {
  const state = await Warmup.load();
  const status = Warmup.status(state);
  const box = $('#warmup-status');
  const startBtn = $('#btn-start-warmup');
  const stopBtn = $('#btn-stop-warmup');

  if (status.active) {
    const pct = Math.round((status.day / 11) * 100);
    box.className = 'warmup-status active';
    box.innerHTML = `
      <div><span class="day">יום ${status.day}/11</span> · cap היום: <strong>${status.cap}</strong> הודעות · עוד ${status.daysToFull} ימים לחימום מלא</div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%;"></div></div>
    `;
    startBtn.style.display = 'none';
    stopBtn.style.display = '';
  } else if (status.completed) {
    box.className = 'warmup-status active';
    box.innerHTML = `<div>✔ <span class="day">חימום הושלם</span> · החשבון "מבושל" ויכול לעבוד בקצב מלא</div>`;
    startBtn.style.display = '';
    stopBtn.style.display = 'none';
    startBtn.textContent = '🔄 התחל חימום מחדש';
  } else {
    box.className = 'warmup-status';
    box.innerHTML = '';
    startBtn.style.display = '';
    stopBtn.style.display = 'none';
  }

  startBtn.onclick = async () => {
    if (!confirm('להתחיל חימום? ה-cap היומי ירד ל-20 ויעלה הדרגתית לאורך 11 ימים.')) return;
    await Warmup.start();
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'warmup', value: 'started' });
    await renderWarmupControls();
    renderCircuitBanner();
  };
  stopBtn.onclick = async () => {
    if (!confirm('לעצור את החימום? התקרה תחזור לפרופיל הבטיחות הרגיל.')) return;
    await Warmup.stop();
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'warmup', value: 'stopped' });
    await renderWarmupControls();
    renderCircuitBanner();
  };
}

async function renderGoogleContactsControls() {
  const settings = await GoogleContacts.getSettings();
  const status = $('#gc-status');
  $('#gc-enabled').checked = !!settings.enabled;
  $('#gc-group').value = settings.groupName || 'GetJob-WA-2026';

  if (!GoogleContacts.isConfigured()) {
    status.innerHTML = '⚠️ OAuth לא הוגדר במניפסט. ראה <code>SETUP_GOOGLE.md</code>.';
  } else {
    status.innerHTML = '✔ OAuth מוגדר. לחץ "בדוק חיבור" לאישור הרשאה.';
  }

  $('#gc-enabled').onchange = async () => {
    const s = await GoogleContacts.getSettings();
    s.enabled = $('#gc-enabled').checked;
    await GoogleContacts.setSettings(s);
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'gcontacts_enabled', value: s.enabled });
  };
  $('#gc-group').onblur = async () => {
    const s = await GoogleContacts.getSettings();
    s.groupName = $('#gc-group').value.trim() || 'GetJob-WA-2026';
    await GoogleContacts.setSettings(s);
  };
  $('#btn-test-gc').onclick = async () => {
    try {
      const token = await GoogleContacts.getToken({ interactive: true });
      status.innerHTML = `✔ חיבור תקין! token ${token.slice(0, 12)}...`;
    } catch (e) {
      status.innerHTML = `❌ שגיאה: ${e.message}`;
    }
  };
}

async function renderTelemetryControls() {
  const enabled = await Telemetry.isEnabled();
  const coord = await Telemetry.getCoordinatorId();
  $('#telemetry-enabled').checked = enabled;
  $('#coord-name').value = coord.name || '';

  const status = $('#telemetry-status');
  if (!Telemetry.isConfigured()) {
    status.innerHTML = '⚠️ טלמטריה לא מוגדרת. <code>config.js</code> עדיין עם CHANGE-ME.';
  } else {
    status.innerHTML = `✔ מוגדר. coordinator_id: <code>${coord.id.slice(0, 16)}...</code>`;
  }

  $('#telemetry-enabled').onchange = async () => {
    await Telemetry.setEnabled($('#telemetry-enabled').checked);
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'telemetry_enabled', value: $('#telemetry-enabled').checked });
  };
  $('#coord-name').onblur = async () => {
    await Telemetry.setCoordinatorName($('#coord-name').value);
  };
}

async function saveSettings() {
  const apiKey = $('#api-key').value.trim();
  const model = $('#ai-model').value;
  await AIGenerator.saveSettings({ apiKey, model });
  showSettingsResult('הגדרות נשמרו ✔', true);
}

async function testApi() {
  const box = $('#settings-result');
  box.textContent = 'בודק חיבור ל-Claude...';
  box.className = 'result-box';
  try {
    const result = await AIGenerator.generateVariants(
      'הודעת בדיקה קצרה לעובד שביקש פרטים על משמרת',
      { numVariants: 1 }
    );
    showSettingsResult(`✔ חיבור תקין!\nמודל: ${result.model}\nדוגמת וריאציה:\n${result.templates[0]}`, true);
  } catch (err) {
    showSettingsResult('רוני נכשל: ' + AIGenerator.errMessage(err.message), false);
  }
}

function showSettingsResult(msg, ok) {
  const box = $('#settings-result');
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

// ---------- test tab ----------
function showResult(msg, ok) {
  const box = $('#result');
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

// --- Manual send: BI lookup ---
let manualResolvedWorker = null;

async function manualLookup() {
  const q = $('#manual-lookup').value.trim();
  const box = $('#manual-suggestions');
  if (q.length < 2) { box.innerHTML = ''; box.classList.remove('has-results'); return; }

  // Make sure BI cache is loaded
  let cached = await new Promise(r => chrome.storage.local.get(['roni:biCache'], d => r(d['roni:biCache'])));
  if (!cached) {
    try { cached = await BIImporter.fetchAll(); } catch { return; }
  }
  if (!cached?.workers) return;

  const qLower = q.toLowerCase();
  const isPhoneSearch = /^\d/.test(q);
  const matches = cached.workers.filter(w => {
    if (isPhoneSearch) {
      return String(w.w || '').includes(q) || String(w.p || '').replace(/\D/g, '').includes(q);
    }
    return String(w.n || '').toLowerCase().includes(qLower);
  }).slice(0, 8);

  if (!matches.length) {
    box.innerHTML = '<div class="lookup-row"><span class="lr-meta">אין תוצאות ב-BI</span></div>';
    box.classList.add('has-results');
    return;
  }

  box.innerHTML = matches.map(w => `
    <div class="lookup-row" data-phone="${w.w}" data-name="${escapeHtml(w.n || '')}">
      <span class="lr-name">${escapeHtml(w.n || '')}</span>
      <span class="lr-meta">${escapeHtml(w.c || '')} · ${escapeHtml(w.s || '')}</span>
      <span class="lr-phone">${w.w?.slice(-4) || ''}</span>
    </div>
  `).join('');
  box.classList.add('has-results');

  box.querySelectorAll('.lookup-row[data-phone]').forEach(row => {
    row.addEventListener('click', () => {
      const w = matches.find(x => x.w === row.dataset.phone);
      selectManualWorker(w);
    });
  });
}

function selectManualWorker(w) {
  if (!w) return;
  manualResolvedWorker = w;
  $('#manual-lookup').value = '';
  $('#manual-suggestions').innerHTML = '';
  $('#manual-suggestions').classList.remove('has-results');
  $('#test-phone').value = w.w;
  $('#manual-resolved').style.display = 'block';
  $('#manual-resolved-name').textContent = `${w.n}`;
  $('#manual-resolved-meta').textContent = `${w.p || w.w} · ${w.c || ''} · ${w.r ? w.r.split(',')[0] : ''}`;
}

function clearManualResolved() {
  manualResolvedWorker = null;
  $('#manual-resolved').style.display = 'none';
  $('#test-phone').value = '';
}

async function sendOne() {
  const phone = $('#test-phone').value.replace(/\D/g, '');
  let text = $('#test-text').value.trim();
  const btn = $('#btn-send-one');
  if (!phone || phone.length < 9) { showResult('רוני אומר: טלפון לא תקין', false); return; }

  // Substitute {{שם}} if a worker was resolved from BI
  if (manualResolvedWorker && /\{\{\s*(שם|name)\s*\}\}/.test(text)) {
    text = text.replace(/\{\{\s*(שם|name)\s*\}\}/gi, manualResolvedWorker.fn || manualResolvedWorker.n || '');
  }
  if (!text) { showResult('רוני אומר: ההודעה ריקה', false); return; }

  // Pre-flight safety check
  const safetyState = await Safety.loadState();
  const allow = await Safety.checkCanSend(safetyState);
  if (!allow.allowed) {
    showResult('רוני נעצר: ' + Safety.reasonText(allow.reason), false);
    EventLog.log(allow.reason === 'OUTSIDE_WORK_HOURS' || allow.reason === 'OUTSIDE_WORK_DAYS'
      ? EventLog.TYPE.OUTSIDE_HOURS_BLOCKED
      : (allow.reason === 'DAILY_CAP_REACHED' ? EventLog.TYPE.DAILY_CAP_HIT : EventLog.TYPE.SESSION_CAP_HIT),
      { reason: allow.reason, phone });
    renderCircuitBanner();
    return;
  }

  const tab = await getWaTab();
  if (!tab) { showResult('רוני צריך שתפתח קודם את web.whatsapp.com', false); return; }

  btn.disabled = true;
  showResult('רוני שולח...', true);
  EventLog.log(EventLog.TYPE.SEND_ATTEMPTED, { phone, msgLen: text.length, source: 'manual_test' });
  const startMs = Date.now();

  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'SEND_MESSAGE', phone, text });
    if (resp && resp.success) {
      const r = resp.result;
      Safety.recordSuccess(safetyState, r.ack);
      await Safety.saveState(safetyState);
      EventLog.log(EventLog.TYPE.SEND_SUCCESS, {
        phone,
        method: r.method,
        ack: r.ack,
        durationMs: Date.now() - startMs,
        source: 'manual_test'
      });
      showResult(`רוני: נשלח ✔\nשיטה: ${r.method}\nack: ${r.ack ?? '—'}\nmsgId: ${r.msgId ?? '—'}`, true);

      // Soft-block check
      const risk = Safety.detectSoftBlockRisk(safetyState);
      if (risk.level >= 2) {
        EventLog.log(EventLog.TYPE.SOFT_BLOCK_DETECTED, { risk });
      }
    } else {
      const errMsg = resp?.error || 'unknown';
      Safety.recordFailure(safetyState, errMsg);
      await Safety.saveState(safetyState);
      EventLog.log(EventLog.TYPE.SEND_FAILED, {
        phone, error: errMsg, durationMs: Date.now() - startMs, source: 'manual_test'
      });
      if (safetyState.circuit !== 'OK') {
        EventLog.log(EventLog.TYPE.CIRCUIT_OPENED, { reason: safetyState.circuitReason });
      }
      showResult(`רוני נתקל בבעיה: ${errMsg}`, false);
    }
  } catch (err) {
    EventLog.log(EventLog.TYPE.SEND_FAILED, {
      phone, error: 'COMM:' + err.message, durationMs: Date.now() - startMs, source: 'manual_test'
    });
    showResult(`רוני לא הצליח לתקשר: ${err.message}`, false);
  } finally {
    btn.disabled = false;
    renderCircuitBanner();
  }
}

async function rebuildStore() {
  const tab = await getWaTab();
  if (!tab) { showResult('רוני צריך שתפתח קודם את web.whatsapp.com', false); return; }
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: 'REBUILD_STORE' });
    if (resp && resp.success) {
      showResult(`רוני התעורר: hasStore=${resp.result.hasStore} hasChat=${resp.result.hasChat}`, resp.result.hasChat);
    } else {
      showResult(`רוני לא הצליח להתעורר: ${resp?.error || 'לא ידוע'}`, false);
    }
  } catch (err) {
    showResult(`רוני נתקל בשגיאה: ${err.message}`, false);
  }
}

// ---------- tab counts ----------
function updateTabCounts() {
  $('#tab-count-contacts').textContent = state.contacts.length || '';
  const set = activeSet();
  $('#tab-count-templates').textContent = set ? set.templates.length : '';
}

// ---------- init ----------
function isEmbeddedInWAPanel() {
  try {
    return window !== window.top && new URLSearchParams(location.search).get('embed') === 'wapanel';
  } catch { return false; }
}

document.addEventListener('DOMContentLoaded', async () => {
  // Hide the "open side panel" button when running inside WA Web's injected panel
  if (isEmbeddedInWAPanel()) {
    document.body.classList.add('embedded');
    const sidePanelBtn = document.getElementById('btn-side-panel');
    if (sidePanelBtn) sidePanelBtn.style.display = 'none';
  }

  await loadContactsState();
  await loadLibrary();

  $$('.tab').forEach(t => t.addEventListener('click', () => activateTab(t.dataset.tab)));

  // contacts — file
  $('#file-upload').addEventListener('change', handleFile);
  $('#btn-clear-contacts').addEventListener('click', clearContacts);

  // contacts — sources
  $('#src-bi').addEventListener('click', openBiModal);
  $('#src-shared').addEventListener('click', loadShared);
  $('#src-wa').addEventListener('click', importFromWA);
  $('#src-file').addEventListener('click', () => $('#file-upload').click());

  // BI modal
  $('#bi-modal-close').addEventListener('click', closeBiModal);
  $('#bi-modal').addEventListener('click', (e) => { if (e.target.id === 'bi-modal') closeBiModal(); });
  $('#bi-load-active').addEventListener('click', biLoadActive);
  $('#bi-load-shared').addEventListener('click', biLoadShared);
  $('#bi-search').addEventListener('input', () => updateBiSummary());

  // templates / library
  $('#btn-new-set').addEventListener('click', newEmptySet);
  $('#btn-add-template').addEventListener('click', addVariantToActive);
  $('#btn-save-set').addEventListener('click', saveActiveSet);
  $('#btn-delete-set').addEventListener('click', deleteActiveSet);

  // AI modal
  $('#btn-ai-create').addEventListener('click', openAiModal);
  $('#ai-modal-close').addEventListener('click', closeAiModal);
  $('#ai-generate').addEventListener('click', () => aiGenerate(5));
  $('#ai-generate-3').addEventListener('click', () => aiGenerate(3));
  $('#ai-regenerate').addEventListener('click', () => aiGenerate(state.aiResult?.templates?.length || 5));
  $('#ai-save').addEventListener('click', aiSaveAsSet);
  $('#ai-modal').addEventListener('click', (e) => {
    if (e.target.id === 'ai-modal') closeAiModal();
  });

  // settings
  $('#btn-save-settings').addEventListener('click', saveSettings);
  $('#btn-test-api').addEventListener('click', testApi);

  // side panel
  $('#btn-side-panel')?.addEventListener('click', async () => {
    try {
      await chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL' });
      window.close();
    } catch (e) { alert('לא הצלחתי לפתוח סרגל צד: ' + e.message); }
  });

  // preview
  $('#btn-refresh-preview').addEventListener('click', renderPreview);

  // test / manual send
  $('#btn-send-one').addEventListener('click', sendOne);
  $('#btn-rebuild-store').addEventListener('click', rebuildStore);
  $('#btn-refresh-status').addEventListener('click', refreshStatus);
  let lookupTimer = null;
  $('#manual-lookup').addEventListener('input', () => {
    clearTimeout(lookupTimer);
    lookupTimer = setTimeout(manualLookup, 200);
  });
  $('#manual-clear').addEventListener('click', clearManualResolved);

  // insights
  $('#btn-export-events').addEventListener('click', exportEventsCsv);
  $('#btn-clear-events').addEventListener('click', clearEventsLog);

  // send tab
  $('#btn-send-now').addEventListener('click', sendNow);
  $('#btn-schedule').addEventListener('click', openScheduleModal);
  $('#schedule-modal-close').addEventListener('click', closeScheduleModal);
  $('#btn-confirm-schedule').addEventListener('click', confirmSchedule);
  $('#schedule-modal').addEventListener('click', (e) => {
    if (e.target.id === 'schedule-modal') closeScheduleModal();
  });
  $('#btn-pause-queue').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'QUEUE_PAUSE' });
    refreshQueueCard();
  });
  $('#btn-resume-queue').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'QUEUE_RESUME' });
    refreshQueueCard();
  });
  $('#btn-cancel-queue').addEventListener('click', async () => {
    if (!confirm('רוני יבטל את הסבב. ההודעות שכבר נשלחו יישארו. להמשיך?')) return;
    await chrome.runtime.sendMessage({ type: 'QUEUE_CANCEL' });
    refreshQueueCard();
  });

  renderContacts();
  renderSetsList();
  renderSetEditor();
  updateTabCounts();
  refreshStatus();
  renderCircuitBanner();
  initUpdater();
  refreshSourceCards();

  // Log that the extension was opened (useful for engagement metrics)
  EventLog.log(EventLog.TYPE.EXTENSION_OPENED);

  // Refresh circuit banner periodically while popup is open
  setInterval(renderCircuitBanner, 30000);

  // If queue is running, refresh send tab live
  setInterval(() => {
    if (document.querySelector('.tab.active')?.dataset.tab === 'send') refreshQueueCard();
  }, 4000);

  // Start central telemetry shipping (no-op if config has CHANGE-ME placeholders)
  Telemetry.startAutoShipping();
});

// ---------- send tab (queue + scheduling) ----------
async function renderSendTab() {
  const set = activeSet();
  const recipients = state.contacts.filter(c => c.status === 'pending').length;
  const safety = await Safety.loadState();
  const profile = Safety.PROFILES[safety.profile];

  $('#send-recipients').textContent = recipients;
  $('#send-active-set').textContent = set ? `${set.icon}` : '—';
  // ETA = recipients * median delay seconds
  if (recipients) {
    const etaSec = recipients * Math.exp(profile.delayMu);
    const m = Math.round(etaSec / 60);
    $('#send-eta').textContent = m < 60 ? `~${m}ד׳` : `~${(m/60).toFixed(1)}ש׳`;
  } else {
    $('#send-eta').textContent = '—';
  }

  // Hint area
  const hint = $('#send-hint');
  if (!set) hint.innerHTML = '⚠️ אין סט פעיל — בחר/י סט בטאב <strong>✏️</strong>';
  else if (!recipients) hint.innerHTML = '⚠️ אין נמענים — טען/י קובץ בטאב <strong>📋</strong>';
  else hint.innerHTML = `רוני ישלח ${recipients} הודעות בפרופיל ${profile.label}, רוטציה בין ${set.templates.length} וריאציות.`;

  const enabled = !!(set && recipients);
  $('#btn-send-now').disabled = !enabled;
  $('#btn-schedule').disabled = !enabled;

  // Render queue + schedules state
  await refreshQueueCard();
  await refreshSchedulesCard();
}

async function refreshQueueCard() {
  const status = await chrome.runtime.sendMessage({ type: 'QUEUE_STATUS' });
  const card = $('#queue-card');
  if (!status || !status.exists || status.status === 'completed' || status.status === 'cancelled') {
    card.style.display = 'none';
    return;
  }
  card.style.display = 'block';
  const c = status.counts;
  $('#queue-counts').textContent = `${c.sent}/${status.total} נשלחו · ${c.failed} כשלים`;
  $('#queue-progress').style.width = `${Math.round((c.sent / status.total) * 100)}%`;

  const labelMap = { running: '⏳ רוני שולח...', paused: '⏸️ מושהה', idle: '⏸️ ממתין' };
  $('#queue-status-label').textContent = labelMap[status.status] || status.status;

  if (status.nextItem) {
    $('#queue-next').textContent = `הבא: ${status.nextItem.name} (${status.nextItem.phone.slice(-4)})`;
  } else {
    $('#queue-next').textContent = '';
  }

  $('#btn-pause-queue').style.display = status.status === 'running' ? '' : 'none';
  $('#btn-resume-queue').style.display = status.status === 'paused' ? '' : 'none';

  // Recent items
  // (We don't have direct access to queue items here — fetch via storage)
  const { 'roni:queue': q } = await chrome.storage.local.get(['roni:queue']);
  if (q) {
    const recent = q.items.filter(i => i.status === 'sent' || i.status === 'failed').slice(-5).reverse();
    $('#queue-recent').innerHTML = recent.map(it => `
      <div class="recent-row">
        <span class="badge-mini ${it.status}">${it.status === 'sent' ? '✔' : '✗'}</span>
        <span style="flex:1;">${escapeHtml(it.name)}</span>
        <span style="color:#999; font-family:monospace;">${it.phone.slice(-4)}</span>
      </div>
    `).join('');
  }
}

async function refreshSchedulesCard() {
  const r = await chrome.runtime.sendMessage({ type: 'SCHEDULE_LIST' });
  const card = $('#schedules-card');
  const list = $('#schedules-list');
  const upcoming = (r?.schedules || []).filter(s => s.status === 'pending');
  if (!upcoming.length) { card.style.display = 'none'; return; }
  card.style.display = 'block';
  list.innerHTML = upcoming.map(s => `
    <div class="schedule-row">
      <span class="when">${new Date(s.at).toLocaleString('he-IL', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
      <span class="label">${escapeHtml(s.label || '(ללא תווית)')}</span>
      <span class="count">${s.payload.items.length}</span>
      <button class="btn-danger" data-cancel-id="${s.id}">בטל</button>
    </div>
  `).join('');
  list.querySelectorAll('[data-cancel-id]').forEach(btn => {
    btn.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'SCHEDULE_CANCEL', payload: btn.dataset.cancelId });
      refreshSchedulesCard();
    });
  });
}

function buildQueuePayload() {
  const set = activeSet();
  if (!set) return null;
  const valid = set.templates.filter(t => t && t.trim());
  if (!valid.length) return null;
  const rotator = new TemplateEngine.Rotator(valid);
  const items = state.contacts.filter(c => c.status === 'pending').map(c => {
    const { index, text } = rotator.renderForContact(c);
    return {
      contactId: c.id,
      phone: c.phone,
      name: c.name,
      text,
      setId: set.id,
      templateIdx: index
    };
  });
  return { items, profile: 'balanced', source: 'send_now', setId: set.id };
}

async function sendNow() {
  const payload = buildQueuePayload();
  if (!payload || !payload.items.length) return;
  const r = await chrome.runtime.sendMessage({ type: 'QUEUE_START', payload });
  if (!r?.ok) {
    alert('שגיאה בהתחלת התור: ' + (r?.error || 'unknown'));
    return;
  }
  await renderSendTab();
}

function openScheduleModal() {
  // Default to "tomorrow at 09:00"
  const tomorrow = new Date(Date.now() + 24 * 3600 * 1000);
  $('#schedule-date').value = tomorrow.toISOString().slice(0, 10);
  $('#schedule-time').value = '09:00';
  $('#schedule-label').value = activeSet()?.name || '';
  $('#schedule-result').style.display = 'none';
  $('#schedule-modal').style.display = 'flex';
}

function closeScheduleModal() {
  $('#schedule-modal').style.display = 'none';
}

async function confirmSchedule() {
  const date = $('#schedule-date').value;
  const time = $('#schedule-time').value;
  const label = $('#schedule-label').value.trim();
  if (!date || !time) {
    showScheduleResult('בחר תאריך ושעה', false);
    return;
  }
  const at = new Date(`${date}T${time}:00`).getTime();
  if (at < Date.now() + 60 * 1000) {
    showScheduleResult('הזמן צריך להיות לפחות דקה מעכשיו', false);
    return;
  }
  const payload = buildQueuePayload();
  if (!payload || !payload.items.length) {
    showScheduleResult('אין נמענים או סט פעיל', false);
    return;
  }
  payload.source = 'scheduled';
  const r = await chrome.runtime.sendMessage({
    type: 'SCHEDULE_AT',
    payload: { at, label, payload }
  });
  if (r?.ok) {
    showScheduleResult(`✔ נקבע! רוני יתחיל ב-${new Date(at).toLocaleString('he-IL')}`, true);
    setTimeout(() => { closeScheduleModal(); renderSendTab(); }, 1500);
  } else {
    showScheduleResult('שגיאה: ' + (r?.error || 'unknown'), false);
  }
}

function showScheduleResult(msg, ok) {
  const box = $('#schedule-result');
  box.style.display = 'block';
  box.textContent = msg;
  box.className = 'result-box ' + (ok ? 'ok' : 'err');
}

// ---------- safety + circuit banner ----------
async function renderCircuitBanner() {
  const s = await Safety.loadState();
  const banner = $('#circuit-banner');
  const profile = Safety.PROFILES[s.profile] || Safety.PROFILES.balanced;

  const wh = Safety.checkWorkingHours(s.workingHours);
  const warmup = Warmup.status(await Warmup.load());
  let cls = 'ok';
  let msg = '';
  let actionBtn = '';

  if (s.circuit === 'OPEN_24H') {
    cls = 'open';
    const remaining = Math.max(0, s.circuitSince + 24 * 3600 * 1000 - Date.now());
    const hrs = Math.floor(remaining / 3600000);
    const min = Math.floor((remaining % 3600000) / 60000);
    msg = `🛑 רוני נעצר ל-24 שעות. נותרו: ${hrs}ש ${min}ד`;
  } else if (s.circuit === 'COOLING_10MIN') {
    cls = 'cooling';
    const remaining = Math.max(0, s.circuitSince + 10 * 60 * 1000 - Date.now());
    const min = Math.ceil(remaining / 60000);
    msg = `⏸️ עצירת קירור. נותרו ${min} דקות`;
  } else if (s.circuit === 'WARNING') {
    cls = 'warn';
    msg = `⚠️ רוני מבקש אישור להמשיך — היה כשל קודם`;
    actionBtn = `<button id="btn-clear-circuit">המשך בכל זאת</button>`;
  } else if (!wh.ok) {
    cls = 'warn';
    msg = `🌙 ${Safety.reasonText(wh.reason)}`;
  } else {
    const risk = Safety.detectSoftBlockRisk(s);
    if (risk.level >= 2) {
      cls = 'warn';
      msg = `⚠️ סיכון soft-block (רמה ${risk.level}/3). שקול להפסיק עכשיו.`;
    } else {
      cls = 'ok';
      const effectiveCap = warmup.active && warmup.cap ? warmup.cap : profile.dailyCap;
      const warmupTag = warmup.active ? ` · 🌡️ חימום יום ${warmup.day}` : '';
      msg = `✔ ${profile.label} · ${s.dailyCount}/${effectiveCap} היום · סשן ${s.sessionCount}/${profile.sessionCap}${warmupTag}`;
    }
  }

  banner.className = 'circuit-banner ' + cls;
  banner.innerHTML = `<span class="msg">${msg}</span> ${actionBtn}`;
  banner.style.display = 'flex';

  if (actionBtn) {
    $('#btn-clear-circuit').addEventListener('click', async () => {
      const st = await Safety.loadState();
      Safety.clearCircuit(st);
      await Safety.saveState(st);
      EventLog.log(EventLog.TYPE.CIRCUIT_CLOSED, { reason: 'USER_ACK' });
      renderCircuitBanner();
    });
  }
}

// ---------- insights tab ----------
async function renderInsights() {
  const s = await Insights.summary();
  const summary = $('#insights-summary');
  summary.innerHTML = `
    <div class="insight-card"><span class="num">${s.sentToday}</span><span class="label">נשלחו היום</span></div>
    <div class="insight-card"><span class="num">${s.sentWeek}</span><span class="label">השבוע</span></div>
    <div class="insight-card"><span class="num">${s.successRateWeek ?? '—'}${s.successRateWeek != null ? '%' : ''}</span><span class="label">הצלחה</span></div>
    <div class="insight-card"><span class="num">${s.failedToday}</span><span class="label">נכשלו היום</span></div>
    <div class="insight-card"><span class="num">${s.softBlocksWeek}</span><span class="label">soft-block שבוע</span></div>
    <div class="insight-card"><span class="num">${s.aiUsesWeek}</span><span class="label">גנרציות AI</span></div>
  `;

  // Heatmap
  const hm = await Insights.sendsHeatmap();
  const heatmap = $('#insights-heatmap');
  const dayNames = ['היום', 'אתמול', 'לפני 2', 'לפני 3', 'לפני 4', 'לפני 5', 'לפני 6'];
  const cells = ['<div class="heatmap-grid">', '<div class="heatmap-label"></div>'];
  for (let h = 0; h < 24; h++) cells.push(`<div class="heatmap-label">${h}</div>`);
  for (let d = 0; d < 7; d++) {
    cells.push(`<div class="heatmap-row-label">${dayNames[d]}</div>`);
    for (let h = 0; h < 24; h++) {
      const v = hm.grid[d][h];
      const intensity = v / hm.max;
      const bg = v === 0 ? '#eee' : `rgba(37, 211, 102, ${0.2 + intensity * 0.8})`;
      cells.push(`<div class="heatmap-cell" style="background:${bg};" title="${v} שליחות"></div>`);
    }
  }
  cells.push('</div>');
  heatmap.innerHTML = cells.join('');

  // Sets usage
  const setsUsage = await Insights.templateSetUsage();
  const setsBox = $('#insights-sets');
  if (!setsUsage.length) {
    setsBox.innerHTML = '<div class="hint" style="padding:8px;">אין נתוני שימוש עדיין.</div>';
  } else {
    const totalUses = setsUsage.reduce((a, b) => a + b.count, 0);
    setsBox.innerHTML = setsUsage.map(u => {
      const set = state.sets.find(s => s.id === u.setId);
      const name = set ? `${set.icon} ${escapeHtml(set.name)}` : `(נמחק)`;
      const pct = Math.round((u.count / totalUses) * 100);
      return `<div style="display:flex; align-items:center; gap:6px; margin:4px 0; font-size:11px;">
        <div style="flex:1;">${name}</div>
        <div style="width:40px; text-align:left;"><strong>${u.count}</strong> (${pct}%)</div>
        <div style="flex:0 0 80px; background:#eee; border-radius:3px; height:8px;"><div style="background:#25D366; height:100%; width:${pct}%; border-radius:3px;"></div></div>
      </div>`;
    }).join('');
  }

  // Forensics
  const forensics = await Insights.preCircuitForensics();
  const fbox = $('#insights-forensics');
  if (!forensics.length) {
    fbox.innerHTML = '<div class="hint" style="padding:8px;">✔ אין אירועי circuit. המשך כך.</div>';
  } else {
    fbox.innerHTML = forensics.slice(-5).reverse().map(f => `
      <div class="forensic-item">
        <strong>${new Date(f.openedAt).toLocaleString('he-IL')}</strong> · ${escapeHtml(Safety.reasonText(f.reason || ''))}
        <br><small>10 דק׳ לפני: ${f.sendsBefore} שליחות · ${f.failuresBefore} כשלים · ${f.events} אירועים בסה"כ</small>
      </div>
    `).join('');
  }

  // Raw event list
  const events = await EventLog.getLast(40);
  $('#events-list').innerHTML = events.map(e => `
    <div class="event-row">
      <span class="ts">${new Date(e.t).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}</span>
      <span class="type">${e.type}</span>
      <span class="data">${escapeHtml(JSON.stringify(Object.fromEntries(Object.entries(e).filter(([k]) => !['t','type','v'].includes(k)))).slice(0, 80))}</span>
    </div>
  `).join('');
}

async function exportEventsCsv() {
  const csv = await EventLog.toCsv();
  const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `roni-events-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

async function clearEventsLog() {
  if (!confirm('רוני ימחק את כל יומן האירועים. ההיסטוריה תאבד. להמשיך?')) return;
  await EventLog.clear();
  renderInsights();
}

// ---------- safety profile + working hours UI ----------
async function renderSafetyControls() {
  const s = await Safety.loadState();

  // profile selector
  const sel = $('#safety-profile');
  sel.innerHTML = Object.entries(Safety.PROFILES).map(([k, p]) =>
    `<option value="${k}" ${k === s.profile ? 'selected' : ''}>${p.label}</option>`
  ).join('');
  $('#safety-profile-desc').textContent =
    Safety.PROFILES[s.profile].desc + ` · תקרה ${Safety.PROFILES[s.profile].dailyCap}/יום, סשן ${Safety.PROFILES[s.profile].sessionCap}.`;
  sel.onchange = async () => {
    s.profile = sel.value;
    await Safety.saveState(s);
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'profile', value: sel.value });
    $('#safety-profile-desc').textContent =
      Safety.PROFILES[s.profile].desc + ` · תקרה ${Safety.PROFILES[s.profile].dailyCap}/יום, סשן ${Safety.PROFILES[s.profile].sessionCap}.`;
    renderCircuitBanner();
  };

  // working hours
  $('#wh-enabled').checked = !!s.workingHours.enabled;
  $('#wh-start').value = s.workingHours.startHour;
  $('#wh-end').value = s.workingHours.endHour;

  const dayNames = ['א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ש'];
  $('#wh-days').innerHTML = dayNames.map((n, i) =>
    `<span class="day-chip ${s.workingHours.days.includes(i) ? 'active' : ''}" data-day="${i}">${n}</span>`
  ).join('');
  $('#wh-days').querySelectorAll('.day-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      const st = await Safety.loadState();
      const d = +chip.dataset.day;
      st.workingHours.days = st.workingHours.days.includes(d)
        ? st.workingHours.days.filter(x => x !== d)
        : [...st.workingHours.days, d].sort();
      await Safety.saveState(st);
      EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, { setting: 'working_days', value: st.workingHours.days });
      renderSafetyControls();
      renderCircuitBanner();
    });
  });

  const onWHChange = async () => {
    const st = await Safety.loadState();
    st.workingHours.enabled = $('#wh-enabled').checked;
    st.workingHours.startHour = Math.max(0, Math.min(23, +$('#wh-start').value || 9));
    st.workingHours.endHour = Math.max(0, Math.min(23, +$('#wh-end').value || 18));
    await Safety.saveState(st);
    EventLog.log(EventLog.TYPE.SETTINGS_CHANGED, {
      setting: 'working_hours',
      enabled: st.workingHours.enabled,
      start: st.workingHours.startHour,
      end: st.workingHours.endHour
    });
    renderCircuitBanner();
  };
  $('#wh-enabled').onchange = onWHChange;
  $('#wh-start').onchange = onWHChange;
  $('#wh-end').onchange = onWHChange;
}

// ---------- updater ----------
async function initUpdater() {
  // Show actual manifest version in header
  const v = chrome.runtime.getManifest().version;
  $('#version').textContent = `v${v}`;

  let result;
  try { result = await Updater.check(); } catch { return; }
  if (!result || !result.hasUpdate) return;

  const dismissedKey = 'roni:updateDismissed:' + result.latest;
  const dismissed = await new Promise(r => chrome.storage.local.get([dismissedKey], d => r(d[dismissedKey])));
  if (dismissed && !result.mandatory) return;

  const banner = $('#update-banner');
  const msg = banner.querySelector('.update-msg');
  const link = $('#update-link');

  msg.innerHTML = `<strong>🆕 גרסה ${escapeHtml(result.latest)} זמינה</strong>
    <small>אחרי הורדה: חלץ ל-<code>C:\\Roni\\</code> ולחץ Ctrl+R</small>`;

  if (result.downloadUrl) {
    link.href = result.downloadUrl;
    link.style.display = '';
  } else {
    link.style.display = 'none';
  }
  banner.style.display = 'flex';

  $('#update-dismiss').addEventListener('click', () => {
    chrome.storage.local.set({ [dismissedKey]: true });
    banner.style.display = 'none';
  });
}
