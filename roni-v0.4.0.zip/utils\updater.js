// utils/updater.js — checks for new versions and exposes a banner state.
// Loaded as a regular <script> in popup; namespace Updater.

const Updater = (() => {
  const STORAGE_KEY = 'roni:updateCheck';

  function currentVersion() {
    return chrome.runtime.getManifest().version;
  }

  // Compare semver-ish strings: '0.4.1' > '0.3.10'
  function isNewer(remote, local) {
    const a = String(remote).split('.').map(n => parseInt(n, 10) || 0);
    const b = String(local).split('.').map(n => parseInt(n, 10) || 0);
    const len = Math.max(a.length, b.length);
    for (let i = 0; i < len; i++) {
      const ai = a[i] || 0;
      const bi = b[i] || 0;
      if (ai > bi) return true;
      if (ai < bi) return false;
    }
    return false;
  }

  function getCachedCheck() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (data) => {
        resolve(data[STORAGE_KEY] || null);
      });
    });
  }

  function setCachedCheck(payload) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [STORAGE_KEY]: payload }, resolve);
    });
  }

  function shouldRecheck(cached) {
    if (!cached) return true;
    const intervalMs = (RONI_CONFIG.updateCheckIntervalHours || 6) * 3600 * 1000;
    return (Date.now() - (cached.checkedAt || 0)) > intervalMs;
  }

  // Returns { hasUpdate, latest, current, downloadUrl, notes } or null if disabled / no update.
  async function check({ force = false } = {}) {
    if (!RONI_CONFIG.updateCheckUrl) return null;
    if (RONI_CONFIG.githubUser && RONI_CONFIG.githubUser.includes('CHANGE-ME')) {
      // Updater not configured yet — skip silently.
      return null;
    }

    const cached = await getCachedCheck();
    if (!force && cached && !shouldRecheck(cached)) {
      return formatResult(cached.payload);
    }

    let payload;
    try {
      const res = await fetch(RONI_CONFIG.updateCheckUrl, {
        cache: 'no-store',
        headers: { 'cache-control': 'no-cache' }
      });
      if (!res.ok) throw new Error(`HTTP_${res.status}`);
      payload = await res.json();
    } catch (err) {
      // Network or parse error — keep cached, just return current.
      return cached ? formatResult(cached.payload) : null;
    }

    await setCachedCheck({ checkedAt: Date.now(), payload });
    return formatResult(payload);
  }

  function formatResult(payload) {
    if (!payload || !payload.version) return null;
    const current = currentVersion();
    const latest = String(payload.version);
    const hasUpdate = isNewer(latest, current);

    let downloadUrl = payload.downloadUrl;
    if (!downloadUrl && payload.zipFilename) {
      downloadUrl = (RONI_CONFIG.releasesBaseUrl || '') + payload.zipFilename;
    }

    return {
      hasUpdate,
      latest,
      current,
      downloadUrl: downloadUrl || null,
      notes: payload.notes || '',
      releasedAt: payload.releasedAt || null,
      mandatory: !!payload.mandatory
    };
  }

  return { check, isNewer, currentVersion };
})();

if (typeof window !== 'undefined') window.Updater = Updater;
