// content-main.js — runs in MAIN world of web.whatsapp.com.
// Responsible for: Store API injection (primary send path) and DOM fallback.
// Talks to content-isolated.js via window.postMessage.
//
// Inspired by whatsapp-web.js (MIT) — github.com/pedroslopez/whatsapp-web.js

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  // ---------- moduleRaid: capture every webpack module ----------
  // WA Web is a webpack bundle. We push a fake chunk that requires every module
  // and captures the module exports map. From there we search by signature.
  let modulesCache = null;

  function captureModules() {
    if (modulesCache) return modulesCache;
    const chunkName = Object.keys(window).find(k => k.startsWith('webpackChunk'));
    if (!chunkName) return null;
    const chunk = window[chunkName];

    const modules = {};
    const chunkId = 'getjob_' + Date.now();
    chunk.push([
      [chunkId],
      {},
      (req) => {
        for (const id of Object.keys(req.m || {})) {
          try {
            const mod = req(id);
            if (mod) modules[id] = mod;
          } catch (_) { /* skip */ }
        }
      }
    ]);
    modulesCache = modules;
    return modules;
  }

  // ---------- find specific Store pieces by signature ----------
  function findModule(modules, predicate) {
    for (const id of Object.keys(modules)) {
      const m = modules[id];
      if (!m) continue;
      try {
        if (predicate(m)) return m;
        if (m.default && predicate(m.default)) return m.default;
      } catch (_) { /* skip */ }
    }
    return null;
  }

  let Store = null;

  function buildStore() {
    if (Store) return Store;
    const modules = captureModules();
    if (!modules) return null;

    Store = {};

    // Chat collection — has .find / .get / ._models
    Store.Chat = findModule(modules, m =>
      m && m.Chat && typeof m.Chat.find === 'function'
    );
    if (Store.Chat) Store.Chat = Store.Chat.Chat;
    if (!Store.Chat) {
      Store.Chat = findModule(modules, m =>
        m && typeof m.find === 'function' && m._models &&
        m._models[0] && m._models[0].constructor && m._models[0].constructor.name === 'Chat'
      );
    }

    // Wid factory — modern path: WidFactory.createWid('123@c.us')
    Store.WidFactory = findModule(modules, m =>
      m && typeof m.createWid === 'function' && typeof m.createWidFromWidLike === 'function'
    );

    // SendMessage — the chat-instance .sendMessage method handles this for us,
    // but we also keep a reference to a direct sender for diagnostics.
    Store.SendTextMsgToChat = findModule(modules, m =>
      m && typeof m === 'function' && /SendTextMsgToChat|sendTextMsgToChat/.test(m.toString())
    );

    // Connection state — Stream.displayInfo === 'CONNECTED'
    Store.Stream = findModule(modules, m =>
      m && typeof m.displayInfo === 'string' && typeof m.mode === 'string'
    );

    // Number existence check (WapQuery in older builds, Wap2 in newer)
    Store.WapQuery = findModule(modules, m =>
      m && (typeof m.queryWidExists === 'function' || typeof m.queryExist === 'function')
    );

    return Store;
  }

  // ---------- send via Store (primary) ----------
  async function sendViaStore(phone, text) {
    const S = buildStore();
    if (!S || !S.Chat || !S.WidFactory) {
      throw new Error('STORE_UNAVAILABLE');
    }

    const jid = `${phone}@c.us`;
    const wid = S.WidFactory.createWid(jid);

    // verify number exists on WhatsApp before opening a chat
    if (S.WapQuery) {
      try {
        const q = S.WapQuery.queryWidExists || S.WapQuery.queryExist;
        const res = await q(wid);
        const exists = res && (res.wid || res.jid || res === true);
        if (!exists) throw new Error('NUMBER_NOT_ON_WHATSAPP');
      } catch (e) {
        if (e.message === 'NUMBER_NOT_ON_WHATSAPP') throw e;
        // queryExists itself failed — proceed anyway, Chat.find may still work
      }
    }

    let chat = S.Chat.get && S.Chat.get(wid);
    if (!chat) {
      chat = await S.Chat.find(wid);
    }
    if (!chat) throw new Error('CHAT_NOT_FOUND');

    // sendMessage on the chat model — returns an ack-bearing object
    const result = await chat.sendMessage(text);
    return {
      method: 'store',
      ack: (result && result.ack) ?? null,
      msgId: (result && result.id && result.id._serialized) || null
    };
  }

  // ---------- DOM fallback (no wa.me/send) ----------
  // Find chat via the in-app search box, then type into compose box and Enter.
  async function sendViaDom(phone, text) {
    // Open new-chat search via search button (aria-label changes by locale!)
    const searchBtn =
      document.querySelector('[aria-label="חיפוש או צ\'אט חדש"]') ||
      document.querySelector('[aria-label="Search or start new chat"]') ||
      document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="3"]');

    let searchBox = document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="3"]');
    if (!searchBox && searchBtn) {
      searchBtn.click();
      await sleep(300);
      searchBox = document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="3"]');
    }
    if (!searchBox) throw new Error('SEARCH_BOX_NOT_FOUND');

    searchBox.focus();
    document.execCommand('insertText', false, phone);
    await sleep(800);

    // Press Enter on the first matching contact (WA opens it)
    const firstResult = document.querySelector('[role="listitem"][tabindex="-1"]') ||
                        document.querySelector('div[role="grid"] [role="row"]');
    if (!firstResult) throw new Error('NO_CONTACT_MATCH');
    firstResult.click();
    await sleep(700);

    // Compose box
    const compose = document.querySelector('div[role="textbox"][contenteditable="true"][data-tab="10"]') ||
                    document.querySelector('footer div[contenteditable="true"]');
    if (!compose) throw new Error('COMPOSE_NOT_FOUND');
    compose.focus();

    // Type one char at a time with jitter (slightly more human than paste)
    for (const ch of text) {
      document.execCommand('insertText', false, ch);
      await sleep(40 + Math.random() * 80);
    }
    await sleep(300);

    // Enter to send
    compose.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    await sleep(800);
    return { method: 'dom', ack: null, msgId: null };
  }

  // ---------- top-level send: hybrid ----------
  async function send(phone, text) {
    try {
      return await sendViaStore(phone, text);
    } catch (storeErr) {
      console.warn(TAG, 'Store failed, falling back to DOM:', storeErr.message);
      try {
        const r = await sendViaDom(phone, text);
        r.storeError = storeErr.message;
        return r;
      } catch (domErr) {
        throw new Error(`STORE_AND_DOM_FAILED: store=${storeErr.message} dom=${domErr.message}`);
      }
    }
  }

  function getConnectionState() {
    const S = buildStore();
    if (!S || !S.Stream) return 'unknown';
    return S.Stream.displayInfo || 'unknown';
  }

  function isReady() {
    return getConnectionState() === 'CONNECTED';
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- bridge: window.postMessage <-> isolated world ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;

    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        respond({ ok: true, result: { ready: isReady(), state: getConnectionState() } });
      } else if (action === 'rebuildStore') {
        modulesCache = null;
        Store = null;
        const S = buildStore();
        respond({ ok: true, result: { hasStore: !!S, hasChat: !!(S && S.Chat) } });
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  // attempt eager Store build once page is interactive
  const tryInit = () => { try { buildStore(); } catch (_) {} };
  if (document.readyState === 'complete') {
    setTimeout(tryInit, 2000);
  } else {
    window.addEventListener('load', () => setTimeout(tryInit, 2000));
  }

  console.log(TAG, 'injected (MAIN world)');
})();
