// service-worker.js — minimal in Phase 1. Expanded in Phase 4.

const TAG = '[GetJob/bg]';

chrome.runtime.onInstalled.addListener(() => {
  console.log(TAG, 'installed');
});

// In Phase 1 the popup talks directly to the WA Web tab via chrome.tabs.sendMessage.
// The service worker only proxies status checks and (later) owns the queue.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'BG_PING') {
    sendResponse({ ok: true, ts: Date.now() });
    return false;
  }
  return false;
});
