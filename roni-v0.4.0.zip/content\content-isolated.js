// content-isolated.js — runs in ISOLATED world.
// Bridges chrome.runtime <-> the MAIN-world script via window.postMessage.

(function () {
  'use strict';

  const TAG = '[GetJob/iso]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  let nextId = 1;
  const pending = new Map();

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== RES || !msg.id) return;

    const cb = pending.get(msg.id);
    if (cb) {
      pending.delete(msg.id);
      cb(msg.data);
    }
  });

  function callMain(action, payload, timeoutMs = 60000) {
    return new Promise((resolve, reject) => {
      const id = nextId++;
      const timer = setTimeout(() => {
        if (pending.has(id)) {
          pending.delete(id);
          reject(new Error('MAIN_TIMEOUT'));
        }
      }, timeoutMs);
      pending.set(id, (data) => {
        clearTimeout(timer);
        if (!data) return reject(new Error('NO_DATA'));
        if (!data.ok) return reject(new Error(data.error || 'UNKNOWN'));
        resolve(data.result);
      });
      window.postMessage({ type: REQ, id, action, payload }, '*');
    });
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return false;

    if (msg.type === 'SEND_MESSAGE') {
      callMain('send', { phone: msg.phone, text: msg.text }, 90000)
        .then(result => sendResponse({ success: true, result }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (msg.type === 'GET_STATUS') {
      callMain('status', {}, 5000)
        .then(result => sendResponse({ success: true, result }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (msg.type === 'REBUILD_STORE') {
      callMain('rebuildStore', {}, 10000)
        .then(result => sendResponse({ success: true, result }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    return false;
  });

  console.log(TAG, 'bridge ready');
})();
