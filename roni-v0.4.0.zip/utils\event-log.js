// utils/event-log.js — append-only structured event log for forensics + insights.
// Stored locally in chrome.storage.local. Capped at 10000 events (~3MB).
// EVERY meaningful action goes through here so we can reconstruct what happened
// before a soft-block / ban.

const EventLog = (() => {
  const STORAGE_KEY = 'roni:events';
  const MAX_EVENTS = 10000;

  // Event types — stable string constants
  const TYPE = {
    SEND_ATTEMPTED: 'send_attempted',
    SEND_SUCCESS: 'send_success',
    SEND_FAILED: 'send_failed',
    SOFT_BLOCK_DETECTED: 'soft_block_detected',
    CIRCUIT_OPENED: 'circuit_opened',
    CIRCUIT_CLOSED: 'circuit_closed',
    BREAK_TAKEN: 'break_taken',
    DAILY_CAP_HIT: 'daily_cap_hit',
    SESSION_CAP_HIT: 'session_cap_hit',
    OUTSIDE_HOURS_BLOCKED: 'outside_hours_blocked',
    CONTACTS_LOADED: 'contacts_loaded',
    CONTACTS_CLEARED: 'contacts_cleared',
    TEMPLATE_SET_CREATED: 'template_set_created',
    TEMPLATE_SET_DELETED: 'template_set_deleted',
    AI_GENERATION: 'ai_generation',
    SETTINGS_CHANGED: 'settings_changed',
    WA_STATUS_CHANGE: 'wa_status_change',
    EXTENSION_OPENED: 'extension_opened',
    UPDATE_AVAILABLE: 'update_available',
    UPDATE_INSTALLED: 'update_installed'
  };

  function load() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (data) => {
        resolve(data[STORAGE_KEY] || []);
      });
    });
  }

  function save(events) {
    return new Promise((r) => chrome.storage.local.set({ [STORAGE_KEY]: events }, r));
  }

  // Phone hashing — store as last-4 digits for partial identification without leaking full number
  function maskPhone(phone) {
    if (!phone) return '';
    const s = String(phone);
    return s.length > 4 ? '...' + s.slice(-4) : s;
  }

  // Append a new event. Always adds: timestamp, version. PII is opt-in via opts.
  async function log(type, data = {}, opts = {}) {
    const events = await load();
    const evt = {
      t: Date.now(),
      type,
      v: chrome.runtime.getManifest().version,
      ...data
    };
    if (data.phone && !opts.fullPhone) {
      evt.phone = maskPhone(data.phone);
    }
    events.push(evt);
    if (events.length > MAX_EVENTS) {
      events.splice(0, events.length - MAX_EVENTS);
    }
    await save(events);
    return evt;
  }

  // --- Query helpers ---
  async function getRange({ from, to, types } = {}) {
    const events = await load();
    return events.filter(e => {
      if (from && e.t < from) return false;
      if (to && e.t > to) return false;
      if (types && !types.includes(e.type)) return false;
      return true;
    });
  }

  async function getLast(n = 50, filter) {
    let events = await load();
    if (filter) events = events.filter(filter);
    return events.slice(-n).reverse();
  }

  async function clear() {
    return save([]);
  }

  async function size() {
    const events = await load();
    return { count: events.length, oldestAt: events[0]?.t || null, newestAt: events[events.length - 1]?.t || null };
  }

  // CSV export for sharing / external analysis
  async function toCsv() {
    const events = await load();
    if (!events.length) return 'timestamp,iso,type,version,details\n';
    const lines = ['timestamp,iso,type,version,details'];
    for (const e of events) {
      const { t, type, v, ...rest } = e;
      const iso = new Date(t).toISOString();
      const detail = JSON.stringify(rest).replace(/"/g, '""');
      lines.push(`${t},${iso},${type},${v},"${detail}"`);
    }
    return lines.join('\n');
  }

  // --- Forensic snapshot: everything an investigator needs around a given moment ---
  async function forensicSnapshot(centerMs = Date.now(), windowMin = 30) {
    const halfMs = windowMin * 60 * 1000;
    const events = await getRange({ from: centerMs - halfMs, to: centerMs + halfMs });
    const safetyState = await new Promise(r => chrome.storage.local.get(['roni:safetyState'], d => r(d['roni:safetyState'])));
    return {
      capturedAt: Date.now(),
      windowMinutes: windowMin,
      around: centerMs,
      events,
      safetyState,
      eventCount: events.length
    };
  }

  return {
    TYPE, log, load, getRange, getLast, clear, size, toCsv, forensicSnapshot, maskPhone
  };
})();

if (typeof window !== 'undefined') window.EventLog = EventLog;
