// utils/ai-generator.js
// Claude API client for generating WhatsApp message variants.
// Loaded as a regular <script> in popup; namespace AIGenerator.

const AIGenerator = (() => {
  const ENDPOINT = 'https://api.anthropic.com/v1/messages';
  const DEFAULT_MODEL = 'claude-haiku-4-5-20251001';
  const API_VERSION = '2023-06-01';

  const SYSTEM_PROMPT = `אתה רוני — עוזר חכם של רכזות שיבוץ עובדים בחברת גטג'וב הישראלית. תפקידך: לייצר וריאציות הודעות WhatsApp בעברית שיישלחו לעובדים זמניים.

חובות נוקשות בכל וריאציה:
- עברית בלבד, טון אנושי ומקצועי
- חייב לכלול {{שם}} (פרסונליזציה — ההגנה הקריטית נגד זיהוי כספאם)
- 30-250 תווים
- פתיחות מגוונות ("שלום", "היי", "הי", "בוקר טוב" וכד׳)
- אמוג׳י לא חובה. אם משתמש — מגוון, לא חוזר על אותו אמוג׳י בכל הוריאציות
- אפשר להשתמש בעיצוב WhatsApp: *מודגש* עבור מילות מפתח, _נטוי_
- כל וריאציה תעביר את אותו מסר ליבה אבל בניסוח טבעי שונה (סדר משפטים שונה, מילים נרדפות, אורכים שונים)
- מותר ורצוי גיוון בלשון פנייה (זכר/נקבה — תמיד נטרלי או הגון לשני המינים, או טופס "אנא מלא/מלאי")
- אם המסר דורש תאריך/שעה ולא נתון לך — השאר {{תאריך}} או {{שעה}} placeholder

אסור:
- אותה פתיחה ב-2+ וריאציות
- העתקה כמעט-זהה בין וריאציות
- טון רובוטי או נוקשה
- שימוש במילים שמעוררות חשד ("הצעה ייחודית", "אל תפספס", spam triggers)

החזר JSON תקין בלבד, ללא טקסט מסביב, בפורמט:
{
  "name": "<שם קצר לסט בעברית, 2-4 מילים>",
  "icon": "<אמוג׳י יחיד שמייצג את המסר>",
  "templates": ["וריאציה 1", "וריאציה 2", "וריאציה 3", "וריאציה 4", "וריאציה 5"]
}`;

  function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.sync.get(['roni:apiKey', 'roni:aiModel'], (data) => {
        resolve({
          apiKey: data['roni:apiKey'] || '',
          model: data['roni:aiModel'] || DEFAULT_MODEL
        });
      });
    });
  }

  function saveSettings({ apiKey, model }) {
    const obj = {};
    if (apiKey != null) obj['roni:apiKey'] = apiKey;
    if (model != null) obj['roni:aiModel'] = model;
    return new Promise((resolve) => chrome.storage.sync.set(obj, resolve));
  }

  async function generateVariants(intent, options = {}) {
    const { apiKey, model } = await getSettings();
    if (!apiKey) throw new Error('NO_API_KEY');
    if (!intent || !intent.trim()) throw new Error('EMPTY_INTENT');

    const numVariants = options.numVariants || 5;

    const userMessage = `המסר שאני רוצה להעביר:
${intent.trim()}

צור ${numVariants} וריאציות הודעה לפי הכללים. החזר JSON בלבד.`;

    const body = {
      model,
      max_tokens: 1500,
      system: SYSTEM_PROMPT,
      messages: [{ role: 'user', content: userMessage }]
    };

    let res;
    try {
      res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': API_VERSION,
          'anthropic-dangerous-direct-browser-access': 'true'
        },
        body: JSON.stringify(body)
      });
    } catch (netErr) {
      throw new Error(`NETWORK: ${netErr.message}`);
    }

    if (!res.ok) {
      let detail = '';
      try {
        const errJson = await res.json();
        detail = errJson?.error?.message || JSON.stringify(errJson);
      } catch (_) {
        detail = await res.text().catch(() => '');
      }
      throw new Error(`API_${res.status}: ${detail}`);
    }

    const data = await res.json();
    const text = (data?.content?.[0]?.text || '').trim();
    if (!text) throw new Error('EMPTY_RESPONSE');

    // Strip markdown code fences if Claude wrapped JSON in ```json ... ```
    const cleaned = text.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '');

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      // try to find a {...} block
      const m = cleaned.match(/\{[\s\S]*\}/);
      if (m) {
        try { parsed = JSON.parse(m[0]); } catch (_) {}
      }
      if (!parsed) throw new Error(`PARSE_FAILED: ${cleaned.slice(0, 200)}`);
    }

    if (!parsed || !Array.isArray(parsed.templates) || !parsed.templates.length) {
      throw new Error('NO_TEMPLATES_IN_RESPONSE');
    }

    // Validate every template has {{שם}} or {{name}}
    const missing = parsed.templates
      .map((t, i) => ({ t, i }))
      .filter(({ t }) => !TemplateEngine.hasNameVar(t));
    if (missing.length === parsed.templates.length) {
      throw new Error('AI_FORGOT_NAME_VAR');
    }

    return {
      name: (parsed.name || 'סט חדש').trim(),
      icon: (parsed.icon || '💬').trim().slice(0, 4),
      templates: parsed.templates.map(t => String(t).trim()).filter(Boolean),
      // metadata
      intent: intent.trim(),
      model,
      generatedAt: Date.now()
    };
  }

  function errMessage(code) {
    if (code.startsWith('API_401')) return 'מפתח API לא תקין. בדוק בהגדרות.';
    if (code.startsWith('API_429')) return 'יותר מדי בקשות בזמן קצר. נסה שוב בעוד דקה.';
    if (code.startsWith('API_5'))   return 'שירות Claude לא זמין כרגע. נסה שוב בעוד מספר דקות.';
    if (code.startsWith('NETWORK')) return 'שגיאת רשת. בדוק חיבור אינטרנט.';
    if (code === 'NO_API_KEY')      return 'לא הוגדר מפתח API. עבור להגדרות והוסף.';
    if (code === 'EMPTY_INTENT')    return 'תאר תחילה מה אתה רוצה לשלוח.';
    if (code === 'AI_FORGOT_NAME_VAR') return 'רוני יצר תבניות בלי {{שם}} — נסה שוב או הוסף ידנית.';
    if (code.startsWith('PARSE_FAILED')) return 'רוני קיבל תשובה לא תקינה מ-Claude. נסה שוב.';
    return code;
  }

  return { generateVariants, getSettings, saveSettings, errMessage, DEFAULT_MODEL };
})();

if (typeof window !== 'undefined') window.AIGenerator = AIGenerator;
