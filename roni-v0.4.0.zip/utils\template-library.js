// utils/template-library.js
// Manages the user's library of saved template sets, with active-set tracking.
// Loaded as a regular <script> in popup; namespace TemplateLibrary.

const TemplateLibrary = (() => {
  const STORAGE_SETS   = 'roni:templateSets';
  const STORAGE_ACTIVE = 'roni:activeSetId';
  const STORAGE_LEGACY = 'roni:templates'; // v0.2.x — flat list, migrate once

  const DEFAULT_SETS = [
    {
      id: 'form101',
      name: 'תזכורת טופס 101',
      icon: '📝',
      builtin: true,
      templates: [
        `שלום {{שם}}, רוני מגטג'וב 🙋\nטופס 101 שלך עדיין לא הגיע אלינו.\n*ללא הטופס החתום לא נוכל להעביר לך משכורת* — אנא מלא היום. תודה!`,
        `היי {{שם}}! רוני מגטג'וב פה.\nשלחנו אלייך טופס 101 — חשוב *למלא היום* כדי שנשחרר לך את המשכורת בזמן 🙏`,
        `{{שם}}, מדבר רוני מגטג'וב.\nחשוב! טופס 101 שלך עדיין לא הגיע — *בלי החתימה לא נוכל לשלם*. אנא עשה זאת היום. תודה!`,
        `היי {{שם}} 👋 רוני מגטג'וב כאן.\nרצינו להזכיר — טופס 101 ממתין לחתימתך.\n*ללא הטופס לא נוכל לשחרר את המשכורת.* אנא מלא ב-5 דקות 😊`,
        `שלום {{שם}}, זה רוני מגטג'וב.\nנשלח אלייך טופס 101 חשוב למילוי — *הכרחי לתשלום משכורת*. אנא מלא וחתום היום. תודה 🙏`
      ]
    },
    {
      id: 'welcome',
      name: 'ברוכים הבאים',
      icon: '👋',
      builtin: true,
      templates: [
        `שלום {{שם}}, ברוך/ה הבא/ה לגטג'וב! 🎉\nרוני כאן. בקרוב נעדכן אותך על הזדמנויות שיבוץ. שאלה? כתוב/י לנו.`,
        `היי {{שם}} 👋\nכיף שהצטרפת לגטג'וב! מהיום נשלח אלייך הצעות עבודה זמניות בקרבת מקום.`,
        `{{שם}}, ברוכים הבאים לגטג'וב 🤝\nאנחנו מחברים בין עובדים זמניים למעסיקים. תקבל הצעות שמתאימות לך — הכל כאן בוואטסאפ.`,
        `שלום {{שם}}, רוני מגטג'וב 🙋\nשמחים שאת/ה איתנו. נשלח לך עדכונים על משמרות פנויות בהתאם להעדפותיך.`,
        `הי {{שם}}! ברוכים הבאים למשפחת גטג'וב 💚\nרוני כאן לכל שאלה. נתחיל לחפש לך משמרות מתאימות.`
      ]
    },
    {
      id: 'lastminute',
      name: 'משמרת רגע אחרון',
      icon: '⚡',
      builtin: true,
      templates: [
        `{{שם}}, יש לנו משמרת *דחופה* {{תאריך}} ב-{{מקום}} ⚡\nתשלום מיידי. מעוניין/ת? ענה/י YES.`,
        `היי {{שם}}! משמרת התפנתה *לרגע האחרון* — {{מקום}}, {{תאריך}}.\nאם זה מתאים לך, אשר/י כאן ונסגור.`,
        `שלום {{שם}}, משמרת פנויה *עכשיו* ב-{{מקום}} ({{תאריך}}). תשלום טוב 💰\nאם רלוונטי — אנא הגב/י מהר.`,
        `{{שם}}, יש שיבוץ פנוי לרגע האחרון! 🚨\nמיקום: {{מקום}}\nתאריך: {{תאריך}}\nמעוניין/ת? תגיד/י YES וננעל.`,
        `הי {{שם}} 👋\nמישהו ביטל ויש משמרת מצוינת — {{מקום}}, {{תאריך}}. אם אתה פנוי/ה, רוני יסגור לך תוך 5 דקות.`
      ]
    },
    {
      id: 'shift_confirm',
      name: 'אישור משמרת',
      icon: '✅',
      builtin: true,
      templates: [
        `שלום {{שם}}, רוני מגטג'וב.\nתזכורת — משמרת *מחר* ב-{{מקום}}, התחלה {{שעה}}. אנא אשר/י קבלה 👍`,
        `היי {{שם}}! 🙋\nעדכון: משמרת מחר ב-{{מקום}} מתחילה ב-{{שעה}}. אנא ענה/י "מאשר/ת".`,
        `{{שם}}, רוני כאן.\nהמשמרת שלך נקבעה: {{מקום}}, {{שעה}}. *חשוב* להגיע 10 דקות לפני. תודה!`,
        `הי {{שם}} 👋 תזכורת ידידותית — משמרת ב-{{מקום}} מחר ב-{{שעה}}. אנא אשר/י שאתה מגיע.`,
        `שלום {{שם}}, רוצים לוודא שהכל בסדר עם המשמרת מחר ב-{{מקום}} ({{שעה}}). אנא אשר/י 🙏`
      ]
    }
  ];

  function load() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_SETS, STORAGE_ACTIVE, STORAGE_LEGACY], (data) => {
        let sets = data[STORAGE_SETS];
        let activeId = data[STORAGE_ACTIVE];
        const legacy = data[STORAGE_LEGACY];

        // First-run: seed defaults
        if (!sets || !sets.length) {
          sets = JSON.parse(JSON.stringify(DEFAULT_SETS));
          // If legacy flat list existed, preserve it as a custom set
          if (Array.isArray(legacy) && legacy.length) {
            sets.unshift({
              id: 'legacy_' + Date.now(),
              name: 'התבניות הישנות שלי',
              icon: '⭐',
              builtin: false,
              templates: legacy.filter(t => t && t.trim())
            });
          }
        }

        if (!activeId || !sets.find(s => s.id === activeId)) {
          activeId = sets[0].id;
        }
        resolve({ sets, activeId });
      });
    });
  }

  function save(sets, activeId) {
    return new Promise((resolve) => {
      chrome.storage.local.set({
        [STORAGE_SETS]: sets,
        [STORAGE_ACTIVE]: activeId
      }, resolve);
    });
  }

  function newId() {
    return 'set_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
  }

  function createSet({ name, icon, templates, intent, model } = {}) {
    return {
      id: newId(),
      name: (name || 'סט חדש').trim(),
      icon: (icon || '💬').trim() || '💬',
      builtin: false,
      templates: (templates && templates.length) ? templates : ['שלום {{שם}}, רוני מגטג\'וב 🙋'],
      intent: intent || null,
      model: model || null,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
  }

  return { load, save, createSet, DEFAULT_SETS };
})();

if (typeof window !== 'undefined') window.TemplateLibrary = TemplateLibrary;
