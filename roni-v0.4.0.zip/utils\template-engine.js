// utils/template-engine.js
// Variable substitution + template rotation. Hebrew & English aliases.
// Loaded as a regular <script> in popup; namespace TemplateEngine.

const TemplateEngine = (() => {
  const NAME_VARS = ['name', 'שם', 'שם פרטי', 'first_name', 'firstName'];

  // Simple {{var}} or {{var|fallback}} replacement.
  // Variables are resolved first against contact.name (for any NAME_VARS alias),
  // then against contact.extra (case-insensitive).
  function render(template, contact) {
    if (!template) return '';
    return String(template).replace(/\{\{\s*([^}|]+?)(?:\s*\|\s*([^}]+))?\s*\}\}/g, (_, key, fallback) => {
      const k = key.trim();
      // name aliases → contact.name
      if (NAME_VARS.some(n => n.toLowerCase() === k.toLowerCase())) {
        return contact.name || (fallback ?? '');
      }
      // extra fields (case-insensitive lookup)
      if (contact.extra) {
        const found = Object.keys(contact.extra).find(x => x.trim().toLowerCase() === k.toLowerCase());
        if (found != null) {
          const val = contact.extra[found];
          if (val !== '' && val != null) return String(val);
        }
      }
      return fallback != null ? fallback.trim() : '';
    });
  }

  function extractVars(template) {
    const out = new Set();
    if (!template) return [];
    const re = /\{\{\s*([^}|]+?)(?:\s*\|[^}]+)?\s*\}\}/g;
    let m;
    while ((m = re.exec(template))) out.add(m[1].trim());
    return [...out];
  }

  function hasNameVar(template) {
    return extractVars(template).some(v => NAME_VARS.some(n => n.toLowerCase() === v.toLowerCase()));
  }

  // Validates an array of templates. Returns { ok, errors[], warnings[] }.
  function validateTemplates(templates) {
    const errors = [];
    const warnings = [];
    const valid = templates.filter(t => t && t.trim());
    if (!valid.length) errors.push('אין תבניות פעילות');
    valid.forEach((t, i) => {
      if (!hasNameVar(t)) {
        errors.push(`תבנית ${i + 1}: חובה שתכלול {{שם}} או {{name}} (פרסונליזציה היא ההגנה החשובה ביותר נגד פינגרפרינטינג)`);
      }
      if (t.length < 30) warnings.push(`תבנית ${i + 1}: קצרה מאוד (${t.length} תווים) — קל יותר לזהות כספאם`);
      if (t.length > 1500) warnings.push(`תבנית ${i + 1}: ארוכה מאוד (${t.length} תווים)`);
    });
    if (valid.length < 3) warnings.push('פחות מ-3 תבניות פעילות — Roni ממליץ על 3-5 גרסאות לרוטציה');
    return { ok: errors.length === 0, errors, warnings, count: valid.length };
  }

  // Rotation engine: avoids re-using the same template for the same contact twice in a row.
  class Rotator {
    constructor(templates) {
      this.templates = templates.filter(t => t && t.trim());
      this.lastUsed = new Map(); // contactId → template index
      this.useCount = new Array(this.templates.length).fill(0);
    }

    pick(contactId) {
      if (!this.templates.length) throw new Error('NO_TEMPLATES');
      if (this.templates.length === 1) {
        this.useCount[0]++;
        return { index: 0, template: this.templates[0] };
      }
      const last = this.lastUsed.get(contactId);
      // Prefer the least-used template that wasn't last for this contact.
      const candidates = this.templates
        .map((t, i) => ({ i, count: this.useCount[i] }))
        .filter(c => c.i !== last)
        .sort((a, b) => a.count - b.count || Math.random() - 0.5);
      const choice = candidates[0];
      this.useCount[choice.i]++;
      this.lastUsed.set(contactId, choice.i);
      return { index: choice.i, template: this.templates[choice.i] };
    }

    renderForContact(contact) {
      const { index, template } = this.pick(contact.id);
      return { index, text: render(template, contact) };
    }

    distribution() {
      return this.useCount.slice();
    }
  }

  return { render, extractVars, hasNameVar, validateTemplates, Rotator, NAME_VARS };
})();

const DEFAULT_TEMPLATES = [
  `שלום {{שם}}, רוני מגטג'וב 🙋\nטופס 101 שלך עדיין לא הגיע אלינו.\n*ללא הטופס החתום לא נוכל להעביר לך משכורת* — אנא מלא היום. תודה!`,
  `היי {{שם}}! רוני מגטג'וב פה.\nשלחנו אלייך טופס 101 — חשוב *למלא היום* כדי שנשחרר לך את המשכורת בזמן 🙏`,
  `{{שם}}, מדבר רוני מגטג'וב.\nחשוב! טופס 101 שלך עדיין לא הגיע — *בלי החתימה לא נוכל לשלם*. אנא עשה זאת היום. תודה!`,
  `היי {{שם}} 👋 רוני מגטג'וב כאן.\nרצינו להזכיר — טופס 101 ממתין לחתימתך.\n*ללא הטופס לא נוכל לשחרר את המשכורת.* אנא מלא ב-5 דקות 😊`,
  `שלום {{שם}}, זה רוני מגטג'וב.\nנשלח אלייך טופס 101 חשוב למילוי — *הכרחי לתשלום משכורת*. אנא מלא וחתום היום. תודה 🙏`
];

if (typeof window !== 'undefined') {
  window.TemplateEngine = TemplateEngine;
  window.DEFAULT_TEMPLATES = DEFAULT_TEMPLATES;
}
