// utils/insights.js — aggregations from the event log for the dashboard tab.

const Insights = (() => {
  const HOUR_MS = 3600 * 1000;
  const DAY_MS = 24 * HOUR_MS;

  function startOfTodayIsraelMs() {
    const fmt = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Jerusalem' });
    const dateStr = fmt.format(new Date()).slice(0, 10); // YYYY-MM-DD in IL
    // construct UTC ms for "midnight in IL". IL is UTC+2/+3 — use Date.parse with TZ-aware string.
    return Date.parse(`${dateStr}T00:00:00+02:00`); // approximation; close enough for hourly buckets
  }

  async function summary() {
    const events = await EventLog.load();
    const now = Date.now();
    const todayStart = startOfTodayIsraelMs();
    const weekAgo = now - 7 * DAY_MS;

    const today    = events.filter(e => e.t >= todayStart);
    const week     = events.filter(e => e.t >= weekAgo);

    const sentToday = today.filter(e => e.type === EventLog.TYPE.SEND_SUCCESS).length;
    const sentWeek  = week.filter(e => e.type === EventLog.TYPE.SEND_SUCCESS).length;
    const failedToday = today.filter(e => e.type === EventLog.TYPE.SEND_FAILED).length;
    const failedWeek  = week.filter(e => e.type === EventLog.TYPE.SEND_FAILED).length;
    const breaksToday = today.filter(e => e.type === EventLog.TYPE.BREAK_TAKEN).length;

    const successRateWeek = sentWeek + failedWeek > 0
      ? Math.round((sentWeek / (sentWeek + failedWeek)) * 100)
      : null;

    const circuitOpensWeek = week.filter(e => e.type === EventLog.TYPE.CIRCUIT_OPENED).length;
    const softBlocksWeek   = week.filter(e => e.type === EventLog.TYPE.SOFT_BLOCK_DETECTED).length;
    const aiUsesWeek       = week.filter(e => e.type === EventLog.TYPE.AI_GENERATION).length;

    return {
      sentToday, failedToday, breaksToday,
      sentWeek, failedWeek,
      successRateWeek,
      circuitOpensWeek, softBlocksWeek, aiUsesWeek,
      totalEvents: events.length
    };
  }

  // 7-day × 24-hour heatmap of send_success events
  async function sendsHeatmap() {
    const events = await EventLog.load();
    const now = Date.now();
    const weekAgo = now - 7 * DAY_MS;
    const sends = events.filter(e => e.type === EventLog.TYPE.SEND_SUCCESS && e.t >= weekAgo);

    // Build [dayOffset(0..6 — 0 = today)][hour(0..23)] = count
    const grid = Array.from({ length: 7 }, () => Array(24).fill(0));
    const fmt = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Jerusalem',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false
    });
    const todayStr = (() => {
      const p = fmt.formatToParts(new Date());
      return `${p.find(x => x.type === 'year').value}-${p.find(x => x.type === 'month').value}-${p.find(x => x.type === 'day').value}`;
    })();

    for (const ev of sends) {
      const p = fmt.formatToParts(new Date(ev.t));
      const dStr = `${p.find(x => x.type === 'year').value}-${p.find(x => x.type === 'month').value}-${p.find(x => x.type === 'day').value}`;
      const hr = parseInt(p.find(x => x.type === 'hour').value, 10);
      // diff in days vs today
      const diff = Math.round((Date.parse(todayStr + 'T00:00:00Z') - Date.parse(dStr + 'T00:00:00Z')) / DAY_MS);
      if (diff >= 0 && diff < 7) grid[diff][hr]++;
    }
    return { grid, max: Math.max(1, ...grid.flat()) };
  }

  // Per-template-set usage breakdown last 30 days
  async function templateSetUsage() {
    const events = await EventLog.load();
    const cutoff = Date.now() - 30 * DAY_MS;
    const sends = events.filter(e =>
      e.type === EventLog.TYPE.SEND_SUCCESS && e.t >= cutoff && e.setId
    );
    const map = new Map();
    for (const s of sends) {
      map.set(s.setId, (map.get(s.setId) || 0) + 1);
    }
    return [...map.entries()]
      .map(([setId, count]) => ({ setId, count }))
      .sort((a, b) => b.count - a.count);
  }

  // Pattern detection: events leading up to a circuit open
  async function preCircuitForensics() {
    const events = await EventLog.load();
    const opens = events.filter(e => e.type === EventLog.TYPE.CIRCUIT_OPENED);
    return opens.map(open => {
      const tenMinBefore = open.t - 10 * 60 * 1000;
      const ctx = events.filter(e => e.t >= tenMinBefore && e.t <= open.t);
      const sendCount = ctx.filter(e => e.type === EventLog.TYPE.SEND_SUCCESS).length;
      const failCount = ctx.filter(e => e.type === EventLog.TYPE.SEND_FAILED).length;
      return {
        openedAt: open.t,
        reason: open.reason,
        contextWindowMin: 10,
        sendsBefore: sendCount,
        failuresBefore: failCount,
        events: ctx.length
      };
    });
  }

  return { summary, sendsHeatmap, templateSetUsage, preCircuitForensics };
})();

if (typeof window !== 'undefined') window.Insights = Insights;
