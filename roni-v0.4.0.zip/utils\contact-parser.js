// utils/contact-parser.js
// Parses Excel/CSV files into a normalized contact list.
// Loaded as a regular <script> in the popup; relies on global XLSX from lib/xlsx.full.min.js.

const ContactParser = (() => {
  // Aliases for the two required columns (Hebrew + English variations).
  const NAME_KEYS  = ['name', 'שם', 'שם פרטי', 'first name', 'firstname', 'Name', 'שֵם'];
  const PHONE_KEYS = ['phone', 'טלפון', 'נייד', 'מספר', 'mobile', 'Phone', 'cellphone', 'cell'];

  function pickKey(row, candidates) {
    const rowKeys = Object.keys(row);
    // exact match first
    for (const c of candidates) {
      if (Object.prototype.hasOwnProperty.call(row, c)) return c;
    }
    // case-insensitive trimmed match
    const norm = (s) => String(s).trim().toLowerCase();
    const map = new Map(rowKeys.map(k => [norm(k), k]));
    for (const c of candidates) {
      const hit = map.get(norm(c));
      if (hit) return hit;
    }
    return null;
  }

  function normalizePhone(raw) {
    if (raw == null) return '';
    let digits = String(raw).replace(/\D/g, '');
    if (!digits) return '';
    if (digits.startsWith('00')) digits = digits.slice(2);
    if (digits.startsWith('972')) return digits;
    if (digits.startsWith('0'))   return '972' + digits.slice(1);
    if (digits.length === 9 && digits.startsWith('5')) return '972' + digits;
    if (digits.length === 10 && digits.startsWith('5')) return '972' + digits; // 5XXXXXXXXX
    return digits;
  }

  function isValidIsraeliMobile(digits) {
    // After normalization should be 9725XXXXXXXX (12 digits, starts with 9725)
    return /^9725\d{8}$/.test(digits);
  }

  function parseFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const wb = XLSX.read(e.target.result, { type: 'array', codepage: 65001 });
          const sheet = wb.Sheets[wb.SheetNames[0]];
          if (!sheet) return reject(new Error('NO_SHEET'));
          const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
          resolve(rowsToContacts(rows));
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('FILE_READ_ERROR'));
      reader.readAsArrayBuffer(file);
    });
  }

  function rowsToContacts(rows) {
    if (!rows.length) return { contacts: [], stats: empty() };

    const sample = rows[0];
    const nameKey  = pickKey(sample, NAME_KEYS);
    const phoneKey = pickKey(sample, PHONE_KEYS);

    if (!nameKey)  throw new Error('MISSING_NAME_COLUMN');
    if (!phoneKey) throw new Error('MISSING_PHONE_COLUMN');

    const seen = new Set();
    const contacts = [];
    const stats = empty();
    stats.total = rows.length;

    rows.forEach((row, i) => {
      const rawName  = String(row[nameKey] ?? '').trim();
      const rawPhone = row[phoneKey];
      const phone    = normalizePhone(rawPhone);

      if (!rawName)  { stats.missingName++;  return; }
      if (!phone)    { stats.missingPhone++; return; }
      if (!isValidIsraeliMobile(phone)) { stats.invalidPhone++; return; }
      if (seen.has(phone)) { stats.duplicate++; return; }
      seen.add(phone);

      // Strip the two known keys from extras to keep the variable map clean.
      const extra = { ...row };
      delete extra[nameKey];
      delete extra[phoneKey];

      contacts.push({
        id: i + 1,
        name: rawName,
        phone,
        extra,
        status: 'pending', // pending | sent | failed | skipped
        templateUsed: null,
        sentAt: null,
        error: null
      });
    });

    stats.accepted = contacts.length;
    return { contacts, stats };
  }

  function empty() {
    return { total: 0, accepted: 0, missingName: 0, missingPhone: 0, invalidPhone: 0, duplicate: 0 };
  }

  return { parseFile, normalizePhone, isValidIsraeliMobile, rowsToContacts };
})();

if (typeof window !== 'undefined') window.ContactParser = ContactParser;
