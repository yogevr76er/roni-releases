// background/service-worker.js
// Persistent background queue + scheduler. Sends messages even when popup is closed.
// Keeps state in chrome.storage.local so it survives worker restarts.

const TAG = '[GetJob/bg]';
const QUEUE_KEY = 'roni:queue';
const ALARM_NAME = 'roni-queue-tick';
const SCHEDULE_PREFIX = 'roni-schedule-';
const EVENTS_KEY = 'roni:events';
const SAFETY_KEY = 'roni:safetyState';

chrome.runtime.onInstalled.addListener(() => {
  console.log(TAG, 'installed');
});

// Side panel: open when user clicks toolbar icon (alongside popup)
try {
  chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: false });
} catch (_) { /* older Chrome */ }

// Allow side panel on any tab — useful when WA Web isn't focused
chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m && m.type === 'OPEN_SIDE_PANEL') {
    chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
      try {
        await chrome.sidePanel.open({ tabId: tab.id });
        send({ ok: true });
      } catch (e) { send({ ok: false, error: e.message }); }
    });
    return true;
  }
});

// ===== Direct event log access (bg can't import popup-side modules) =====
async function logEvent(type, data = {}) {
  const { [EVENTS_KEY]: events = [] } = await chrome.storage.local.get([EVENTS_KEY]);
  const v = chrome.runtime.getManifest().version;
  const evt = { t: Date.now(), type, v, ...data };
  if (data.phone) evt.phone = '...' + String(data.phone).slice(-4);
  events.push(evt);
  if (events.length > 10000) events.splice(0, events.length - 10000);
  await chrome.storage.local.set({ [EVENTS_KEY]: events });
}

// ===== Reply detection from content script =====
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'REPLY_DETECTED') {
    const p = msg.payload || {};
    logEvent('reply_received', {
      phone: p.phone,
      originalMsgId: p.originalMsgId,
      responseTimeSec: p.responseTimeSec,
      replyLen: p.replyLen
    });
    sendResponse({ ok: true });
    return false;
  }

  if (msg && msg.type === 'BG_PING') {
    sendResponse({ ok: true, ts: Date.now() });
    return false;
  }

  // ===== Queue control =====
  if (msg && msg.type === 'QUEUE_START') {
    startQueue(msg.payload).then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'QUEUE_PAUSE') {
    pauseQueue().then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'QUEUE_RESUME') {
    resumeQueue().then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'QUEUE_CANCEL') {
    cancelQueue().then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'QUEUE_STATUS') {
    getQueueStatus().then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'SCHEDULE_AT') {
    scheduleAt(msg.payload).then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'SCHEDULE_LIST') {
    listSchedules().then(r => sendResponse(r));
    return true;
  }
  if (msg && msg.type === 'SCHEDULE_CANCEL') {
    cancelSchedule(msg.payload).then(r => sendResponse(r));
    return true;
  }

  return false;
});

// ===== Alarm-driven queue tick =====
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) {
    await processNextInQueue();
  } else if (alarm.name.startsWith(SCHEDULE_PREFIX)) {
    const scheduleId = alarm.name.slice(SCHEDULE_PREFIX.length);
    await fireSchedule(scheduleId);
  }
});

// ===== Queue model =====
// queue = { id, items: [{ contactId, phone, name, text, status, attemptedAt?, error?, msgId?, ack? }],
//           cursor, status: 'idle'|'running'|'paused'|'completed'|'cancelled',
//           startedAt, completedAt, profile }

async function getQueue() {
  const { [QUEUE_KEY]: q } = await chrome.storage.local.get([QUEUE_KEY]);
  return q || null;
}

async function setQueue(q) {
  return chrome.storage.local.set({ [QUEUE_KEY]: q });
}

async function startQueue({ items, profile = 'balanced', source = 'manual' }) {
  const queue = {
    id: 'q_' + Date.now(),
    items: items.map((it, i) => ({ ...it, idx: i, status: 'pending' })),
    cursor: 0,
    status: 'running',
    startedAt: Date.now(),
    completedAt: null,
    profile,
    source
  };
  await setQueue(queue);
  await logEvent('queue_started', { queueId: queue.id, count: items.length, profile, source });
  // First tick after a tiny delay so UI updates can render
  await chrome.alarms.create(ALARM_NAME, { when: Date.now() + 1500 });
  return { ok: true, queueId: queue.id };
}

async function pauseQueue() {
  const q = await getQueue();
  if (!q) return { ok: false, error: 'NO_QUEUE' };
  q.status = 'paused';
  await setQueue(q);
  await chrome.alarms.clear(ALARM_NAME);
  await logEvent('queue_paused', { queueId: q.id });
  return { ok: true };
}

async function resumeQueue() {
  const q = await getQueue();
  if (!q) return { ok: false, error: 'NO_QUEUE' };
  q.status = 'running';
  await setQueue(q);
  await chrome.alarms.create(ALARM_NAME, { when: Date.now() + 500 });
  await logEvent('queue_resumed', { queueId: q.id });
  return { ok: true };
}

async function cancelQueue() {
  const q = await getQueue();
  if (!q) return { ok: false, error: 'NO_QUEUE' };
  q.status = 'cancelled';
  q.completedAt = Date.now();
  await setQueue(q);
  await chrome.alarms.clear(ALARM_NAME);
  await logEvent('queue_completed', { queueId: q.id, status: 'cancelled' });
  return { ok: true };
}

async function getQueueStatus() {
  const q = await getQueue();
  if (!q) return { exists: false };
  const counts = { pending: 0, sent: 0, failed: 0, skipped: 0 };
  for (const it of q.items) counts[it.status] = (counts[it.status] || 0) + 1;
  return {
    exists: true,
    id: q.id,
    status: q.status,
    cursor: q.cursor,
    total: q.items.length,
    counts,
    startedAt: q.startedAt,
    completedAt: q.completedAt,
    profile: q.profile,
    nextItem: q.items.find(i => i.status === 'pending') || null
  };
}

// ===== Safety logic (mini copy — avoiding ESM imports in service worker for simplicity) =====
const PROFILES = {
  cautious: { mu: Math.log(120), sigma: 0.45, min: 60, max: 360, dailyCap: 50, sessionCap: 15, breakEvery: 12, breakMin: 600, breakMax: 1200 },
  balanced: { mu: Math.log(75),  sigma: 0.40, min: 35, max: 240, dailyCap: 120, sessionCap: 25, breakEvery: 20, breakMin: 300, breakMax: 900 },
  active:   { mu: Math.log(50),  sigma: 0.35, min: 25, max: 180, dailyCap: 180, sessionCap: 35, breakEvery: 25, breakMin: 240, breakMax: 600 }
};
function logNormalSec(p) {
  let u1 = Math.random(); if (u1 < 1e-9) u1 = 1e-9;
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * Math.random());
  return Math.max(p.min, Math.min(p.max, Math.round(Math.exp(p.mu + p.sigma * z))));
}

async function getSafety() {
  const { [SAFETY_KEY]: s } = await chrome.storage.local.get([SAFETY_KEY]);
  return s || { profile: 'balanced', sessionCount: 0, dailyCount: 0, dailyDate: '', lastSendAt: 0, circuit: 'OK', consecutiveFailures: 0, ackHistory: [], breaksTakenThisSession: 0, workingHours: { enabled: false, days: [0,1,2,3,4], startHour: 9, endHour: 18 } };
}
async function saveSafety(s) {
  return chrome.storage.local.set({ [SAFETY_KEY]: s });
}
function inWorkingHours(wh) {
  if (!wh.enabled) return true;
  const fmt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jerusalem', weekday: 'short', hour: '2-digit', hour12: false });
  const parts = fmt.formatToParts(new Date());
  const wd = parts.find(p => p.type === 'weekday')?.value;
  const hr = parseInt(parts.find(p => p.type === 'hour')?.value, 10);
  const dayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
  return wh.days.includes(dayMap[wd]) && hr >= wh.startHour && hr < wh.endHour;
}

// ===== The actual send loop =====
async function processNextInQueue() {
  const q = await getQueue();
  if (!q || q.status !== 'running') return;

  const item = q.items.find(i => i.status === 'pending');
  if (!item) {
    q.status = 'completed';
    q.completedAt = Date.now();
    await setQueue(q);
    await logEvent('queue_completed', { queueId: q.id, status: 'completed' });
    notifyUser('רוני', '✅ סיימתי את הסבב!');
    return;
  }

  const safety = await getSafety();
  const p = PROFILES[safety.profile] || PROFILES.balanced;

  // Pre-flight guards
  if (safety.circuit === 'OPEN_24H') {
    notifyUser('רוני', '🛑 התור עצור — circuit פתוח ל-24 שעות');
    return;
  }
  if (safety.dailyCount >= p.dailyCap) {
    notifyUser('רוני', `🌙 הגעתי ל-${p.dailyCap} היום. ממשיך מחר.`);
    return;
  }
  if (!inWorkingHours(safety.workingHours)) {
    notifyUser('רוני', '🌙 מחוץ לשעות פעילות. ממשיך כשנחזור.');
    return;
  }
  if (safety.sessionCount >= p.sessionCap) {
    notifyUser('רוני', `☕ עברתי ${p.sessionCap} בסשן. הפסקה של 30 דק' ואז ממשיך.`);
    safety.sessionCount = 0;
    await saveSafety(safety);
    await chrome.alarms.create(ALARM_NAME, { when: Date.now() + 30 * 60 * 1000 });
    return;
  }

  // Find WA tab
  const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  const tab = tabs[0];
  if (!tab) {
    notifyUser('רוני', '⚠️ WhatsApp Web לא פתוח. פתח טאב ולחץ "המשך"');
    q.status = 'paused';
    await setQueue(q);
    return;
  }

  // Send
  item.status = 'sending';
  item.attemptedAt = Date.now();
  await setQueue(q);
  await logEvent('send_attempted', { phone: item.phone, msgLen: item.text.length, source: 'queue', queueId: q.id, contactId: item.contactId });

  let resp = null;
  try {
    resp = await chrome.tabs.sendMessage(tab.id, { type: 'SEND_MESSAGE', phone: item.phone, text: item.text });
  } catch (err) {
    resp = { success: false, error: 'COMM:' + err.message };
  }

  if (resp && resp.success) {
    item.status = 'sent';
    item.msgId = resp.result.msgId;
    item.ack = resp.result.ack;
    await logEvent('send_success', {
      phone: item.phone, method: resp.result.method, ack: resp.result.ack,
      durationMs: Date.now() - item.attemptedAt, source: 'queue', queueId: q.id,
      contactId: item.contactId, setId: item.setId, templateIdx: item.templateIdx
    });
    safety.sessionCount++;
    safety.dailyCount++;
    safety.lastSendAt = Date.now();
    safety.consecutiveFailures = 0;
  } else {
    item.status = 'failed';
    item.error = resp?.error || 'unknown';
    await logEvent('send_failed', {
      phone: item.phone, error: item.error,
      durationMs: Date.now() - item.attemptedAt, source: 'queue', queueId: q.id,
      contactId: item.contactId
    });
    safety.consecutiveFailures = (safety.consecutiveFailures || 0) + 1;
    if (safety.consecutiveFailures >= 7) {
      safety.circuit = 'OPEN_24H';
      safety.circuitSince = Date.now();
      await logEvent('circuit_opened', { reason: 'SEVEN_FAILURES', queueId: q.id });
      notifyUser('רוני', '🛑 7 כשלים רצופים — עוצר ל-24 שעות. בדוק את החיבור.');
    } else if (safety.consecutiveFailures >= 5) {
      safety.circuit = 'COOLING_10MIN';
      safety.circuitSince = Date.now();
      notifyUser('רוני', '⏸️ 5 כשלים רצופים — קירור 10 דקות');
    } else if (safety.consecutiveFailures >= 3) {
      notifyUser('רוני', `⚠️ ${safety.consecutiveFailures} כשלים רצופים. ממשיך אבל זהיר.`);
    }
    // 1-2 failures: silent
  }

  await setQueue(q);
  await saveSafety(safety);

  if (safety.circuit !== 'OK') return; // stop ticking

  // Schedule next: usually log-normal delay, occasionally a coffee break
  let nextDelaySec;
  if (safety.sessionCount > 0 && safety.sessionCount % p.breakEvery === 0) {
    nextDelaySec = p.breakMin + Math.floor(Math.random() * (p.breakMax - p.breakMin));
    await logEvent('break_taken', { seconds: nextDelaySec, after: safety.sessionCount });
    notifyUser('רוני', `☕ הפסקת קפה ${Math.round(nextDelaySec/60)} דקות`);
  } else {
    nextDelaySec = logNormalSec(p);
  }
  await chrome.alarms.create(ALARM_NAME, { when: Date.now() + nextDelaySec * 1000 });
}

// ===== Scheduling: fire a saved batch at a specific time =====
async function scheduleAt({ at, payload, label }) {
  const id = 'sch_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
  const all = await getSchedules();
  all[id] = { id, at, label: label || '', payload, createdAt: Date.now(), status: 'pending' };
  await chrome.storage.local.set({ 'roni:schedules': all });
  await chrome.alarms.create(SCHEDULE_PREFIX + id, { when: at });
  await logEvent('schedule_created', { scheduleId: id, at, count: payload.items?.length });
  return { ok: true, id };
}

async function fireSchedule(id) {
  const all = await getSchedules();
  const sch = all[id];
  if (!sch || sch.status !== 'pending') return;
  sch.status = 'fired';
  sch.firedAt = Date.now();
  await chrome.storage.local.set({ 'roni:schedules': all });
  await logEvent('schedule_fired', { scheduleId: id });
  await startQueue(sch.payload);
  notifyUser('רוני', `🚀 התחלתי את הסבב המתוזמן: ${sch.label || id}`);
}

async function getSchedules() {
  const { 'roni:schedules': all } = await chrome.storage.local.get(['roni:schedules']);
  return all || {};
}

async function listSchedules() {
  const all = await getSchedules();
  return { ok: true, schedules: Object.values(all).sort((a, b) => a.at - b.at) };
}

async function cancelSchedule(id) {
  const all = await getSchedules();
  if (!all[id]) return { ok: false, error: 'NOT_FOUND' };
  all[id].status = 'cancelled';
  await chrome.storage.local.set({ 'roni:schedules': all });
  await chrome.alarms.clear(SCHEDULE_PREFIX + id);
  return { ok: true };
}

// ===== Notifications (require notifications permission) =====
function notifyUser(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title,
      message
    });
  } catch (_) { /* no permission */ }
}
