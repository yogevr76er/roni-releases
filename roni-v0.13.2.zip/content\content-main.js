// content-main.js — runs in MAIN world of web.whatsapp.com.
// v0.13: DOM-ONLY sender. NO webpack injection.
//
// We learned the hard way (lesson_no_parasitic_push.md): pushing a parasitic
// chunk to webpackChunkwhatsapp_web_client BREAKS WhatsApp Web's session
// initialization in 2026. So we do not touch webpack at all — pure DOM.
//
// Bridge: window.postMessage <-> isolated world (content-isolated.js).

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- DOM helpers (verified via Chrome MCP inspection 2026-05-01) ----------
  // KEY FINDING: WA Web 2026 search box is now <input type="text">, NOT contenteditable.
  // Compose box is still contenteditable (in chat footer).
  function findSearchBox() {
    const selectors = [
      // Modern: input element (verified in WA Web 2026)
      'input[type="text"][placeholder*="Search"]',
      'input[type="text"][placeholder*="חיפוש"]',
      'input[type="text"][placeholder*="צ\'אט"]',
      'input[type="text"][role="textbox"]',
      // Generic — any visible text input (last resort, but check it's not the compose)
      'header input[type="text"]',
      'div[role="search"] input',
      // Legacy fallbacks (older WA or if they revert)
      'div[role="textbox"][contenteditable="true"][data-tab="3"]',
      'div[role="textbox"][contenteditable="true"][data-tab="4"]',
      'div[contenteditable="true"][aria-label*="חיפוש"]',
      'div[contenteditable="true"][aria-label*="Search"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return { el, selector: sel };
    }
    return { el: null, selector: null };
  }

  function findNewChatButton() {
    const selectors = [
      // Verified in WA Web 2026
      '[aria-label="New chat"]',
      '[aria-label="צ\'אט חדש"]',
      '[aria-label*="New chat"][role="button"]',
      '[aria-label*="צ\'אט חדש"][role="button"]',
      'button[aria-label*="New chat"]',
      'button[aria-label*="צ\'אט חדש"]',
      // Older selectors
      '[aria-label="חיפוש או צ\'אט חדש"]',
      '[aria-label="Search or start new chat"]',
      '[aria-label="Search or start a new chat"]',
      'span[data-icon="new-chat-outline"]',
      'span[data-icon*="new-chat"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return { el, selector: sel };
    }
    return { el: null, selector: null };
  }

  function findComposeBox() {
    const selectors = [
      'footer div[contenteditable="true"][role="textbox"]',
      'footer div[contenteditable="true"]',
      'footer [role="textbox"]',
      'div[role="textbox"][contenteditable="true"][data-tab="10"]',
      'div[role="textbox"][contenteditable="true"][aria-label*="הודעה"]',
      'div[role="textbox"][contenteditable="true"][aria-label*="message"]',
      'div[role="textbox"][contenteditable="true"][aria-label*="Type"]',
      // Last resort: any contenteditable not in the sidebar
      'main div[contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return { el, selector: sel };
    }
    return { el: null, selector: null };
  }

  // Wait for an element matching predicate. Polls every 200ms up to timeoutMs.
  async function waitFor(predicate, timeoutMs = 15000, intervalMs = 200) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = predicate();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  }

  // Type into either an <input>/<textarea> or a contenteditable div.
  async function typeIntoField(el, text, jitter = true) {
    el.focus();
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      // Use the native value setter so React picks up the change
      const proto = el.tagName === 'INPUT' ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, '');
      el.dispatchEvent(new Event('input', { bubbles: true }));
      let acc = '';
      for (const ch of text) {
        acc += ch;
        setter.call(el, acc);
        el.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true }));
        if (jitter) await sleep(40 + Math.random() * 80);
      }
      return;
    }
    // contenteditable path
    try { document.execCommand('selectAll', false, null); } catch (_) {}
    try { document.execCommand('delete', false, null); } catch (_) {}
    for (const ch of text) {
      try {
        document.execCommand('insertText', false, ch);
      } catch (_) {
        el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ch, bubbles: true }));
        el.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true }));
      }
      if (jitter) await sleep(40 + Math.random() * 80);
    }
  }

  function pressEnter(el) {
    el.focus();
    const ev = (type) => new KeyboardEvent(type, {
      key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true
    });
    el.dispatchEvent(ev('keydown'));
    el.dispatchEvent(ev('keypress'));
    el.dispatchEvent(ev('keyup'));
  }

  // ---------- DOM-only send ----------
  // Verified flow (WA Web 2026, via Chrome MCP inspection):
  // 1. Click "New chat" button → opens new-chat side panel with search input
  // 2. Type phone in the search <input> (real input, not contenteditable)
  // 3. Click first matching contact row
  // 4. Type message in compose contenteditable
  // 5. Press Enter
  async function sendViaDom(phone, text) {
    const t0 = Date.now();
    const log = (s) => console.log(TAG, `[send] ${s} (+${Date.now()-t0}ms)`);

    // 1. Open the new-chat / search panel
    let search = findSearchBox();
    if (!search.el) {
      log('search not visible, looking for New chat button');
      const btn = findNewChatButton();
      if (btn.el) {
        log(`clicking new-chat button: ${btn.selector}`);
        btn.el.click();
        await sleep(700);
        search = findSearchBox();
      }
    }
    if (!search.el) {
      // Last resort: WA's keyboard shortcut Ctrl+Alt+/ for search
      log('still no search, trying Ctrl+Alt+/ shortcut');
      const ev = new KeyboardEvent('keydown', {
        key: '/', code: 'Slash', keyCode: 191, which: 191,
        ctrlKey: true, altKey: true, bubbles: true, cancelable: true
      });
      document.dispatchEvent(ev);
      document.body.dispatchEvent(ev);
      await sleep(600);
      search = findSearchBox();
    }
    if (!search.el) {
      // Final diagnostic dump
      const inputs = [...document.querySelectorAll('input')].map(e => ({
        type: e.type, placeholder: e.placeholder?.slice(0, 30), aria: e.getAttribute('aria-label')?.slice(0, 30)
      })).slice(0, 5);
      const buttons = [...document.querySelectorAll('button[aria-label], [role="button"][aria-label]')]
        .map(e => e.getAttribute('aria-label')?.slice(0, 30)).slice(0, 8);
      throw new Error(`SEARCH_BOX_NOT_FOUND. inputs: ${JSON.stringify(inputs)}. buttons: ${JSON.stringify(buttons)}. שלח ליוגב.`);
    }
    log(`search box found: ${search.selector} (${search.el.tagName})`);

    // 2. Type phone number into search
    await typeIntoField(search.el, phone, false); // no jitter on phone — fast
    log(`typed phone into search`);
    await sleep(900);

    // 3. Find the first contact result. WA shows matching results below the search.
    // Strategy: pick the FIRST [role="listitem"] that is NOT the search input itself.
    const resultSelectors = [
      'div[role="listitem"][tabindex]',
      'div[role="grid"] div[role="row"]',
      'div[role="list"] div[role="listitem"]',
      'div[data-list-scroll-container] div[role="listitem"]'
    ];
    let result = null;
    const startedAt = Date.now();
    while (Date.now() - startedAt < 5000) {
      for (const sel of resultSelectors) {
        const items = document.querySelectorAll(sel);
        if (items.length > 0) {
          result = items[0];
          break;
        }
      }
      if (result) break;
      await sleep(150);
    }
    if (!result) throw new Error('NO_CONTACT_MATCH — לא הופיעה תוצאה לחיפוש. ייתכן שהמספר לא קיים בוואטסאפ או שWA לוקח זמן.');
    log(`result found, clicking`);
    result.click();
    await sleep(800);

    // 4. Find the compose box (now visible after opening chat)
    const compose = await waitFor(() => {
      const c = findComposeBox();
      return c.el ? c : null;
    }, 8000);
    if (!compose) throw new Error('COMPOSE_BOX_NOT_FOUND — השיחה נפתחה אבל תיבת הכתיבה לא הופיעה.');
    log(`compose found: ${compose.selector}`);

    // 5. Type the message
    await typeIntoField(compose.el, text);
    log(`message typed`);
    await sleep(400);

    // 6. Send via Enter
    pressEnter(compose.el);
    log(`Enter pressed`);
    await sleep(800);

    return {
      method: 'dom',
      ack: 'sent',
      msgId: null,
      durationMs: Date.now() - t0
    };
  }

  // ---------- Top-level send ----------
  async function send(phone, text) {
    return await sendViaDom(phone, text);
  }

  // ---------- Connection state probe ----------
  function getConnectionState() {
    // Heuristic: if search box is present, WA is loaded.
    if (findSearchBox().el) return 'CONNECTED';
    // QR screen present?
    if (document.querySelector('canvas[role="img"]')) return 'PAIRING';
    return 'BUILDING';
  }

  function isReady() {
    return getConnectionState() === 'CONNECTED';
  }

  // ---------- Chat extraction (DOM-based) ----------
  function extractChats(opts = {}) {
    const limit = opts.limit || 500;
    // WA renders chat list as virtualized rows. We pick visible rows.
    const rows = document.querySelectorAll('div[role="grid"] div[role="row"], div[data-list-scroll-container] div[role="listitem"]');
    const out = [];
    for (const row of rows) {
      if (out.length >= limit) break;
      // Try to extract name + (preview/timestamp); we don't have phone from DOM
      // unless we open the chat. Provide best-effort.
      const nameEl = row.querySelector('[title], span[dir="auto"]');
      const name = nameEl ? (nameEl.getAttribute('title') || nameEl.textContent || '').trim() : '';
      if (!name) continue;
      out.push({ name, phone: '', isGroup: false });
    }
    return out;
  }

  // ---------- Diagnostic (passive — does NOT touch webpack) ----------
  async function runDiagnostic() {
    const t0 = Date.now();
    const search = findSearchBox();
    const compose = findComposeBox();
    const report = {
      capturedAt: new Date().toISOString(),
      version: '0.13.0',
      strategy: 'DOM-only (no webpack injection)',
      whatsapp: {
        pageReady: document.readyState,
        url: location.href,
        title: document.title
      },
      dom: {
        searchBoxFound: !!search.el,
        searchBoxSelector: search.selector,
        composeBoxFound: !!compose.el,
        composeBoxSelector: compose.selector,
        contenteditables: document.querySelectorAll('[contenteditable="true"]').length,
        chatListMounted: !!document.querySelector('div[role="grid"], div[role="list"]'),
        qrCanvas: !!document.querySelector('canvas[role="img"]')
      },
      connection: {
        state: getConnectionState()
      },
      recommendations: []
    };

    if (report.dom.qrCanvas) {
      report.recommendations.push('🟡 ה-QR מוצג — סרוק קודם מהטלפון, אז רוני יוכל לשלוח.');
    } else if (!report.dom.searchBoxFound) {
      report.recommendations.push('🔴 לא נמצאה תיבת חיפוש — WhatsApp עוד לא נטען מלא או שמשהו חוסם. חכה עוד 10 שניות.');
    } else if (!report.dom.chatListMounted) {
      report.recommendations.push('🟡 רשימת השיחות לא הופיעה. ייתכן שהסשן עוד מסתנכרן.');
    } else {
      report.recommendations.push('✅ הכל נראה תקין. רוני אמור לשלוח.');
    }

    report.diagnosticLatencyMs = Date.now() - t0;
    return report;
  }

  // ---------- bridge: window.postMessage <-> isolated world ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;

    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        respond({ ok: true, result: {
          ready: isReady(),
          state: getConnectionState(),
          hasStore: false, // we don't use Store anymore
          mode: 'dom-only'
        }});
      } else if (action === 'rebuildStore') {
        // Legacy action — no-op now, just report state
        respond({ ok: true, result: { hasStore: false, hasChat: false, mode: 'dom-only', note: 'v0.13 uses DOM only' }});
      } else if (action === 'extractChats') {
        try {
          const chats = extractChats(payload);
          respond({ ok: true, result: { chats } });
        } catch (e) {
          respond({ ok: false, error: e.message });
        }
      } else if (action === 'diagnose') {
        const report = await runDiagnostic();
        respond({ ok: true, result: report });
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  console.log(TAG, 'injected (MAIN world) — DOM-only mode, no webpack injection');
})();
