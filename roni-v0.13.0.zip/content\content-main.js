// content-main.js — runs in MAIN world of web.whatsapp.com.
// v0.13: DOM-ONLY sender. NO webpack injection.
//
// We learned the hard way (lesson_no_parasitic_push.md): pushing a parasitic
// chunk to webpackChunkwhatsapp_web_client BREAKS WhatsApp Web's session
// initialization in 2026. So we do not touch webpack at all — pure DOM.
//
// Bridge: window.postMessage <-> isolated world (content-isolated.js).

(function () {
  'use strict';

  const TAG = '[GetJob/main]';
  const REQ = 'GETJOB_REQUEST';
  const RES = 'GETJOB_RESPONSE';

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ---------- DOM helpers ----------
  function findSearchBox() {
    const selectors = [
      'div[role="textbox"][contenteditable="true"][data-tab="3"]',
      'div[role="textbox"][contenteditable="true"][data-tab="4"]',
      'div[contenteditable="true"][aria-label*="חיפוש"]',
      'div[contenteditable="true"][aria-label*="צ\'אט"]',
      'div[contenteditable="true"][aria-label*="Search"]',
      'div[role="textbox"][contenteditable="true"]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return { el, selector: sel };
    }
    return { el: null, selector: null };
  }

  function findComposeBox() {
    const selectors = [
      'div[role="textbox"][contenteditable="true"][data-tab="10"]',
      'footer div[contenteditable="true"][role="textbox"]',
      'footer div[contenteditable="true"]',
      'footer [role="textbox"]'
    ];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      // Prefer the one that's NOT the search box (search has data-tab=3/4, compose has 10)
      for (const el of els) {
        const dt = el.getAttribute('data-tab');
        if (dt === '10') return { el, selector: sel };
        if (!dt || dt === '6') return { el, selector: sel }; // compose without data-tab
      }
    }
    return { el: null, selector: null };
  }

  // Wait for an element matching predicate. Polls every 200ms up to timeoutMs.
  async function waitFor(predicate, timeoutMs = 15000, intervalMs = 200) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const result = predicate();
      if (result) return result;
      await sleep(intervalMs);
    }
    return null;
  }

  // Type a string into a contenteditable, simulating real keypresses.
  async function typeIntoContentEditable(el, text, jitter = true) {
    el.focus();
    // Try execCommand first — works on most contenteditables
    try { document.execCommand('selectAll', false, null); } catch (_) {}
    try { document.execCommand('delete', false, null); } catch (_) {}
    for (const ch of text) {
      try {
        document.execCommand('insertText', false, ch);
      } catch (_) {
        // Fallback: dispatch input event with InputEvent
        el.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ch, bubbles: true }));
        el.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true }));
      }
      if (jitter) await sleep(40 + Math.random() * 80);
    }
  }

  function pressEnter(el) {
    el.focus();
    const ev = (type) => new KeyboardEvent(type, {
      key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true
    });
    el.dispatchEvent(ev('keydown'));
    el.dispatchEvent(ev('keypress'));
    el.dispatchEvent(ev('keyup'));
  }

  // ---------- DOM-only send ----------
  // Strategy: use WA's native search-by-number flow. Open new chat → type
  // phone in search → click matching result → type message → Enter.
  async function sendViaDom(phone, text) {
    const t0 = Date.now();
    const log = (s) => console.log(TAG, `[send] ${s} (+${Date.now()-t0}ms)`);

    // 1. Find/open search box
    let search = findSearchBox();
    if (!search.el) {
      // Try clicking the new-chat / search button to open it
      const btnSelectors = [
        '[aria-label="חיפוש או צ\'אט חדש"]',
        '[aria-label="Search or start new chat"]',
        '[aria-label*="חיפוש"][role="button"]',
        '[aria-label*="Search"][role="button"]'
      ];
      for (const sel of btnSelectors) {
        const b = document.querySelector(sel);
        if (b) { b.click(); break; }
      }
      await sleep(500);
      search = findSearchBox();
    }
    if (!search.el) throw new Error('SEARCH_BOX_NOT_FOUND — לא מצאתי את תיבת החיפוש של WhatsApp. ודא שWA Web נטען מלא.');
    log(`search box found: ${search.selector}`);

    // 2. Type phone number into search (no leading +)
    search.el.focus();
    try { document.execCommand('selectAll', false, null); } catch (_) {}
    try { document.execCommand('delete', false, null); } catch (_) {}
    document.execCommand('insertText', false, phone);
    log(`typed phone into search`);
    await sleep(900);

    // 3. Find the first contact result. WA shows matching results below the search.
    // Strategy: pick the FIRST [role="listitem"] that is NOT the search input itself.
    const resultSelectors = [
      'div[role="listitem"][tabindex]',
      'div[role="grid"] div[role="row"]',
      'div[role="list"] div[role="listitem"]',
      'div[data-list-scroll-container] div[role="listitem"]'
    ];
    let result = null;
    const startedAt = Date.now();
    while (Date.now() - startedAt < 5000) {
      for (const sel of resultSelectors) {
        const items = document.querySelectorAll(sel);
        if (items.length > 0) {
          result = items[0];
          break;
        }
      }
      if (result) break;
      await sleep(150);
    }
    if (!result) throw new Error('NO_CONTACT_MATCH — לא הופיעה תוצאה לחיפוש. ייתכן שהמספר לא קיים בוואטסאפ או שWA לוקח זמן.');
    log(`result found, clicking`);
    result.click();
    await sleep(800);

    // 4. Find the compose box (now visible after opening chat)
    const compose = await waitFor(() => {
      const c = findComposeBox();
      return c.el ? c : null;
    }, 8000);
    if (!compose) throw new Error('COMPOSE_BOX_NOT_FOUND — השיחה נפתחה אבל תיבת הכתיבה לא הופיעה.');
    log(`compose found: ${compose.selector}`);

    // 5. Type the message
    await typeIntoContentEditable(compose.el, text);
    log(`message typed`);
    await sleep(400);

    // 6. Send via Enter
    pressEnter(compose.el);
    log(`Enter pressed`);
    await sleep(800);

    return {
      method: 'dom',
      ack: 'sent',
      msgId: null,
      durationMs: Date.now() - t0
    };
  }

  // ---------- Top-level send ----------
  async function send(phone, text) {
    return await sendViaDom(phone, text);
  }

  // ---------- Connection state probe ----------
  function getConnectionState() {
    // Heuristic: if search box is present, WA is loaded.
    if (findSearchBox().el) return 'CONNECTED';
    // QR screen present?
    if (document.querySelector('canvas[role="img"]')) return 'PAIRING';
    return 'BUILDING';
  }

  function isReady() {
    return getConnectionState() === 'CONNECTED';
  }

  // ---------- Chat extraction (DOM-based) ----------
  function extractChats(opts = {}) {
    const limit = opts.limit || 500;
    // WA renders chat list as virtualized rows. We pick visible rows.
    const rows = document.querySelectorAll('div[role="grid"] div[role="row"], div[data-list-scroll-container] div[role="listitem"]');
    const out = [];
    for (const row of rows) {
      if (out.length >= limit) break;
      // Try to extract name + (preview/timestamp); we don't have phone from DOM
      // unless we open the chat. Provide best-effort.
      const nameEl = row.querySelector('[title], span[dir="auto"]');
      const name = nameEl ? (nameEl.getAttribute('title') || nameEl.textContent || '').trim() : '';
      if (!name) continue;
      out.push({ name, phone: '', isGroup: false });
    }
    return out;
  }

  // ---------- Diagnostic (passive — does NOT touch webpack) ----------
  async function runDiagnostic() {
    const t0 = Date.now();
    const search = findSearchBox();
    const compose = findComposeBox();
    const report = {
      capturedAt: new Date().toISOString(),
      version: '0.13.0',
      strategy: 'DOM-only (no webpack injection)',
      whatsapp: {
        pageReady: document.readyState,
        url: location.href,
        title: document.title
      },
      dom: {
        searchBoxFound: !!search.el,
        searchBoxSelector: search.selector,
        composeBoxFound: !!compose.el,
        composeBoxSelector: compose.selector,
        contenteditables: document.querySelectorAll('[contenteditable="true"]').length,
        chatListMounted: !!document.querySelector('div[role="grid"], div[role="list"]'),
        qrCanvas: !!document.querySelector('canvas[role="img"]')
      },
      connection: {
        state: getConnectionState()
      },
      recommendations: []
    };

    if (report.dom.qrCanvas) {
      report.recommendations.push('🟡 ה-QR מוצג — סרוק קודם מהטלפון, אז רוני יוכל לשלוח.');
    } else if (!report.dom.searchBoxFound) {
      report.recommendations.push('🔴 לא נמצאה תיבת חיפוש — WhatsApp עוד לא נטען מלא או שמשהו חוסם. חכה עוד 10 שניות.');
    } else if (!report.dom.chatListMounted) {
      report.recommendations.push('🟡 רשימת השיחות לא הופיעה. ייתכן שהסשן עוד מסתנכרן.');
    } else {
      report.recommendations.push('✅ הכל נראה תקין. רוני אמור לשלוח.');
    }

    report.diagnosticLatencyMs = Date.now() - t0;
    return report;
  }

  // ---------- bridge: window.postMessage <-> isolated world ----------
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== REQ) return;

    const { id, action, payload } = msg;
    const respond = (data) => window.postMessage({ type: RES, id, data }, '*');

    try {
      if (action === 'send') {
        const result = await send(payload.phone, payload.text);
        respond({ ok: true, result });
      } else if (action === 'status') {
        respond({ ok: true, result: {
          ready: isReady(),
          state: getConnectionState(),
          hasStore: false, // we don't use Store anymore
          mode: 'dom-only'
        }});
      } else if (action === 'rebuildStore') {
        // Legacy action — no-op now, just report state
        respond({ ok: true, result: { hasStore: false, hasChat: false, mode: 'dom-only', note: 'v0.13 uses DOM only' }});
      } else if (action === 'extractChats') {
        try {
          const chats = extractChats(payload);
          respond({ ok: true, result: { chats } });
        } catch (e) {
          respond({ ok: false, error: e.message });
        }
      } else if (action === 'diagnose') {
        const report = await runDiagnostic();
        respond({ ok: true, result: report });
      } else {
        respond({ ok: false, error: 'UNKNOWN_ACTION' });
      }
    } catch (err) {
      respond({ ok: false, error: err.message || String(err) });
    }
  });

  console.log(TAG, 'injected (MAIN world) — DOM-only mode, no webpack injection');
})();
