// utils/safety.js — anti-ban guardrails: delays, working hours, circuit breaker.
// Pure logic, callable from popup or background. Persists state to chrome.storage.local.

const Safety = (() => {
  const STORAGE_KEY = 'roni:safetyState';

  // --- Profiles: each is a tradeoff between throughput and ban-risk ---
  const PROFILES = {
    cautious: {
      label: '🛡️ זהיר',
      desc: 'מקסימום הגנה — לחשבונות חדשים או אחרי חסימה',
      delayMu: Math.log(120),  // median ~120s
      delaySigma: 0.45,
      delayMin: 60,
      delayMax: 360,
      dailyCap: 50,
      sessionCap: 15,
      breakEvery: 12,
      breakMinSec: 600,   // 10 min
      breakMaxSec: 1200   // 20 min
    },
    balanced: {
      label: '⚖️ מאוזן',
      desc: 'ברירת מחדל — מתאים לרוב הרכזות',
      delayMu: Math.log(75),   // median ~75s
      delaySigma: 0.4,
      delayMin: 35,
      delayMax: 240,
      dailyCap: 120,
      sessionCap: 25,
      breakEvery: 20,
      breakMinSec: 300,   // 5 min
      breakMaxSec: 900    // 15 min
    },
    active: {
      label: '⚡ פעיל',
      desc: 'יותר הודעות ביום — לחשבונות מבוססים בלבד',
      delayMu: Math.log(50),
      delaySigma: 0.35,
      delayMin: 25,
      delayMax: 180,
      dailyCap: 180,
      sessionCap: 35,
      breakEvery: 25,
      breakMinSec: 240,
      breakMaxSec: 600
    }
  };

  // Working hours: Israel time, Sun-Thu 09-18 by default
  const DEFAULT_WORKING_HOURS = {
    enabled: true,
    days: [0, 1, 2, 3, 4],   // 0=Sun ... 4=Thu (JS getDay)
    startHour: 9,
    endHour: 18,
    timezone: 'Asia/Jerusalem'
  };

  // --- log-normal delay sample ---
  function sampleLogNormal(mu, sigma, min, max) {
    // Box-Muller for standard normal
    let u1 = Math.random(); if (u1 < 1e-9) u1 = 1e-9;
    const u2 = Math.random();
    const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    const x = Math.exp(mu + sigma * z);
    return Math.max(min, Math.min(max, Math.round(x)));
  }

  function getDelaySeconds(profileKey = 'balanced') {
    const p = PROFILES[profileKey] || PROFILES.balanced;
    return sampleLogNormal(p.delayMu, p.delaySigma, p.delayMin, p.delayMax);
  }

  // --- working hours gate ---
  function nowInIsrael() {
    // Get current time in Asia/Jerusalem regardless of host TZ
    const fmt = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'Asia/Jerusalem',
      weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false
    });
    const parts = fmt.formatToParts(new Date());
    const wd = parts.find(p => p.type === 'weekday')?.value;
    const hr = parseInt(parts.find(p => p.type === 'hour')?.value, 10);
    const mn = parseInt(parts.find(p => p.type === 'minute')?.value, 10);
    const dayMap = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    return { day: dayMap[wd], hour: hr, minute: mn };
  }

  function checkWorkingHours(config = DEFAULT_WORKING_HOURS) {
    if (!config.enabled) return { ok: true, reason: 'WORKING_HOURS_DISABLED' };
    const { day, hour } = nowInIsrael();
    if (!config.days.includes(day)) return { ok: false, reason: 'OUTSIDE_WORK_DAYS', day, hour };
    if (hour < config.startHour || hour >= config.endHour) return { ok: false, reason: 'OUTSIDE_WORK_HOURS', day, hour };
    return { ok: true, day, hour };
  }

  // --- circuit breaker state machine ---
  // State: OK | WARNING | COOLING_10MIN | OPEN_24H
  function defaultState() {
    return {
      circuit: 'OK',
      circuitSince: 0,
      circuitReason: null,
      sessionCount: 0,
      sessionStartedAt: 0,
      dailyCount: 0,
      dailyDate: todayString(),
      lastSendAt: 0,
      consecutiveFailures: 0,
      ackHistory: [],         // last 20 ack states for soft-block detection
      breaksTakenThisSession: 0,
      profile: 'balanced',
      workingHours: { ...DEFAULT_WORKING_HOURS }
    };
  }

  function todayString() {
    const { day, hour } = nowInIsrael();
    // YYYY-MM-DD in Israel time (rough, by computing local-ish)
    const fmt = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Jerusalem' });
    return fmt.format(new Date()).slice(0, 10);
  }

  function loadState() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (data) => {
        let s = data[STORAGE_KEY];
        if (!s) s = defaultState();
        // daily reset
        if (s.dailyDate !== todayString()) {
          s.dailyCount = 0;
          s.dailyDate = todayString();
          s.breaksTakenThisSession = 0;
        }
        // session reset if inactive >30 min
        if (s.lastSendAt && Date.now() - s.lastSendAt > 30 * 60 * 1000) {
          s.sessionCount = 0;
          s.breaksTakenThisSession = 0;
          s.sessionStartedAt = 0;
        }
        // auto-reopen 24h circuit
        if (s.circuit === 'OPEN_24H' && Date.now() - s.circuitSince > 24 * 3600 * 1000) {
          s.circuit = 'OK';
          s.circuitReason = 'AUTO_REOPENED';
          s.circuitSince = Date.now();
          s.consecutiveFailures = 0;
        }
        if (s.circuit === 'COOLING_10MIN' && Date.now() - s.circuitSince > 10 * 60 * 1000) {
          s.circuit = 'WARNING';  // require user ack to clear
        }
        resolve(s);
      });
    });
  }

  function saveState(s) {
    return new Promise((r) => chrome.storage.local.set({ [STORAGE_KEY]: s }, r));
  }

  // --- pre-send check: returns { allowed, reason, wait? } ---
  async function checkCanSend(state) {
    if (state.circuit === 'OPEN_24H') {
      return { allowed: false, reason: 'CIRCUIT_OPEN_24H', expiresAt: state.circuitSince + 24 * 3600 * 1000 };
    }
    if (state.circuit === 'COOLING_10MIN') {
      return { allowed: false, reason: 'CIRCUIT_COOLING', expiresAt: state.circuitSince + 10 * 60 * 1000 };
    }
    if (state.circuit === 'WARNING') {
      return { allowed: false, reason: 'CIRCUIT_WARNING_NEEDS_ACK' };
    }

    const wh = checkWorkingHours(state.workingHours);
    if (!wh.ok) return { allowed: false, reason: wh.reason, day: wh.day, hour: wh.hour };

    const p = PROFILES[state.profile] || PROFILES.balanced;
    if (state.dailyCount >= p.dailyCap) {
      return { allowed: false, reason: 'DAILY_CAP_REACHED', cap: p.dailyCap };
    }
    if (state.sessionCount >= p.sessionCap) {
      return { allowed: false, reason: 'SESSION_CAP_REACHED', cap: p.sessionCap, suggestedBreakSec: 1800 };
    }
    return { allowed: true };
  }

  // --- after-send updates ---
  function recordSuccess(state, ackState) {
    state.lastSendAt = Date.now();
    if (!state.sessionStartedAt) state.sessionStartedAt = Date.now();
    state.sessionCount++;
    state.dailyCount++;
    state.consecutiveFailures = 0;
    pushAck(state, ackState);
    return state;
  }

  function recordFailure(state, errorCode) {
    state.lastSendAt = Date.now();
    state.consecutiveFailures++;
    pushAck(state, 'FAIL:' + errorCode);

    // Sane thresholds — single failures happen (wrong number, network blip, etc.)
    // Only escalate when there's a real pattern.
    if (state.consecutiveFailures >= 7) {
      state.circuit = 'OPEN_24H';
      state.circuitSince = Date.now();
      state.circuitReason = 'SEVEN_FAILURES';
    } else if (state.consecutiveFailures >= 5) {
      state.circuit = 'COOLING_10MIN';
      state.circuitSince = Date.now();
      state.circuitReason = 'FIVE_FAILURES';
    } else if (state.consecutiveFailures >= 3) {
      state.circuit = 'WARNING';
      state.circuitSince = Date.now();
      state.circuitReason = 'THREE_FAILURES';
    }
    // 1-2 failures: silent, just count
    return state;
  }

  function pushAck(state, ack) {
    state.ackHistory.push({ ack, at: Date.now() });
    if (state.ackHistory.length > 20) state.ackHistory.shift();
  }

  // --- soft-block detector: returns risk 0-3 ---
  function detectSoftBlockRisk(state) {
    const recent = state.ackHistory.slice(-10);
    if (recent.length < 5) return { level: 0, reason: 'INSUFFICIENT_DATA' };

    // count pending acks (-1 = sent but no server ack) and failures
    const pendingCount = recent.filter(r => r.ack === null || r.ack === 0 || r.ack === -1).length;
    const failCount = recent.filter(r => typeof r.ack === 'string' && r.ack.startsWith('FAIL:')).length;

    if (failCount >= 2) return { level: 3, reason: 'MULTIPLE_FAILURES' };
    if (pendingCount >= 5) return { level: 2, reason: 'MANY_PENDING_ACKS' };
    if (pendingCount >= 3) return { level: 1, reason: 'SOME_PENDING_ACKS' };
    return { level: 0, reason: 'HEALTHY' };
  }

  function shouldTakeBreak(state) {
    const p = PROFILES[state.profile] || PROFILES.balanced;
    return state.sessionCount > 0 && state.sessionCount % p.breakEvery === 0;
  }

  function getBreakSeconds(state) {
    const p = PROFILES[state.profile] || PROFILES.balanced;
    return p.breakMinSec + Math.floor(Math.random() * (p.breakMaxSec - p.breakMinSec));
  }

  function clearCircuit(state, ack = 'USER_ACK') {
    state.circuit = 'OK';
    state.circuitSince = Date.now();
    state.circuitReason = ack;
    state.consecutiveFailures = 0;
    return state;
  }

  function reasonText(reason) {
    return ({
      DAILY_CAP_REACHED: 'הגעת לתקרה היומית. רוני נח עד מחר 🌙',
      SESSION_CAP_REACHED: 'הגעת לתקרת הסשן. רוני ממליץ על הפסקת ½ שעה ☕',
      OUTSIDE_WORK_DAYS: 'רוני לא שולח בסוף שבוע (שישי-שבת)',
      OUTSIDE_WORK_HOURS: 'מחוץ לשעות הפעילות (09:00-18:00)',
      CIRCUIT_OPEN_24H: '🛑 רוני זיהה סיכון חסימה ועצר ל-24 שעות',
      CIRCUIT_COOLING: '⏸️ רוני בעצירת קירור 10 דקות',
      CIRCUIT_WARNING_NEEDS_ACK: '⚠️ רוני צריך אישור מפורש כדי להמשיך',
      THREE_FAILURES: '3 כשלים רצופים — רוני מבקש אישור',
      FIVE_FAILURES: '5 כשלים רצופים — קירור 10 דקות',
      SEVEN_FAILURES: '7 כשלים רצופים — עצירת חירום ל-24 שעות',
      AUTO_REOPENED: 'רוני התעורר אחרי 24 שעות',
      USER_ACK: 'הרכזת אישרה להמשיך'
    })[reason] || reason;
  }

  return {
    PROFILES, DEFAULT_WORKING_HOURS,
    loadState, saveState, defaultState,
    getDelaySeconds, getBreakSeconds, shouldTakeBreak,
    checkCanSend, checkWorkingHours,
    recordSuccess, recordFailure, clearCircuit,
    detectSoftBlockRisk, reasonText, nowInIsrael
  };
})();

if (typeof window !== 'undefined') window.Safety = Safety;
