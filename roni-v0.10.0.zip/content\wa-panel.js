// content/wa-panel.js — injects floating Roni button + slide-out panel into WhatsApp Web.
// The panel hosts an iframe that loads our existing popup.html — zero UI duplication.

(function () {
  'use strict';

  const TAG = '[GetJob/wa-panel]';
  const STORAGE_OPEN_KEY = 'roni:waPanelOpen';
  const STORAGE_WIDTH_KEY = 'roni:waPanelWidth';

  // Wait a beat to avoid racing WA's own boot
  function init() {
    if (document.getElementById('roni-fab')) return; // idempotent
    injectFab();
    injectPanel();
    restoreState();
    console.log(TAG, 'panel injected');
  }

  function injectFab() {
    const btn = document.createElement('button');
    btn.id = 'roni-fab';
    btn.title = 'רוני — שליחה חכמה';
    btn.textContent = 'R';
    btn.addEventListener('click', togglePanel);
    document.body.appendChild(btn);
  }

  function injectPanel() {
    const container = document.createElement('div');
    container.id = 'roni-panel-container';

    const bar = document.createElement('div');
    bar.id = 'roni-panel-bar';
    bar.innerHTML = `
      <span class="title">🟢 רוני — בתוך WhatsApp</span>
      <button id="roni-panel-popout" title="פתח כחלון נפרד">↗</button>
      <button id="roni-panel-close" title="סגור">✕</button>
    `;

    const iframe = document.createElement('iframe');
    iframe.id = 'roni-panel-iframe';
    iframe.src = chrome.runtime.getURL('popup/popup.html?embed=wapanel');
    iframe.allow = 'clipboard-write';

    const resize = document.createElement('div');
    resize.id = 'roni-panel-resize';

    container.append(resize, bar, iframe);
    document.body.appendChild(container);

    bar.querySelector('#roni-panel-close').addEventListener('click', () => setOpen(false));
    bar.querySelector('#roni-panel-popout').addEventListener('click', () => {
      window.open(chrome.runtime.getURL('popup/popup.html'), '_blank',
        'width=520,height=720,toolbar=no,menubar=no');
    });

    initResize(resize, container);
  }

  function setOpen(open) {
    const c = document.getElementById('roni-panel-container');
    if (!c) return;
    c.classList.toggle('open', open);
    document.body.classList.toggle('roni-panel-open', open);
    try {
      chrome.storage.local.set({ [STORAGE_OPEN_KEY]: open });
    } catch (_) { /* extension context may be invalidated on reload */ }
  }

  function togglePanel() {
    const c = document.getElementById('roni-panel-container');
    if (!c) return;
    setOpen(!c.classList.contains('open'));
  }

  function initResize(handle, panel) {
    let dragging = false;
    let startX = 0;
    let startWidth = 0;
    handle.addEventListener('mousedown', (e) => {
      dragging = true;
      startX = e.clientX;
      startWidth = panel.getBoundingClientRect().width;
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dir = document.documentElement.dir === 'rtl' ? 1 : -1;
      const newWidth = Math.max(360, Math.min(720, startWidth + dir * (e.clientX - startX)));
      panel.style.width = newWidth + 'px';
    });
    window.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      document.body.style.userSelect = '';
      try {
        const w = panel.getBoundingClientRect().width;
        chrome.storage.local.set({ [STORAGE_WIDTH_KEY]: w });
      } catch (_) {}
    });
  }

  function restoreState() {
    try {
      chrome.storage.local.get([STORAGE_OPEN_KEY, STORAGE_WIDTH_KEY], (data) => {
        const c = document.getElementById('roni-panel-container');
        if (!c) return;
        if (data[STORAGE_WIDTH_KEY]) c.style.width = data[STORAGE_WIDTH_KEY] + 'px';
        if (data[STORAGE_OPEN_KEY]) setOpen(true);
      });
    } catch (_) {}
  }

  // Listen for keyboard shortcut Ctrl+Shift+R to toggle (avoids WA's own shortcuts)
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && (e.key === 'R' || e.key === 'r' || e.key === 'ר')) {
      e.preventDefault();
      togglePanel();
    }
  });

  // WA's React renders late — wait for body and a tick
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(init, 800));
  } else {
    setTimeout(init, 800);
  }
})();
