// utils/warmup.js — gradual ramp-up for new accounts to avoid early bans.

const Warmup = (() => {
  const STORAGE_KEY = 'roni:warmupState';

  // Day → cap mapping. Caps the safety profile's dailyCap.
  const RAMP = [
    { day: 1,  cap: 20  },
    { day: 2,  cap: 30  },
    { day: 3,  cap: 40  },
    { day: 4,  cap: 50  },
    { day: 5,  cap: 60  },
    { day: 6,  cap: 70  },
    { day: 7,  cap: 80  },
    { day: 8,  cap: 90  },
    { day: 9,  cap: 100 },
    { day: 10, cap: 110 },
    { day: 11, cap: null }   // null = no warmup cap (use profile default)
  ];

  function load() {
    return new Promise((resolve) => {
      chrome.storage.local.get([STORAGE_KEY], (data) => {
        resolve(data[STORAGE_KEY] || { enabled: false, startedAt: null });
      });
    });
  }
  function save(state) {
    return new Promise((r) => chrome.storage.local.set({ [STORAGE_KEY]: state }, r));
  }

  // Returns { active, day, cap, daysToFull } given current state.
  // cap=null means "no warmup cap, use profile default".
  function status(state) {
    if (!state || !state.enabled || !state.startedAt) {
      return { active: false, day: null, cap: null, daysToFull: 0 };
    }
    const days = Math.floor((Date.now() - state.startedAt) / (24 * 3600 * 1000)) + 1;
    const stage = RAMP.find(r => r.day === days) ||
                  (days >= RAMP[RAMP.length - 1].day ? RAMP[RAMP.length - 1] : RAMP[RAMP.length - 2]);
    if (stage.cap == null || days >= 11) {
      return { active: false, day: days, cap: null, daysToFull: 0, completed: true };
    }
    return { active: true, day: days, cap: stage.cap, daysToFull: 11 - days };
  }

  async function start() {
    const state = { enabled: true, startedAt: Date.now() };
    await save(state);
    return status(state);
  }
  async function stop() {
    const state = { enabled: false, startedAt: null };
    await save(state);
    return status(state);
  }

  // Used by the queue/safety check — returns the effective dailyCap given profile + warmup.
  async function effectiveDailyCap(profileCap) {
    const s = status(await load());
    if (!s.active || s.cap == null) return profileCap;
    return Math.min(profileCap, s.cap);
  }

  return { load, save, status, start, stop, effectiveDailyCap, RAMP };
})();

if (typeof window !== 'undefined') window.Warmup = Warmup;
