// utils/google-contacts.js — auto-save phone numbers to Google Contacts before messaging.
// Per research, "having the number saved" is the #1 anti-ban signal in 2025.
//
// Setup (one-time, by Yogev):
// 1. Console: https://console.cloud.google.com/apis/credentials
// 2. Create OAuth 2.0 Client ID → "Chrome App" → enter the extension's stable ID.
//    To get a stable ID for unpacked dev: add a "key" field to manifest.json (see SETUP.md).
//    For Chrome Web Store distribution, the ID is the store ID.
// 3. Add scope: https://www.googleapis.com/auth/contacts
// 4. Paste the client_id into manifest.json under "oauth2".
// 5. Enable People API on the GCP project.

const GoogleContacts = (() => {
  const CACHE_KEY = 'roni:gcontactsCache';      // phone -> { saved: true, at: ts }
  const SETTINGS_KEY = 'roni:gcontactsSettings'; // { enabled, groupName }

  function isConfigured() {
    const m = chrome.runtime.getManifest();
    return !!(m.oauth2 && m.oauth2.client_id && !m.oauth2.client_id.includes('CHANGE-ME'));
  }

  function getSettings() {
    return new Promise(r => chrome.storage.sync.get([SETTINGS_KEY], d => {
      r(d[SETTINGS_KEY] || { enabled: false, groupName: 'GetJob-WA-2026' });
    }));
  }
  function setSettings(s) {
    return new Promise(r => chrome.storage.sync.set({ [SETTINGS_KEY]: s }, r));
  }

  async function getToken({ interactive = false } = {}) {
    if (!isConfigured()) throw new Error('OAUTH_NOT_CONFIGURED');
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!token) return reject(new Error('NO_TOKEN'));
        resolve(token);
      });
    });
  }

  async function revokeToken() {
    try {
      const token = await getToken({ interactive: false });
      chrome.identity.removeCachedAuthToken({ token });
      await fetch(`https://oauth2.googleapis.com/revoke?token=${token}`, { method: 'POST' });
    } catch (_) {}
  }

  // Load already-saved cache
  async function loadCache() {
    return new Promise(r => chrome.storage.local.get([CACHE_KEY], d => r(d[CACHE_KEY] || {})));
  }
  async function saveCache(cache) {
    return new Promise(r => chrome.storage.local.set({ [CACHE_KEY]: cache }, r));
  }

  // Ensure a contact exists in Google Contacts. Returns { skipped|created|cached }.
  async function ensureSaved(phone, name) {
    const settings = await getSettings();
    if (!settings.enabled) return { skipped: 'DISABLED' };
    if (!isConfigured()) return { skipped: 'NOT_CONFIGURED' };

    const cache = await loadCache();
    if (cache[phone]) return { cached: true };

    let token;
    try {
      token = await getToken({ interactive: false });
    } catch (e) {
      return { skipped: 'NO_TOKEN', error: e.message };
    }

    const body = {
      names: [{ givenName: name || phone }],
      phoneNumbers: [{ value: '+' + phone, type: 'mobile' }],
      memberships: settings.groupName
        ? [{ contactGroupMembership: { contactGroupResourceName: 'contactGroups/myContacts' } }]
        : []
    };

    try {
      const res = await fetch('https://people.googleapis.com/v1/people:createContact', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });
      if (!res.ok) {
        const err = await res.text();
        return { skipped: 'API_ERROR', error: `${res.status}: ${err.slice(0, 200)}` };
      }
      cache[phone] = { saved: true, at: Date.now() };
      await saveCache(cache);
      return { created: true };
    } catch (e) {
      return { skipped: 'NETWORK', error: e.message };
    }
  }

  // Bulk pre-save before a campaign starts (called by queue start)
  async function bulkSave(contacts, onProgress) {
    const settings = await getSettings();
    if (!settings.enabled || !isConfigured()) return { skipped: contacts.length };

    let created = 0, cached = 0, failed = 0;
    for (let i = 0; i < contacts.length; i++) {
      const c = contacts[i];
      const r = await ensureSaved(c.phone, c.name);
      if (r.created) created++;
      else if (r.cached) cached++;
      else failed++;
      if (onProgress) onProgress(i + 1, contacts.length, r);
    }
    return { created, cached, failed };
  }

  return { isConfigured, getSettings, setSettings, getToken, revokeToken, ensureSaved, bulkSave };
})();

if (typeof window !== 'undefined') window.GoogleContacts = GoogleContacts;
